﻿Imports System.Data.OleDb
Imports System.IO

Public Class frmRoomDetails

    Private Sub frmRoomDetails_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Label1.Text = "--"
        Label2.Text = "--"
        Label4.Text = "--"
        txtEditRent.Text = "0.00"
        lblDescContent.Text = ""

        If currentUserRole.ToUpper().Trim() <> "ADMIN" Then
            btnUpdatePrice.Visible = False
            txtEditRent.ReadOnly = True
            txtEditRent.BorderStyle = BorderStyle.None
        Else
            btnUpdatePrice.Visible = True
            txtEditRent.ReadOnly = False
            txtEditRent.BorderStyle = BorderStyle.Fixed3D
        End If

        cmbSelectFloor.Items.Clear()
        cmbSelectFloor.Items.AddRange(New String() {"All Floors", "1st Floor", "2nd Floor", "3rd Floor", "4th Floor", "5th Floor"})

        cmbCapacity.Items.Clear()
        cmbCapacity.Items.AddRange(New String() {"All Rooms", "2 Persons", "4 Persons"})

        cmbSelectFloor.SelectedIndex = 0
        cmbCapacity.SelectedIndex = 0
    End Sub

    Private Sub cmbSelectFloor_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbSelectFloor.SelectedIndexChanged
        LoadFilteredRooms()
    End Sub

    Private Sub cmbCapacity_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbCapacity.SelectedIndexChanged
        LoadFilteredRooms()
    End Sub

    Private Sub LoadFilteredRooms()
        If cmbSelectFloor.SelectedIndex = -1 OrElse cmbCapacity.SelectedIndex = -1 Then Exit Sub

        cmbSelectRoom.Items.Clear()
        Label1.Text = "--"
        Label2.Text = "--"
        Label4.Text = "--"
        txtEditRent.Text = "0.00"
        lblDescContent.Text = ""

        PictureBox1.ImageLocation = Nothing
        PictureBox2.ImageLocation = Nothing

        Dim sql As String = "SELECT RoomNumber FROM tblRooms WHERE 1=1 "

        Select Case cmbSelectFloor.Text
            Case "1st Floor" : sql &= " AND RoomNumber LIKE '1%' "
            Case "2nd Floor" : sql &= " AND RoomNumber LIKE '2%' "
            Case "3rd Floor" : sql &= " AND RoomNumber LIKE '3%' "
            Case "4th Floor" : sql &= " AND RoomNumber LIKE '4%' "
            Case "5th Floor" : sql &= " AND RoomNumber LIKE '5%' "
        End Select

        If cmbCapacity.Text = "2 Persons" Then
            sql &= " AND RoomCapacity = 2 "
        ElseIf cmbCapacity.Text = "4 Persons" Then
            sql &= " AND RoomCapacity = 4 "
        End If

        sql &= " ORDER BY RoomNumber ASC"

        Using myConn As New OleDbConnection(ConnectionString)
            Try
                myConn.Open()
                Dim cmd As New OleDbCommand(sql, myConn)
                Dim reader As OleDbDataReader = cmd.ExecuteReader()

                While reader.Read()
                    cmbSelectRoom.Items.Add(reader("RoomNumber").ToString())
                End While
                reader.Close()

                If cmbSelectRoom.Items.Count > 0 Then
                    cmbSelectRoom.SelectedIndex = 0
                End If
            Catch ex As Exception
                MsgBox("Error loading rooms: " & ex.Message, MsgBoxStyle.Critical, "System Error")
            End Try
        End Using
    End Sub

    Private Sub cmbSelectRoom_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbSelectRoom.SelectedIndexChanged
        If cmbSelectRoom.Text = "" Then Exit Sub

        Using myConn As New OleDbConnection(ConnectionString)
            Try
                myConn.Open()
                Dim sql As String = "SELECT RoomNumber, FloorLevel, RoomCapacity, BaseRent FROM tblRooms WHERE RoomNumber = @rnum"
                Dim cmd As New OleDbCommand(sql, myConn)
                cmd.Parameters.AddWithValue("@rnum", cmbSelectRoom.Text)
                Dim reader As OleDbDataReader = cmd.ExecuteReader()

                If reader.Read() Then
                    Label1.Text = "Room " & reader("RoomNumber").ToString()

                    Dim floorLevel As String = reader("FloorLevel").ToString()
                    If floorLevel = "1" Then
                        Label2.Text = "1st Floor"
                    ElseIf floorLevel = "2" Then
                        Label2.Text = "2nd Floor"
                    ElseIf floorLevel = "3" Then
                        Label2.Text = "3rd Floor"
                    Else
                        Label2.Text = floorLevel & "th Floor"
                    End If

                    If Not IsDBNull(reader("BaseRent")) Then
                        txtEditRent.Text = Convert.ToDecimal(reader("BaseRent")).ToString("0.00")
                    Else
                        txtEditRent.Text = "0.00"
                    End If

                    Dim capacity As Integer = 0
                    If Not IsDBNull(reader("RoomCapacity")) Then
                        capacity = Convert.ToInt32(reader("RoomCapacity"))
                        Label4.Text = capacity.ToString() & " Persons"
                    Else
                        Label4.Text = "--"
                    End If

                    LoadRoomImagesAndDescription(floorLevel)
                End If
                reader.Close()
            Catch ex As Exception
                MsgBox("Error fetching room details: " & ex.Message, MsgBoxStyle.Critical, "System Error")
            End Try
        End Using
    End Sub

    Private Sub LoadRoomImagesAndDescription(floorLvl As String)
        PictureBox1.ImageLocation = Nothing
        PictureBox2.ImageLocation = Nothing

        Dim img1Name As String = ""
        Dim img2Name As String = ""

        Select Case floorLvl
            Case "1"
                img1Name = "first (1).jpg"
                img2Name = "first (2).jpg"
                lblDescContent.Text = vbCrLf &
                                      "Experience comfortable living in this well-maintained space." & vbCrLf &
                                      "Features:" & vbCrLf &
                                      "• Highly spacious layout with a dedicated sink area" & vbCrLf &
                                      "• Ready for air-conditioner installation" & vbCrLf &
                                      "• Private bathroom with hot and cold shower" & vbCrLf &
                                       vbCrLf &
                                      "Perfect for students and professionals seeking a quiet and safe environment."
            Case "2"
                img1Name = "second (1).png"
                img2Name = "second (2).png"
                lblDescContent.Text = vbCrLf &
                                      "Experience comfortable living in this well-maintained space." & vbCrLf &
                                      "Features:" & vbCrLf &
                                      "• Dedicated sink area for washing" & vbCrLf &
                                      "• Ready for air-conditioner installation" & vbCrLf &
                                      "• Private bathroom with hot and cold shower" & vbCrLf &
                                       vbCrLf &
                                      "Perfect for students and professionals seeking a quiet and safe environment."
            Case "3"
                img1Name = "third (1).png"
                img2Name = "third (2).png"
                lblDescContent.Text = vbCrLf &
                                      "Experience comfortable living in this well-maintained space." & vbCrLf &
                                      "Features:" & vbCrLf &
                                      "• Ready for air-conditioner installation" & vbCrLf &
                                      "• Private bathroom with hot and cold shower" & vbCrLf &
                                        vbCrLf &
                                      "Perfect for students and professionals seeking a quiet and safe environment."
            Case "4"
                img1Name = "forth.png"
                img2Name = ""
                lblDescContent.Text = vbCrLf &
                                      "Experience comfortable living in this well-maintained space." & vbCrLf &
                                      "Features:" & vbCrLf &
                                      "• Highly spacious room layout" & vbCrLf &
                                      "• Private bathroom" & vbCrLf &
                                       vbCrLf &
                                      "Perfect for students and professionals seeking a quiet and safe environment."
            Case "5"
                img1Name = "fifth.png"
                img2Name = ""
                lblDescContent.Text = vbCrLf &
                                      "Experience comfortable living in this well-maintained space." & vbCrLf &
                                      "Features:" & vbCrLf &
                                      "• Standard room layout" & vbCrLf &
                                      "• Private bathroom" & vbCrLf &
                                      vbCrLf &
                                      "Perfect for students and professionals seeking a quiet and safe environment."
        End Select

        Dim basePath As String = "C:\Client\RoomPhoto\"

        If img1Name <> "" AndAlso File.Exists(basePath & img1Name) Then
            PictureBox1.ImageLocation = basePath & img1Name
        End If

        If img2Name <> "" AndAlso File.Exists(basePath & img2Name) Then
            PictureBox2.ImageLocation = basePath & img2Name
        End If
    End Sub

    Private Sub btnUpdatePrice_Click(sender As Object, e As EventArgs) Handles btnUpdatePrice.Click
        If cmbSelectRoom.Text = "" Then
            MsgBox("Please select a room first.", MsgBoxStyle.Exclamation, "Selection Required")
            Exit Sub
        End If

        If Not IsNumeric(txtEditRent.Text) Then
            MsgBox("Please enter a valid numeric amount for the base rent.", MsgBoxStyle.Exclamation, "Invalid Input")
            txtEditRent.Focus()
            Exit Sub
        End If

        Dim ans = MsgBox($"Are you sure you want to update the base rent of Room {cmbSelectRoom.Text} to ₱{txtEditRent.Text}?", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "Confirm Price Update")

        If ans = MsgBoxResult.Yes Then
            Using myConn As New OleDbConnection(ConnectionString)
                Try
                    myConn.Open()
                    Dim sql As String = "UPDATE tblRooms SET BaseRent = @rent WHERE RoomNumber = @rnum"
                    Dim cmd As New OleDbCommand(sql, myConn)
                    cmd.Parameters.AddWithValue("@rent", Convert.ToDecimal(txtEditRent.Text))
                    cmd.Parameters.AddWithValue("@rnum", cmbSelectRoom.Text)

                    cmd.ExecuteNonQuery()
                    MsgBox("Room base rent has been updated successfully!", MsgBoxStyle.Information, "Update Successful")

                    txtEditRent.Text = Convert.ToDecimal(txtEditRent.Text).ToString("0.00")
                Catch ex As Exception
                    MsgBox("Error updating room price: " & ex.Message, MsgBoxStyle.Critical, "System Error")
                End Try
            End Using
        End If
    End Sub

    Private Sub txtEditRent_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtEditRent.KeyPress
        If Not Char.IsControl(e.KeyChar) AndAlso Not Char.IsDigit(e.KeyChar) AndAlso e.KeyChar <> "."c Then
            e.Handled = True
        End If

        If e.KeyChar = "."c AndAlso txtEditRent.Text.IndexOf("."c) > -1 Then
            e.Handled = True
        End If
    End Sub
End Class