﻿''Imports System.Data.OleDb
''Imports System.DirectoryServices.ActiveDirectory
''Imports System.IO
''Imports Org.BouncyCastle.Asn1.Cmp

''Public Class frmRoomDetails

''    Global variable para sa room number na ipapakita
''    Public TargetRoomNumber As String = ""

''    Private Sub frmRoomDetails_Load(sender As Object, e As EventArgs) Handles MyBase.Load

''    End Sub

''    Helper para malaman ang floor base sa room number
''    Private Function GetFloorName(roomNum As String) As String
''        Dim firstDigit As String = roomNum.Substring(0, 1)
''        Select Case firstDigit
''            Case "1" : Return "1st Floor"
''            Case "2" : Return "2nd Floor"
''            Case "3" : Return "3rd Floor"
''            Case "4" : Return "4th Floor"
''            Case "5" : Return "5th Floor"
''            Case Else : Return "Unknown"
''        End Select
''    End Function

''    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
''        Me.Close()
''    End Sub

''End Class