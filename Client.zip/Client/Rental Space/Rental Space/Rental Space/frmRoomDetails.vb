﻿Imports System.Data.OleDb

Public Class frmRoomDetails

    Private Sub frmRoomDetails_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Label1.Text = "--"
        Label2.Text = "--"
        txtEditRent.Text = "0.00"

        ' DITO YUNG FIX: Ginawa nating ToUpper() para kahit lowercase "admin" ang gamit mo, lalabas pa rin ang button.
        If currentUserRole.ToUpper().Trim() <> "ADMIN" Then
            btnUpdatePrice.Visible = False
            txtEditRent.ReadOnly = True
            txtEditRent.BorderStyle = BorderStyle.None
        Else
            btnUpdatePrice.Visible = True
            txtEditRent.ReadOnly = False
            txtEditRent.BorderStyle = BorderStyle.Fixed3D
        End If

        cmbSelectFloor.Items.Clear()
        cmbSelectFloor.Items.AddRange(New String() {"All Floors", "1st Floor", "2nd Floor", "3rd Floor", "4th Floor", "5th Floor"})
        cmbSelectFloor.SelectedIndex = 0
    End Sub

    Private Sub cmbSelectFloor_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbSelectFloor.SelectedIndexChanged
        LoadRoomList(cmbSelectFloor.Text)
    End Sub

    Private Sub LoadRoomList(floorFilter As String)
        cmbSelectRoom.Items.Clear()
        Label1.Text = "--"
        Label2.Text = "--"
        txtEditRent.Text = "0.00"

        Dim sql As String = "SELECT RoomNumber FROM tblRooms "
        Dim floorPrefix As String = ""

        Select Case floorFilter
            Case "1st Floor" : floorPrefix = "1"
            Case "2nd Floor" : floorPrefix = "2"
            Case "3rd Floor" : floorPrefix = "3"
            Case "4th Floor" : floorPrefix = "4"
            Case "5th Floor" : floorPrefix = "5"
            Case Else : floorPrefix = ""
        End Select

        If floorPrefix <> "" Then
            sql &= " WHERE RoomNumber LIKE '" & floorPrefix & "%' "
        End If

        sql &= " ORDER BY RoomNumber ASC"

        Using myConn As New OleDbConnection(ConnectionString)
            Try
                myConn.Open()
                Dim cmd As New OleDbCommand(sql, myConn)
                Dim reader As OleDbDataReader = cmd.ExecuteReader()

                While reader.Read()
                    cmbSelectRoom.Items.Add(reader("RoomNumber").ToString())
                End While
                reader.Close()

                If cmbSelectRoom.Items.Count > 0 Then
                    cmbSelectRoom.SelectedIndex = 0
                End If
            Catch ex As Exception
                MsgBox("Error loading rooms: " & ex.Message, MsgBoxStyle.Critical)
            End Try
        End Using
    End Sub

    Private Sub cmbSelectRoom_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbSelectRoom.SelectedIndexChanged
        If cmbSelectRoom.Text = "" Then Exit Sub

        Using myConn As New OleDbConnection(ConnectionString)
            Try
                myConn.Open()
                Dim sql As String = "SELECT RoomNumber, FloorLevel, BaseRent FROM tblRooms WHERE RoomNumber = @rnum"
                Dim cmd As New OleDbCommand(sql, myConn)
                cmd.Parameters.AddWithValue("@rnum", cmbSelectRoom.Text)
                Dim reader As OleDbDataReader = cmd.ExecuteReader()

                If reader.Read() Then
                    Label1.Text = "Room " & reader("RoomNumber").ToString()

                    Dim floorLevel As String = reader("FloorLevel").ToString()
                    If floorLevel = "1" Then
                        Label2.Text = "1st Floor"
                    ElseIf floorLevel = "2" Then
                        Label2.Text = "2nd Floor"
                    ElseIf floorLevel = "3" Then
                        Label2.Text = "3rd Floor"
                    Else
                        Label2.Text = floorLevel & "th Floor"
                    End If

                    If Not IsDBNull(reader("BaseRent")) Then
                        txtEditRent.Text = Convert.ToDecimal(reader("BaseRent")).ToString("0.00")
                    Else
                        txtEditRent.Text = "0.00"
                    End If
                End If
                reader.Close()
            Catch ex As Exception
                MsgBox("Error fetching room details: " & ex.Message, MsgBoxStyle.Critical)
            End Try
        End Using
    End Sub

    Private Sub btnUpdatePrice_Click(sender As Object, e As EventArgs) Handles btnUpdatePrice.Click
        If cmbSelectRoom.Text = "" Then
            MsgBox("Pumili muna ng kwarto.", MsgBoxStyle.Exclamation)
            Exit Sub
        End If

        If Not IsNumeric(txtEditRent.Text) Then
            MsgBox("Pakilagay ang tamang halaga ng presyo (numbers lang).", MsgBoxStyle.Exclamation)
            txtEditRent.Focus()
            Exit Sub
        End If

        Dim ans = MsgBox("Sigurado ka bang gusto mong palitan ang presyo ng Room " & cmbSelectRoom.Text & " sa ₱" & txtEditRent.Text & "?", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "Confirm Update")

        If ans = MsgBoxResult.Yes Then
            Using myConn As New OleDbConnection(ConnectionString)
                Try
                    myConn.Open()
                    Dim sql As String = "UPDATE tblRooms SET BaseRent = @rent WHERE RoomNumber = @rnum"
                    Dim cmd As New OleDbCommand(sql, myConn)
                    cmd.Parameters.AddWithValue("@rent", Convert.ToDecimal(txtEditRent.Text))
                    cmd.Parameters.AddWithValue("@rnum", cmbSelectRoom.Text)

                    cmd.ExecuteNonQuery()
                    MsgBox("Matagumpay na na-update ang presyo ng kwarto!", MsgBoxStyle.Information, "Success")

                    txtEditRent.Text = Convert.ToDecimal(txtEditRent.Text).ToString("0.00")
                Catch ex As Exception
                    MsgBox("Error updating room price: " & ex.Message, MsgBoxStyle.Critical)
                End Try
            End Using
        End If
    End Sub

    Private Sub txtEditRent_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtEditRent.KeyPress
        If Not Char.IsControl(e.KeyChar) AndAlso Not Char.IsDigit(e.KeyChar) AndAlso e.KeyChar <> "."c Then
            e.Handled = True
        End If

        If e.KeyChar = "."c AndAlso txtEditRent.Text.IndexOf("."c) > -1 Then
            e.Handled = True
        End If
    End Sub

End Class