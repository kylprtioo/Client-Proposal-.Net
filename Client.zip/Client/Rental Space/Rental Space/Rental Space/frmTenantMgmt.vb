﻿Imports System.Data.OleDb
Imports System.IO

Public Class frmTenantMgmt
    Public preSelectedRoom As String = ""
    Public selectedTenantID As Integer = 0

    Private Sub frmTenantMgmt_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        cmbFloor.Items.Clear()
        cmbFloor.Items.AddRange(New String() {"1st Floor", "2nd Floor", "3rd Floor", "4th Floor", "5th Floor"})

        dtpBirthday.MaxDate = DateTime.Today

        dgvTenants.AllowUserToAddRows = False
        dgvTenants.ReadOnly = True
        dgvTenants.SelectionMode = DataGridViewSelectionMode.FullRowSelect
        dgvTenants.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells

        txtMeterNumber.ReadOnly = True

        cmbFilterStatus.SelectedIndex = 0

        Dim tempID As Integer = selectedTenantID
        Dim tempRoom As String = preSelectedRoom

        LoadTenants()
        ClearFields()

        selectedTenantID = tempID
        preSelectedRoom = tempRoom

        If preSelectedRoom <> "" Then
            cmbRoom.Items.Add(preSelectedRoom)
            cmbRoom.Text = preSelectedRoom
            cmbRoom.Enabled = False
            cmbFloor.Enabled = False
        End If

        If selectedTenantID > 0 Then
            For i As Integer = 0 To dgvTenants.Rows.Count - 1
                If CInt(dgvTenants.Rows(i).Cells("TenantID").Value) = selectedTenantID Then
                    dgvTenants.Rows(i).Selected = True
                    dgvTenants_CellClick(dgvTenants, New DataGridViewCellEventArgs(0, i))
                    Exit For
                End If
            Next
        End If
    End Sub

    Private Sub cmbFilterStatus_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbFilterStatus.SelectedIndexChanged
        LoadTenants()
        ClearFields()

        If cmbFilterStatus.Text = "Archived Tenants" Then
            btnSave.Enabled = False
            btnUpdate.Enabled = False
            btnCheckout.Enabled = False
            btnDelete.Enabled = False
            lblTitle.Text = "TENANT HISTORY (ARCHIVED)"
            lblTitle.ForeColor = Color.IndianRed
        Else
            btnSave.Enabled = True
            btnUpdate.Enabled = True
            btnCheckout.Enabled = True
            btnDelete.Enabled = True
            lblTitle.Text = "TENANT MANAGEMENT"
            lblTitle.ForeColor = Color.FromArgb(31, 41, 55)
        End If
    End Sub

    Private Function GetCombinedFullName() As String
        Dim last As String = txtLast.Text.Trim()
        Dim first As String = txtFirst.Text.Trim()
        Dim middle As String = txtMiddle.Text.Trim()

        If middle = "" Then
            Return $"{last}, {first}".Trim()
        Else
            Return $"{last}, {first} {middle}".Trim()
        End If
    End Function

    Private Sub cmbFloor_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbFloor.SelectedIndexChanged
        If cmbFloor.SelectedIndex <> -1 Then
            LoadRoomsByFloor(cmbFloor.Text)
        End If
    End Sub

    Private Sub LoadRoomsByFloor(floorName As String)
        If String.IsNullOrEmpty(floorName) Then Exit Sub
        cmbRoom.Items.Clear()
        Try
            Dim floorPrefix As String = floorName.Substring(0, 1)
            Using myConn As New OleDbConnection(ConnectionString)
                myConn.Open()
                Dim sql As String = "SELECT RoomNumber FROM tblRooms WHERE Status = 'Available' AND RoomNumber LIKE @prefix"
                Dim cmd As New OleDbCommand(sql, myConn)
                cmd.Parameters.AddWithValue("@prefix", floorPrefix & "%")
                Dim reader = cmd.ExecuteReader()
                While reader.Read()
                    cmbRoom.Items.Add(reader("RoomNumber").ToString())
                End While
            End Using
        Catch ex As Exception
        End Try
    End Sub

    Private Sub cmbRoom_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbRoom.SelectedIndexChanged
        If cmbRoom.SelectedIndex <> -1 Then
            Using myConn As New OleDbConnection(ConnectionString)
                Try
                    myConn.Open()
                    Dim sql As String = "SELECT BaseRent, MeterNumber FROM tblRooms WHERE RoomNumber = @rnum"
                    Dim cmd As New OleDbCommand(sql, myConn)
                    cmd.Parameters.AddWithValue("@rnum", cmbRoom.Text)
                    Dim reader = cmd.ExecuteReader()

                    If reader.Read() Then
                        If Not IsDBNull(reader("BaseRent")) Then
                            txtRent.Text = Convert.ToDecimal(reader("BaseRent")).ToString("0.00")
                        End If
                        If Not IsDBNull(reader("MeterNumber")) Then
                            txtMeterNumber.Text = reader("MeterNumber").ToString()
                        Else
                            txtMeterNumber.Clear()
                        End If
                    End If
                Catch ex As Exception
                End Try
            End Using
        End If
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        If txtLast.Text = "" Or txtFirst.Text = "" Or cmbRoom.Text = "" Then
            MsgBox("Pakilagay ang kumpletong Pangalan at Room Assignment.", MsgBoxStyle.Exclamation)
            Exit Sub
        End If

        Using myConn As New OleDbConnection(ConnectionString)
            Try
                myConn.Open()
                Dim trans = myConn.BeginTransaction()

                Dim cmdId As New OleDbCommand("SELECT RoomID FROM tblRooms WHERE RoomNumber = @rnum", myConn, trans)
                cmdId.Parameters.AddWithValue("@rnum", cmbRoom.Text)
                Dim rID = cmdId.ExecuteScalar()

                Dim sql As String = "INSERT INTO tblTenants (FullName, ContactNo, EmailAddress, Birthday, StartDate, EndDate, NumberOfOccupants, OtherNames, RoomID, BaseRent, Status) " &
                                    "VALUES (@name, @cont, @email, @bday, @sdate, @edate, @occu, @others, @rid, @rent, 'Active')"

                Dim cmd As New OleDbCommand(sql, myConn, trans)
                cmd.Parameters.AddWithValue("@name", GetCombinedFullName())
                cmd.Parameters.AddWithValue("@cont", txtContact.Text)
                cmd.Parameters.AddWithValue("@email", txtEmail.Text.Trim())
                cmd.Parameters.AddWithValue("@bday", dtpBirthday.Value.ToShortDateString())
                cmd.Parameters.AddWithValue("@sdate", dtpStartDate.Value.ToShortDateString())
                cmd.Parameters.AddWithValue("@edate", dtpEndDate.Value.ToShortDateString())
                cmd.Parameters.AddWithValue("@occu", If(txtOccupants.Text = "", 0, Val(txtOccupants.Text)))
                cmd.Parameters.AddWithValue("@others", txtOtherNames.Text.Trim())
                cmd.Parameters.AddWithValue("@rid", rID)
                cmd.Parameters.AddWithValue("@rent", CDec(txtRent.Text))
                cmd.ExecuteNonQuery()

                Dim cmdUpdateRoom As New OleDbCommand("UPDATE tblRooms SET Status = 'Occupied' WHERE RoomID = @rid", myConn, trans)
                cmdUpdateRoom.Parameters.AddWithValue("@rid", rID)
                cmdUpdateRoom.ExecuteNonQuery()

                trans.Commit()
                MsgBox("Tenant registered successfully!", MsgBoxStyle.Information)
                LoadTenants()
                ClearFields()
            Catch ex As Exception
                MsgBox("Save Error: " & ex.Message)
            End Try
        End Using
    End Sub

    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        If selectedTenantID = 0 Then
            MsgBox("Pumili muna ng tenant sa listahan.")
            Exit Sub
        End If

        Using myConn As New OleDbConnection(ConnectionString)
            Try
                myConn.Open()
                Dim sql As String = "UPDATE tblTenants SET FullName=@name, ContactNo=@cont, EmailAddress=@email, Birthday=@bday, StartDate=@sdate, EndDate=@edate, NumberOfOccupants=@occu, OtherNames=@others, BaseRent=@rent " &
                                    "WHERE TenantID=@id"
                Dim cmd As New OleDbCommand(sql, myConn)
                cmd.Parameters.AddWithValue("@name", GetCombinedFullName())
                cmd.Parameters.AddWithValue("@cont", txtContact.Text)
                cmd.Parameters.AddWithValue("@email", txtEmail.Text.Trim())
                cmd.Parameters.AddWithValue("@bday", dtpBirthday.Value.ToShortDateString())
                cmd.Parameters.AddWithValue("@sdate", dtpStartDate.Value.ToShortDateString())
                cmd.Parameters.AddWithValue("@edate", dtpEndDate.Value.ToShortDateString())
                cmd.Parameters.AddWithValue("@occu", Val(txtOccupants.Text))
                cmd.Parameters.AddWithValue("@others", txtOtherNames.Text.Trim())
                cmd.Parameters.AddWithValue("@rent", CDec(txtRent.Text))
                cmd.Parameters.AddWithValue("@id", selectedTenantID)
                cmd.ExecuteNonQuery()

                MsgBox("Record updated!", MsgBoxStyle.Information)
                LoadTenants()
                ClearFields()
            Catch ex As Exception
                MsgBox("Update Error: " & ex.Message)
            End Try
        End Using
    End Sub

    Private Sub btnCheckout_Click(sender As Object, e As EventArgs) Handles btnCheckout.Click
        If selectedTenantID = 0 Then Exit Sub
        Dim ans = MsgBox("Confirm Check-out?", MsgBoxStyle.YesNo + MsgBoxStyle.Question)
        If ans = MsgBoxResult.Yes Then
            Using myConn As New OleDbConnection(ConnectionString)
                Try
                    myConn.Open()
                    Dim trans = myConn.BeginTransaction()
                    Dim cmd1 = New OleDbCommand("UPDATE tblTenants SET Status = 'Inactive' WHERE TenantID = @id", myConn, trans)
                    cmd1.Parameters.AddWithValue("@id", selectedTenantID)
                    cmd1.ExecuteNonQuery()

                    Dim cmd2 = New OleDbCommand("UPDATE tblRooms SET Status = 'Needs Cleaning' WHERE RoomID = (SELECT RoomID FROM tblTenants WHERE TenantID = @id)", myConn, trans)
                    cmd2.Parameters.AddWithValue("@id", selectedTenantID)
                    cmd2.ExecuteNonQuery()

                    trans.Commit()
                    MsgBox("Tenant checked out.")
                    LoadTenants()
                    ClearFields()
                Catch ex As Exception
                    MsgBox(ex.Message)
                End Try
            End Using
        End If
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        If selectedTenantID = 0 Then
            MsgBox("Pumili muna ng tenant na ia-archive.", MsgBoxStyle.Exclamation)
            Exit Sub
        End If

        If MsgBox("Archive this tenant record? It will be saved as history.", MsgBoxStyle.Question + MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
            Using myConn As New OleDbConnection(ConnectionString)
                Try
                    myConn.Open()
                    Dim trans = myConn.BeginTransaction()

                    Dim cmdR = New OleDbCommand("UPDATE tblRooms SET Status = 'Needs Cleaning' WHERE RoomID = (SELECT RoomID FROM tblTenants WHERE TenantID = @id)", myConn, trans)
                    cmdR.Parameters.AddWithValue("@id", selectedTenantID)
                    cmdR.ExecuteNonQuery()

                    Dim cmdD = New OleDbCommand("UPDATE tblTenants SET Status = 'Archived' WHERE TenantID = @id", myConn, trans)
                    cmdD.Parameters.AddWithValue("@id", selectedTenantID)
                    cmdD.ExecuteNonQuery()

                    trans.Commit()
                    MsgBox("Tenant archived and room marked as 'Needs Cleaning'.")
                    LoadTenants()
                    ClearFields()
                Catch ex As Exception
                End Try
            End Using
        End If
    End Sub

    Private Sub LoadTenants(Optional searchTerm As String = "")
        Using myConn As New OleDbConnection(ConnectionString)
            Try
                dgvTenants.DataSource = Nothing

                Dim statusFilter As String = If(cmbFilterStatus.Text = "Archived Tenants", "Archived", "Active")

                Dim sql As String = "SELECT t.*, r.MeterNumber FROM tblTenants t INNER JOIN tblRooms r ON t.RoomID = r.RoomID WHERE t.Status = '" & statusFilter & "'"
                If searchTerm <> "" Then sql &= " AND t.FullName LIKE '%" & searchTerm & "%'"

                Dim adapter As New OleDbDataAdapter(sql, myConn)
                Dim dt As New DataTable
                adapter.Fill(dt)
                dgvTenants.DataSource = dt
            Catch ex As Exception
            End Try
        End Using
    End Sub

    Private Sub dgvTenants_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgvTenants.CellClick
        If e.RowIndex >= 0 Then
            Try
                Dim row = dgvTenants.Rows(e.RowIndex)
                selectedTenantID = CInt(row.Cells("TenantID").Value)

                Dim full As String = row.Cells("FullName").Value.ToString()
                txtLast.Clear()
                txtFirst.Clear()
                txtMiddle.Clear()

                If full.Contains(",") Then
                    Dim parts() As String = full.Split(","c)
                    txtLast.Text = parts(0).Trim()

                    Dim firstMid As String = parts(1).Trim()
                    Dim nameParts() As String = firstMid.Split(New Char() {" "c}, StringSplitOptions.RemoveEmptyEntries)

                    If nameParts.Length = 1 Then
                        txtFirst.Text = nameParts(0)
                    ElseIf nameParts.Length > 1 Then
                        txtMiddle.Text = nameParts(nameParts.Length - 1)
                        txtFirst.Text = String.Join(" ", nameParts, 0, nameParts.Length - 1)
                    End If
                Else
                    txtLast.Text = full
                End If

                txtContact.Text = row.Cells("ContactNo").Value.ToString()
                txtEmail.Text = If(IsDBNull(row.Cells("EmailAddress").Value), "", row.Cells("EmailAddress").Value.ToString())
                txtOccupants.Text = If(IsDBNull(row.Cells("NumberOfOccupants").Value), "0", row.Cells("NumberOfOccupants").Value.ToString())
                txtOtherNames.Text = If(IsDBNull(row.Cells("OtherNames").Value), "", row.Cells("OtherNames").Value.ToString())
                dtpBirthday.Value = If(IsDBNull(row.Cells("Birthday").Value), DateTime.Today, CDate(row.Cells("Birthday").Value))
                dtpStartDate.Value = If(IsDBNull(row.Cells("StartDate").Value), DateTime.Today, CDate(row.Cells("StartDate").Value))
                dtpEndDate.Value = If(IsDBNull(row.Cells("EndDate").Value), DateTime.Today, CDate(row.Cells("EndDate").Value))
                txtRent.Text = row.Cells("BaseRent").Value.ToString()
                txtMeterNumber.Text = If(IsDBNull(row.Cells("MeterNumber").Value), "", row.Cells("MeterNumber").Value.ToString())

                cmbFloor.Enabled = False
                cmbRoom.Enabled = False

                If cmbFilterStatus.Text <> "Archived Tenants" Then
                    txtRent.ReadOnly = False
                Else
                    txtRent.ReadOnly = True
                End If

            Catch ex As Exception
            End Try
        End If
    End Sub

    Private Sub txtSearch_TextChanged(sender As Object, e As EventArgs) Handles txtSearch.TextChanged
        LoadTenants(txtSearch.Text)
    End Sub

    Private Sub btnRefresh_Click(sender As Object, e As EventArgs) Handles btnRefresh.Click
        LoadTenants()
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        ClearFields()
    End Sub

    Private Sub ClearFields()
        selectedTenantID = 0
        txtLast.Clear()
        txtFirst.Clear()
        txtMiddle.Clear()
        txtContact.Clear()
        txtEmail.Clear()
        txtRent.Clear()
        txtOccupants.Clear()
        txtOtherNames.Clear()
        txtMeterNumber.Clear()
        cmbFloor.Enabled = True
        cmbRoom.Enabled = True
        cmbFloor.SelectedIndex = -1
        cmbRoom.Items.Clear()
        dtpBirthday.Value = DateTime.Today
        dtpStartDate.Value = DateTime.Today
        dtpEndDate.Value = DateTime.Today
        txtRent.ReadOnly = True
    End Sub

End Class