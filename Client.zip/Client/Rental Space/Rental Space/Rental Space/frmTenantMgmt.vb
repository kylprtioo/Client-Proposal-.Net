﻿Imports System.Data.OleDb
Imports System.IO

Public Class frmTenantMgmt
    Public preSelectedRoom As String = ""
    Public selectedTenantID As Integer = 0

    Private Sub frmTenantMgmt_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        cmbFloor.Items.Clear()
        cmbFloor.Items.AddRange(New String() {"1st Floor", "2nd Floor", "3rd Floor", "4th Floor", "5th Floor"})

        dtpBirthday.MaxDate = DateTime.Today

        dgvTenants.AllowUserToAddRows = False
        dgvTenants.ReadOnly = True
        dgvTenants.SelectionMode = DataGridViewSelectionMode.FullRowSelect
        dgvTenants.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells

        txtMeterNumber.ReadOnly = True

        cmbFilterStatus.SelectedIndex = 0

        Dim tempID As Integer = selectedTenantID
        Dim tempRoom As String = preSelectedRoom

        LoadTenants()
        ClearFields()

        selectedTenantID = tempID
        preSelectedRoom = tempRoom

        If preSelectedRoom <> "" Then
            cmbRoom.Items.Add(preSelectedRoom)
            cmbRoom.Text = preSelectedRoom
            cmbRoom.Enabled = False
            cmbFloor.Enabled = False
        End If

        If selectedTenantID > 0 Then
            For i As Integer = 0 To dgvTenants.Rows.Count - 1
                If CInt(dgvTenants.Rows(i).Cells("TenantID").Value) = selectedTenantID Then
                    dgvTenants.Rows(i).Selected = True
                    dgvTenants_CellClick(dgvTenants, New DataGridViewCellEventArgs(0, i))
                    Exit For
                End If
            Next
        End If
    End Sub

    Private Sub cmbFilterStatus_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbFilterStatus.SelectedIndexChanged
        ClearFields()
        LoadTenants()

        If cmbFilterStatus.Text = "History (Checked-out)" Then
            btnSave.Enabled = False
            btnUpdate.Enabled = False
            btnCheckout.Enabled = False
            lblTitle.Text = "TENANT HISTORY"
            lblTitle.ForeColor = Color.IndianRed
        Else
            lblTitle.Text = "TENANT MANAGEMENT"
            lblTitle.ForeColor = Color.FromArgb(31, 41, 55)
        End If
    End Sub

    Private Function GetCombinedFullName() As String
        Dim last As String = txtLast.Text.Trim()
        Dim first As String = txtFirst.Text.Trim()
        Dim middle As String = txtMiddle.Text.Trim()

        If middle = "" Then
            Return $"{last}, {first}".Trim()
        Else
            Return $"{last}, {first} {middle}".Trim()
        End If
    End Function

    Private Sub dtpStartDate_ValueChanged(sender As Object, e As EventArgs) Handles dtpStartDate.ValueChanged
        dtpEndDate.Value = dtpStartDate.Value.AddYears(1)
    End Sub

    Private Sub cmbFloor_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbFloor.SelectedIndexChanged
        If cmbFloor.SelectedIndex <> -1 Then
            LoadRoomsByFloor(cmbFloor.Text)
        End If
    End Sub

    Private Sub LoadRoomsByFloor(floorName As String)
        If String.IsNullOrEmpty(floorName) Then Exit Sub
        cmbRoom.Items.Clear()
        Try
            Dim floorPrefix As String = floorName.Substring(0, 1)
            Using myConn As New OleDbConnection(ConnectionString)
                myConn.Open()
                Dim sql As String = "SELECT RoomNumber FROM tblRooms WHERE Status = 'Available' AND RoomNumber LIKE @prefix"
                Dim cmd As New OleDbCommand(sql, myConn)
                cmd.Parameters.AddWithValue("@prefix", floorPrefix & "%")
                Dim reader = cmd.ExecuteReader()
                While reader.Read()
                    cmbRoom.Items.Add(reader("RoomNumber").ToString())
                End While
            End Using
        Catch ex As Exception
        End Try
    End Sub

    Private Sub cmbRoom_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbRoom.SelectedIndexChanged
        If cmbRoom.SelectedIndex <> -1 Then
            Using myConn As New OleDbConnection(ConnectionString)
                Try
                    myConn.Open()
                    Dim sql As String = "SELECT BaseRent, MeterNumber FROM tblRooms WHERE RoomNumber = @rnum"
                    Dim cmd As New OleDbCommand(sql, myConn)
                    cmd.Parameters.AddWithValue("@rnum", cmbRoom.Text)
                    Dim reader = cmd.ExecuteReader()

                    If reader.Read() Then
                        If Not IsDBNull(reader("BaseRent")) Then
                            txtRent.Text = Convert.ToDecimal(reader("BaseRent")).ToString("0.00")
                        End If
                        If Not IsDBNull(reader("MeterNumber")) Then
                            txtMeterNumber.Text = reader("MeterNumber").ToString()
                        Else
                            txtMeterNumber.Clear()
                        End If
                    End If
                Catch ex As Exception
                End Try
            End Using
        End If
    End Sub

    Private Function ValidateRoomCapacity(roomNumber As String, occupants As Integer) As Boolean
        Dim capacity As Integer = 0
        Using myConn As New OleDbConnection(ConnectionString)
            Try
                myConn.Open()
                Dim cmd As New OleDbCommand("SELECT RoomCapacity FROM tblRooms WHERE RoomNumber = @rnum", myConn)
                cmd.Parameters.AddWithValue("@rnum", roomNumber)
                Dim capObj = cmd.ExecuteScalar()
                If capObj IsNot Nothing AndAlso Not IsDBNull(capObj) Then
                    capacity = Convert.ToInt32(capObj)
                End If
            Catch ex As Exception
            End Try
        End Using

        If capacity > 0 AndAlso occupants > capacity Then
            MsgBox($"Cannot proceed. The maximum capacity for Room {roomNumber} is {capacity} occupants only.", MsgBoxStyle.Exclamation, "Capacity Limit Exceeded")
            Return False
        End If
        Return True
    End Function

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        If txtLast.Text = "" Or txtFirst.Text = "" Or cmbRoom.Text = "" Then
            MsgBox("Please provide the complete Name and Room Assignment.", MsgBoxStyle.Exclamation)
            Exit Sub
        End If

        If txtContact.Text.Trim() = "" Or txtEmail.Text.Trim() = "" Then
            MsgBox("Please provide both Contact Number and Email Address.", MsgBoxStyle.Exclamation)
            Exit Sub
        End If

        If dtpStartDate.Value.Date < DateTime.Today Then
            MsgBox("Start Date cannot be in the past. Please select today's date or a future date.", MsgBoxStyle.Exclamation)
            Exit Sub
        End If

        If dtpStartDate.Value.Date > DateTime.Today.AddYears(3) Then
            MsgBox("Start Date is too far in advance. You can only set it up to 3 years from today.", MsgBoxStyle.Exclamation)
            Exit Sub
        End If

        If dtpEndDate.Value.Date <= dtpStartDate.Value.Date Then
            MsgBox("End Date must be later than the Start Date.", MsgBoxStyle.Exclamation)
            Exit Sub
        End If


        If dtpEndDate.Value.Date > dtpStartDate.Value.AddYears(3) Then
            MsgBox("The End Date can only be up to a maximum of 3 years from the Start Date.", MsgBoxStyle.Exclamation)
            Exit Sub
        End If

        Dim age As Integer = DateTime.Today.Year - dtpBirthday.Value.Year
        If dtpBirthday.Value.Date > DateTime.Today.AddYears(-age) Then age -= 1
        If age < 18 Then
            MsgBox("The tenant must be at least 18 years old.", MsgBoxStyle.Exclamation)
            Exit Sub
        End If

        Dim occupants As Integer = If(txtOccupants.Text = "", 0, Val(txtOccupants.Text))
        If Not ValidateRoomCapacity(cmbRoom.Text, occupants) Then Exit Sub

        Using myConn As New OleDbConnection(ConnectionString)
            Try
                myConn.Open()


                Dim cmdDup As New OleDbCommand("SELECT COUNT(*) FROM tblTenants WHERE Status = 'Active' AND (ContactNo = @cont OR (EmailAddress = @email AND EmailAddress <> ''))", myConn)
                cmdDup.Parameters.AddWithValue("@cont", txtContact.Text.Trim())
                cmdDup.Parameters.AddWithValue("@email", txtEmail.Text.Trim())

                If Convert.ToInt32(cmdDup.ExecuteScalar()) > 0 Then
                    MsgBox("An active tenant with the same Contact Number or Email Address already exists. Duplicates are not allowed.", MsgBoxStyle.Exclamation)
                    Exit Sub
                End If

                Dim trans = myConn.BeginTransaction()

                Dim cmdId As New OleDbCommand("SELECT RoomID FROM tblRooms WHERE RoomNumber = @rnum", myConn, trans)
                cmdId.Parameters.AddWithValue("@rnum", cmbRoom.Text)
                Dim rID = cmdId.ExecuteScalar()

                Dim sql As String = "INSERT INTO tblTenants (FullName, ContactNo, EmailAddress, Birthday, StartDate, EndDate, NumberOfOccupants, OtherNames, RoomID, BaseRent, Status) " &
                                    "VALUES (@name, @cont, @email, @bday, @sdate, @edate, @occu, @others, @rid, @rent, 'Active')"

                Dim cmd As New OleDbCommand(sql, myConn, trans)
                cmd.Parameters.AddWithValue("@name", GetCombinedFullName())
                cmd.Parameters.AddWithValue("@cont", txtContact.Text.Trim())
                cmd.Parameters.AddWithValue("@email", txtEmail.Text.Trim())
                cmd.Parameters.AddWithValue("@bday", dtpBirthday.Value.ToShortDateString())
                cmd.Parameters.AddWithValue("@sdate", dtpStartDate.Value.ToShortDateString())
                cmd.Parameters.AddWithValue("@edate", dtpEndDate.Value.ToShortDateString())
                cmd.Parameters.AddWithValue("@occu", occupants)
                cmd.Parameters.AddWithValue("@others", txtOtherNames.Text.Trim())
                cmd.Parameters.AddWithValue("@rid", rID)
                cmd.Parameters.AddWithValue("@rent", CDec(txtRent.Text))
                cmd.ExecuteNonQuery()

                Dim cmdUpdateRoom As New OleDbCommand("UPDATE tblRooms SET Status = 'Occupied' WHERE RoomID = @rid", myConn, trans)
                cmdUpdateRoom.Parameters.AddWithValue("@rid", rID)
                cmdUpdateRoom.ExecuteNonQuery()

                trans.Commit()
                MsgBox("Tenant registered successfully!", MsgBoxStyle.Information)
                ClearFields()
                LoadTenants()
            Catch ex As Exception
                MsgBox("Save Error: " & ex.Message)
            End Try
        End Using
    End Sub

    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        If selectedTenantID = 0 Then
            MsgBox("Please select a tenant from the list first.")
            Exit Sub
        End If

        If dtpEndDate.Value.Date <= dtpStartDate.Value.Date Then
            MsgBox("End Date must be later than the Start Date.", MsgBoxStyle.Exclamation)
            Exit Sub
        End If


        If dtpEndDate.Value.Date > dtpStartDate.Value.AddYears(3) Then
            MsgBox("The End Date can only be up to a maximum of 3 years from the Start Date.", MsgBoxStyle.Exclamation)
            Exit Sub
        End If

        Dim age As Integer = DateTime.Today.Year - dtpBirthday.Value.Year
        If dtpBirthday.Value.Date > DateTime.Today.AddYears(-age) Then age -= 1
        If age < 18 Then
            MsgBox("The tenant must be at least 18 years old.", MsgBoxStyle.Exclamation)
            Exit Sub
        End If

        Dim occupants As Integer = If(txtOccupants.Text = "", 0, Val(txtOccupants.Text))
        If Not ValidateRoomCapacity(cmbRoom.Text, occupants) Then Exit Sub

        Using myConn As New OleDbConnection(ConnectionString)
            Try
                myConn.Open()


                Dim cmdDup As New OleDbCommand("SELECT COUNT(*) FROM tblTenants WHERE Status = 'Active' AND TenantID <> @id AND (ContactNo = @cont OR (EmailAddress = @email AND EmailAddress <> ''))", myConn)
                cmdDup.Parameters.AddWithValue("@id", selectedTenantID)
                cmdDup.Parameters.AddWithValue("@cont", txtContact.Text.Trim())
                cmdDup.Parameters.AddWithValue("@email", txtEmail.Text.Trim())

                If Convert.ToInt32(cmdDup.ExecuteScalar()) > 0 Then
                    MsgBox("Another active tenant with the same Contact Number or Email Address already exists. Duplicates are not allowed.", MsgBoxStyle.Exclamation)
                    Exit Sub
                End If

                Dim trans = myConn.BeginTransaction()

                Dim cmdGetOld As New OleDbCommand("SELECT RoomID FROM tblTenants WHERE TenantID = @id", myConn, trans)
                cmdGetOld.Parameters.AddWithValue("@id", selectedTenantID)
                Dim oldRoomID = Convert.ToInt32(cmdGetOld.ExecuteScalar())

                Dim cmdGetNew As New OleDbCommand("SELECT RoomID FROM tblRooms WHERE RoomNumber = @rnum", myConn, trans)
                cmdGetNew.Parameters.AddWithValue("@rnum", cmbRoom.Text)
                Dim newRoomID = Convert.ToInt32(cmdGetNew.ExecuteScalar())

                If oldRoomID <> newRoomID Then
                    Dim cmdOld As New OleDbCommand("UPDATE tblRooms SET Status = 'Needs Cleaning' WHERE RoomID = @rid", myConn, trans)
                    cmdOld.Parameters.AddWithValue("@rid", oldRoomID)
                    cmdOld.ExecuteNonQuery()

                    Dim cmdNew As New OleDbCommand("UPDATE tblRooms SET Status = 'Occupied' WHERE RoomID = @rid", myConn, trans)
                    cmdNew.Parameters.AddWithValue("@rid", newRoomID)
                    cmdNew.ExecuteNonQuery()
                End If

                Dim sql As String = "UPDATE tblTenants SET FullName=@name, ContactNo=@cont, EmailAddress=@email, Birthday=@bday, StartDate=@sdate, EndDate=@edate, NumberOfOccupants=@occu, OtherNames=@others, RoomID=@newrid, BaseRent=@rent " &
                                    "WHERE TenantID=@id"
                Dim cmd As New OleDbCommand(sql, myConn, trans)
                cmd.Parameters.AddWithValue("@name", GetCombinedFullName())
                cmd.Parameters.AddWithValue("@cont", txtContact.Text.Trim())
                cmd.Parameters.AddWithValue("@email", txtEmail.Text.Trim())
                cmd.Parameters.AddWithValue("@bday", dtpBirthday.Value.ToShortDateString())
                cmd.Parameters.AddWithValue("@sdate", dtpStartDate.Value.ToShortDateString())
                cmd.Parameters.AddWithValue("@edate", dtpEndDate.Value.ToShortDateString())
                cmd.Parameters.AddWithValue("@occu", occupants)
                cmd.Parameters.AddWithValue("@others", txtOtherNames.Text.Trim())
                cmd.Parameters.AddWithValue("@newrid", newRoomID)
                cmd.Parameters.AddWithValue("@rent", CDec(txtRent.Text))
                cmd.Parameters.AddWithValue("@id", selectedTenantID)
                cmd.ExecuteNonQuery()

                trans.Commit()

                MsgBox("Record updated successfully!", MsgBoxStyle.Information)
                ClearFields()
                LoadTenants()
            Catch ex As Exception
                MsgBox("Update Error: " & ex.Message)
            End Try
        End Using
    End Sub

    Private Sub btnCheckout_Click(sender As Object, e As EventArgs) Handles btnCheckout.Click
        If selectedTenantID = 0 Then Exit Sub

        Using myConn As New OleDbConnection(ConnectionString)
            Try
                myConn.Open()

                Dim sqlCheckBal As String = "SELECT SUM(Balance) FROM tblBillings WHERE TenantID = @tid AND (IsPaid IN ('No', 'Partial') OR Balance > 0)"
                Dim cmdCheck As New OleDbCommand(sqlCheckBal, myConn)
                cmdCheck.Parameters.AddWithValue("@tid", selectedTenantID)

                Dim totalBalance As Object = cmdCheck.ExecuteScalar()
                Dim balAmount As Decimal = If(IsDBNull(totalBalance), 0, Convert.ToDecimal(totalBalance))

                If balAmount > 0 Then
                    MsgBox("CHECKOUT BLOCKED." & vbCrLf & vbCrLf &
                           "This tenant still has an outstanding balance of ₱" & balAmount.ToString("N2") & "." & vbCrLf &
                           "Please settle all billings before proceeding with checkout.", MsgBoxStyle.Critical, "Action Denied")
                    Exit Sub
                End If

                Dim ans = MsgBox("Are you sure you want to proceed with Check-out? The tenant will be moved to History.", MsgBoxStyle.YesNo + MsgBoxStyle.Question, "Confirm Check-out")
                If ans = MsgBoxResult.Yes Then
                    Dim trans = myConn.BeginTransaction()

                    Dim cmd1 = New OleDbCommand("UPDATE tblTenants SET Status = 'Archived' WHERE TenantID = @id", myConn, trans)
                    cmd1.Parameters.AddWithValue("@id", selectedTenantID)
                    cmd1.ExecuteNonQuery()

                    Dim cmd2 = New OleDbCommand("UPDATE tblRooms SET Status = 'Needs Cleaning' WHERE RoomID = (SELECT RoomID FROM tblTenants WHERE TenantID = @id)", myConn, trans)
                    cmd2.Parameters.AddWithValue("@id", selectedTenantID)
                    cmd2.ExecuteNonQuery()

                    trans.Commit()
                    MsgBox("Tenant checked out successfully.", MsgBoxStyle.Information)
                    ClearFields()
                    LoadTenants()
                End If
            Catch ex As Exception
                MsgBox("Checkout Error: " & ex.Message)
            End Try
        End Using
    End Sub

    Private Sub LoadTenants(Optional searchTerm As String = "")
        Using myConn As New OleDbConnection(ConnectionString)
            Try
                dgvTenants.DataSource = Nothing

                Dim statusFilter As String = If(cmbFilterStatus.Text = "History (Checked-out)", "Archived", "Active")

                Dim sql As String = "SELECT t.*, r.MeterNumber, r.RoomNumber FROM tblTenants t INNER JOIN tblRooms r ON t.RoomID = r.RoomID WHERE t.Status = '" & statusFilter & "'"
                If searchTerm <> "" Then sql &= " AND t.FullName LIKE '%" & searchTerm & "%'"

                Dim adapter As New OleDbDataAdapter(sql, myConn)
                Dim dt As New DataTable
                adapter.Fill(dt)
                dgvTenants.DataSource = dt
            Catch ex As Exception
            End Try
        End Using
    End Sub

    Private Sub dgvTenants_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgvTenants.CellClick
        If e.RowIndex >= 0 Then
            Try
                Dim row = dgvTenants.Rows(e.RowIndex)
                selectedTenantID = CInt(row.Cells("TenantID").Value)

                Dim full As String = row.Cells("FullName").Value.ToString()
                txtLast.Clear()
                txtFirst.Clear()
                txtMiddle.Clear()

                If full.Contains(",") Then
                    Dim parts() As String = full.Split(","c)
                    txtLast.Text = parts(0).Trim()

                    Dim firstMid As String = parts(1).Trim()
                    Dim nameParts() As String = firstMid.Split(New Char() {" "c}, StringSplitOptions.RemoveEmptyEntries)

                    If nameParts.Length = 1 Then
                        txtFirst.Text = nameParts(0)
                    ElseIf nameParts.Length > 1 Then
                        txtMiddle.Text = nameParts(nameParts.Length - 1)
                        txtFirst.Text = String.Join(" ", nameParts, 0, nameParts.Length - 1)
                    End If
                Else
                    txtLast.Text = full
                End If

                txtContact.Text = row.Cells("ContactNo").Value.ToString()
                txtEmail.Text = If(IsDBNull(row.Cells("EmailAddress").Value), "", row.Cells("EmailAddress").Value.ToString())
                txtOccupants.Text = If(IsDBNull(row.Cells("NumberOfOccupants").Value), "0", row.Cells("NumberOfOccupants").Value.ToString())
                txtOtherNames.Text = If(IsDBNull(row.Cells("OtherNames").Value), "", row.Cells("OtherNames").Value.ToString())
                dtpBirthday.Value = If(IsDBNull(row.Cells("Birthday").Value), DateTime.Today, CDate(row.Cells("Birthday").Value))
                dtpStartDate.Value = If(IsDBNull(row.Cells("StartDate").Value), DateTime.Today, CDate(row.Cells("StartDate").Value))
                dtpEndDate.Value = If(IsDBNull(row.Cells("EndDate").Value), DateTime.Today, CDate(row.Cells("EndDate").Value))
                txtRent.Text = row.Cells("BaseRent").Value.ToString()
                txtMeterNumber.Text = If(IsDBNull(row.Cells("MeterNumber").Value), "", row.Cells("MeterNumber").Value.ToString())

                Dim currentRoom As String = row.Cells("RoomNumber").Value.ToString()
                Dim floorChar As String = currentRoom.Substring(0, 1)
                Dim floorIndex As Integer = CInt(floorChar) - 1

                cmbFloor.Enabled = True
                cmbRoom.Enabled = True

                If floorIndex >= 0 AndAlso floorIndex < cmbFloor.Items.Count Then
                    cmbFloor.SelectedIndex = floorIndex
                End If

                If Not cmbRoom.Items.Contains(currentRoom) Then
                    cmbRoom.Items.Add(currentRoom)
                End If
                cmbRoom.Text = currentRoom

                If cmbFilterStatus.Text <> "History (Checked-out)" Then
                    txtRent.ReadOnly = False
                    btnSave.Enabled = False
                    btnUpdate.Enabled = True
                    btnCheckout.Enabled = True
                Else
                    txtRent.ReadOnly = True
                    cmbFloor.Enabled = False
                    cmbRoom.Enabled = False
                    btnSave.Enabled = False
                    btnUpdate.Enabled = False
                    btnCheckout.Enabled = False
                End If

            Catch ex As Exception
            End Try
        End If
    End Sub

    Private Sub txtSearch_TextChanged(sender As Object, e As EventArgs) Handles txtSearch.TextChanged
        LoadTenants(txtSearch.Text)
    End Sub

    Private Sub btnRefresh_Click(sender As Object, e As EventArgs) Handles btnRefresh.Click
        LoadTenants()
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        ClearFields()
    End Sub

    Private Sub ClearFields()
        selectedTenantID = 0
        txtLast.Clear()
        txtFirst.Clear()
        txtMiddle.Clear()
        txtContact.Clear()
        txtEmail.Clear()
        txtRent.Clear()
        txtOccupants.Clear()
        txtOtherNames.Clear()
        txtMeterNumber.Clear()
        cmbFloor.Enabled = True
        cmbRoom.Enabled = True
        cmbFloor.SelectedIndex = -1
        cmbRoom.Items.Clear()
        dtpBirthday.Value = DateTime.Today
        dtpStartDate.Value = DateTime.Today
        dtpEndDate.Value = DateTime.Today.AddYears(1)
        txtRent.ReadOnly = True

        If cmbFilterStatus.Text <> "History (Checked-out)" Then
            btnSave.Enabled = True
            btnUpdate.Enabled = False
            btnCheckout.Enabled = False
        End If
    End Sub

End Class