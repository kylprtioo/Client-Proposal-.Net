﻿Imports System.Data.OleDb
Imports System.IO

Public Class frmTenantMgmt
    Dim selectedTenantID As Integer = 0

    Private Sub frmTenantMgmt_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        cmbFloor.Items.Clear()
        cmbFloor.Items.AddRange(New String() {"1st Floor", "2nd Floor", "3rd Floor", "4th Floor", "5th Floor"})

        dtpBirthday.MaxDate = DateTime.Today

        dgvTenants.AllowUserToAddRows = False
        dgvTenants.ReadOnly = True
        dgvTenants.SelectionMode = DataGridViewSelectionMode.FullRowSelect

        ToggleVehicleFields(False)

        LoadTenants()
        ClearFields()
    End Sub

    Private Function GetCombinedFullName() As String
        Dim last As String = txtLast.Text.Trim()
        Dim first As String = txtFirst.Text.Trim()
        Dim middle As String = txtMiddle.Text.Trim()

        If middle = "" Then
            Return $"{last}, {first}".Trim()
        Else
            Return $"{last}, {first} {middle}".Trim()
        End If
    End Function

    Private Sub ToggleVehicleFields(isEnabled As Boolean)
        txtVehicleModel.Enabled = isEnabled
        txtYearColor.Enabled = isEnabled
        txtPlateNo.Enabled = isEnabled
        If Not isEnabled Then
            txtVehicleModel.Clear()
            txtYearColor.Clear()
            txtPlateNo.Clear()
        End If
    End Sub

    Private Sub chkVehicle_CheckedChanged(sender As Object, e As EventArgs) Handles chkVehicle.CheckedChanged
        ToggleVehicleFields(chkVehicle.Checked)
    End Sub

    Private Sub cmbFloor_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbFloor.SelectedIndexChanged
        If cmbFloor.SelectedIndex <> -1 Then
            LoadRoomsByFloor(cmbFloor.Text)
        End If
    End Sub

    Private Sub LoadRoomsByFloor(floorName As String)
        If String.IsNullOrEmpty(floorName) Then Exit Sub
        cmbRoom.Items.Clear()
        Try
            Dim floorPrefix As String = floorName.Substring(0, 1)
            Using myConn As New OleDbConnection(connString)
                myConn.Open()
                Dim sql As String = "SELECT RoomNumber FROM tblRooms WHERE Status = 'Available' AND RoomNumber LIKE @prefix"
                Dim cmd As New OleDbCommand(sql, myConn)
                cmd.Parameters.AddWithValue("@prefix", floorPrefix & "%")
                Dim reader = cmd.ExecuteReader()
                While reader.Read()
                    cmbRoom.Items.Add(reader("RoomNumber").ToString())
                End While
            End Using
        Catch ex As Exception
        End Try
    End Sub

    Private Sub cmbRoom_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbRoom.SelectedIndexChanged
        If cmbRoom.SelectedIndex <> -1 Then
            Using myConn As New OleDbConnection(connString)
                Try
                    myConn.Open()
                    Dim sql As String = "SELECT BaseRent FROM tblRooms WHERE RoomNumber = @rnum"
                    Dim cmd As New OleDbCommand(sql, myConn)
                    cmd.Parameters.AddWithValue("@rnum", cmbRoom.Text)
                    Dim rentObj = cmd.ExecuteScalar()

                    If rentObj IsNot Nothing AndAlso Not IsDBNull(rentObj) Then
                        txtRent.Text = Convert.ToDecimal(rentObj).ToString("0.00")
                    End If
                Catch ex As Exception
                End Try
            End Using
        End If
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        If txtLast.Text = "" Or txtFirst.Text = "" Or cmbRoom.Text = "" Then
            MsgBox("Pakilagay ang kumpletong Pangalan at Room Assignment.", MsgBoxStyle.Exclamation)
            Exit Sub
        End If

        Using myConn As New OleDbConnection(connString)
            Try
                myConn.Open()
                Dim trans = myConn.BeginTransaction()

                Dim cmdId As New OleDbCommand("SELECT RoomID FROM tblRooms WHERE RoomNumber = @rnum", myConn, trans)
                cmdId.Parameters.AddWithValue("@rnum", cmbRoom.Text)
                Dim rID = cmdId.ExecuteScalar()

                Dim sql As String = "INSERT INTO tblTenants (FullName, ContactNo, EmailAddress, Birthday, StartDate, NumberOfOccupants, HasPet, HasVehicle, VehicleModel, VehicleYearColor, PlateNumber, RoomID, BaseRent, Status) " &
                                   "VALUES (@name, @cont, @email, @bday, @sdate, @occu, @pet, @veh, @model, @yrcolor, @plate, @rid, @rent, 'Active')"

                Dim cmd As New OleDbCommand(sql, myConn, trans)
                cmd.Parameters.AddWithValue("@name", GetCombinedFullName())
                cmd.Parameters.AddWithValue("@cont", txtContact.Text)
                cmd.Parameters.AddWithValue("@email", txtEmail.Text.Trim())
                cmd.Parameters.AddWithValue("@bday", dtpBirthday.Value.ToShortDateString())
                cmd.Parameters.AddWithValue("@sdate", dtpStartDate.Value.ToShortDateString())
                cmd.Parameters.AddWithValue("@occu", If(txtOccupants.Text = "", 0, Val(txtOccupants.Text)))
                cmd.Parameters.AddWithValue("@pet", If(chkPet.Checked, "Yes", "No"))
                cmd.Parameters.AddWithValue("@veh", If(chkVehicle.Checked, "Yes", "No"))
                cmd.Parameters.AddWithValue("@model", txtVehicleModel.Text)
                cmd.Parameters.AddWithValue("@yrcolor", txtYearColor.Text)
                cmd.Parameters.AddWithValue("@plate", txtPlateNo.Text)
                cmd.Parameters.AddWithValue("@rid", rID)
                cmd.Parameters.AddWithValue("@rent", CDec(txtRent.Text))
                cmd.ExecuteNonQuery()

                Dim cmdUpdateRoom As New OleDbCommand("UPDATE tblRooms SET Status = 'Occupied' WHERE RoomID = @rid", myConn, trans)
                cmdUpdateRoom.Parameters.AddWithValue("@rid", rID)
                cmdUpdateRoom.ExecuteNonQuery()

                trans.Commit()
                MsgBox("Tenant registered successfully!", MsgBoxStyle.Information)
                LoadTenants()
                ClearFields()
            Catch ex As Exception
                MsgBox("Save Error: " & ex.Message)
            End Try
        End Using
    End Sub

    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        If selectedTenantID = 0 Then
            MsgBox("Pumili muna ng tenant sa listahan.")
            Exit Sub
        End If

        Using myConn As New OleDbConnection(connString)
            Try
                myConn.Open()
                Dim sql As String = "UPDATE tblTenants SET FullName=@name, ContactNo=@cont, EmailAddress=@email, Birthday=@bday, StartDate=@sdate, NumberOfOccupants=@occu, HasPet=@pet, " &
                                   "HasVehicle=@veh, VehicleModel=@model, VehicleYearColor=@yrcolor, PlateNumber=@plate, BaseRent=@rent " &
                                   "WHERE TenantID=@id"
                Dim cmd As New OleDbCommand(sql, myConn)
                cmd.Parameters.AddWithValue("@name", GetCombinedFullName())
                cmd.Parameters.AddWithValue("@cont", txtContact.Text)
                cmd.Parameters.AddWithValue("@email", txtEmail.Text.Trim())
                cmd.Parameters.AddWithValue("@bday", dtpBirthday.Value.ToShortDateString())
                cmd.Parameters.AddWithValue("@sdate", dtpStartDate.Value.ToShortDateString())
                cmd.Parameters.AddWithValue("@occu", Val(txtOccupants.Text))
                cmd.Parameters.AddWithValue("@pet", If(chkPet.Checked, "Yes", "No"))
                cmd.Parameters.AddWithValue("@veh", If(chkVehicle.Checked, "Yes", "No"))
                cmd.Parameters.AddWithValue("@model", txtVehicleModel.Text)
                cmd.Parameters.AddWithValue("@yrcolor", txtYearColor.Text)
                cmd.Parameters.AddWithValue("@plate", txtPlateNo.Text)
                cmd.Parameters.AddWithValue("@rent", CDec(txtRent.Text))
                cmd.Parameters.AddWithValue("@id", selectedTenantID)
                cmd.ExecuteNonQuery()

                MsgBox("Record updated!", MsgBoxStyle.Information)
                LoadTenants()
                ClearFields()
            Catch ex As Exception
                MsgBox("Update Error: " & ex.Message)
            End Try
        End Using
    End Sub

    Private Sub btnCheckout_Click(sender As Object, e As EventArgs) Handles btnCheckout.Click
        If selectedTenantID = 0 Then Exit Sub
        Dim ans = MsgBox("Confirm Check-out?", MsgBoxStyle.YesNo + MsgBoxStyle.Question)
        If ans = MsgBoxResult.Yes Then
            Using myConn As New OleDbConnection(connString)
                Try
                    myConn.Open()
                    Dim trans = myConn.BeginTransaction()
                    Dim cmd1 = New OleDbCommand("UPDATE tblTenants SET Status = 'Inactive' WHERE TenantID = @id", myConn, trans)
                    cmd1.Parameters.AddWithValue("@id", selectedTenantID)
                    cmd1.ExecuteNonQuery()

                    Dim cmd2 = New OleDbCommand("UPDATE tblRooms SET Status = 'Needs Cleaning' WHERE RoomID = (SELECT RoomID FROM tblTenants WHERE TenantID = @id)", myConn, trans)
                    cmd2.Parameters.AddWithValue("@id", selectedTenantID)
                    cmd2.ExecuteNonQuery()

                    trans.Commit()
                    MsgBox("Tenant checked out.")
                    LoadTenants()
                    ClearFields()
                Catch ex As Exception
                    MsgBox(ex.Message)
                End Try
            End Using
        End If
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        If selectedTenantID = 0 Then Exit Sub
        If MsgBox("Permanent Delete?", MsgBoxStyle.Critical + MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
            Using myConn As New OleDbConnection(connString)
                Try
                    myConn.Open()
                    Dim cmdR = New OleDbCommand("UPDATE tblRooms SET Status = 'Available' WHERE RoomID = (SELECT RoomID FROM tblTenants WHERE TenantID = @id)", myConn)
                    cmdR.Parameters.AddWithValue("@id", selectedTenantID)
                    cmdR.ExecuteNonQuery()

                    Dim cmdD = New OleDbCommand("DELETE FROM tblTenants WHERE TenantID = @id", myConn)
                    cmdD.Parameters.AddWithValue("@id", selectedTenantID)
                    cmdD.ExecuteNonQuery()

                    MsgBox("Deleted.")
                    LoadTenants()
                    ClearFields()
                Catch ex As Exception
                End Try
            End Using
        End If
    End Sub

    Private Sub LoadTenants(Optional searchTerm As String = "")
        Using myConn As New OleDbConnection(connString)
            Try
                dgvTenants.DataSource = Nothing
                Dim sql As String = "SELECT * FROM tblTenants WHERE Status LIKE 'Active%'"
                If searchTerm <> "" Then sql &= " AND FullName LIKE '%" & searchTerm & "%'"
                Dim adapter As New OleDbDataAdapter(sql, myConn)
                Dim dt As New DataTable
                adapter.Fill(dt)
                dgvTenants.DataSource = dt
            Catch ex As Exception
            End Try
        End Using
    End Sub

    Private Sub dgvTenants_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgvTenants.CellClick
        If e.RowIndex >= 0 Then
            Try
                Dim row = dgvTenants.Rows(e.RowIndex)
                selectedTenantID = CInt(row.Cells("TenantID").Value)

                txtLast.Text = row.Cells("FullName").Value.ToString()
                txtFirst.Clear()
                txtMiddle.Clear()

                txtContact.Text = row.Cells("ContactNo").Value.ToString()
                txtEmail.Text = If(IsDBNull(row.Cells("EmailAddress").Value), "", row.Cells("EmailAddress").Value.ToString())
                txtOccupants.Text = If(IsDBNull(row.Cells("NumberOfOccupants").Value), "0", row.Cells("NumberOfOccupants").Value.ToString())
                dtpBirthday.Value = If(IsDBNull(row.Cells("Birthday").Value), DateTime.Today, CDate(row.Cells("Birthday").Value))
                dtpStartDate.Value = If(IsDBNull(row.Cells("StartDate").Value), DateTime.Today, CDate(row.Cells("StartDate").Value))
                txtRent.Text = row.Cells("BaseRent").Value.ToString()
                chkPet.Checked = (row.Cells("HasPet").Value.ToString() = "Yes")
                chkVehicle.Checked = (row.Cells("HasVehicle").Value.ToString() = "Yes")
                txtVehicleModel.Text = row.Cells("VehicleModel").Value.ToString()
                txtYearColor.Text = row.Cells("VehicleYearColor").Value.ToString()
                txtPlateNo.Text = row.Cells("PlateNumber").Value.ToString()

                cmbFloor.Enabled = False
                cmbRoom.Enabled = False

                txtRent.ReadOnly = False
            Catch ex As Exception
            End Try
        End If
    End Sub

    Private Sub txtSearch_TextChanged(sender As Object, e As EventArgs) Handles txtSearch.TextChanged
        LoadTenants(txtSearch.Text)
    End Sub

    Private Sub btnRefresh_Click(sender As Object, e As EventArgs) Handles btnRefresh.Click
        LoadTenants()
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        ClearFields()
    End Sub

    Private Sub ClearFields()
        selectedTenantID = 0
        txtLast.Clear()
        txtFirst.Clear()
        txtMiddle.Clear()
        txtContact.Clear()
        txtEmail.Clear()
        txtRent.Clear()
        txtOccupants.Clear()
        txtVehicleModel.Clear()
        txtYearColor.Clear()
        txtPlateNo.Clear()
        chkPet.Checked = False
        chkVehicle.Checked = False
        cmbFloor.Enabled = True
        cmbRoom.Enabled = True
        cmbFloor.SelectedIndex = -1
        cmbRoom.Items.Clear()
        dtpBirthday.Value = DateTime.Today
        dtpStartDate.Value = DateTime.Today
        txtRent.ReadOnly = True
    End Sub

End Class