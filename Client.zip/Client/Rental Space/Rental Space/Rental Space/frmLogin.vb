﻿Imports System.Data.OleDb

Public Class frmLogin
    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click
        Using myConn As New OleDbConnection(connString)
            Try
                Dim sql As String = "SELECT UserRole FROM tblUsers WHERE Username=@user AND [Password]=@pass"
                Dim cmd As New OleDbCommand(sql, myConn)

                cmd.Parameters.AddWithValue("@user", txtUsername.Text)
                cmd.Parameters.AddWithValue("@pass", txtPassword.Text)

                myConn.Open()
                Dim role As Object = cmd.ExecuteScalar()

                If role IsNot Nothing Then
                    currentUserRole = role.ToString()
                    currentUsername = txtUsername.Text

                    MsgBox("Login Successful! Welcome " & currentUsername, MsgBoxStyle.Information)

                    txtUsername.Clear()
                    txtPassword.Clear()

                    frmDashboard.Show()
                    Me.Hide()
                Else
                    MsgBox("Wrong Username or Password!", MsgBoxStyle.Critical)
                    txtPassword.Clear()
                    txtPassword.Focus()
                End If
            Catch ex As Exception
                MsgBox("System Error: " & ex.Message)
            End Try
        End Using
    End Sub

    Private Sub frmLogin_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.AcceptButton = btnLogin
    End Sub
End Class