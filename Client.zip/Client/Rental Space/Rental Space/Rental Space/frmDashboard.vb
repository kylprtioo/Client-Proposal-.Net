﻿Imports System.Data.OleDb

Public Class frmDashboard

    Private Sub frmDashboard_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        cmbFloorFilter.Items.Clear()
        cmbFloorFilter.Items.AddRange(New String() {"All Floors", "1st Floor", "2nd Floor", "3rd Floor", "4th Floor", "5th Floor"})
        cmbFloorFilter.SelectedIndex = 0

        ApplyRoleSecurity()
        RefreshDashboard()
    End Sub

    Private Sub cmbFloorFilter_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbFloorFilter.SelectedIndexChanged
        LoadRoomGrid()
    End Sub

    Private Sub LoadRoomGrid()
        flpRooms.Controls.Clear()

        Dim sql As String = "SELECT RoomNumber, Status FROM tblRooms "
        Dim floorPrefix As String = ""

        Select Case cmbFloorFilter.Text
            Case "1st Floor" : floorPrefix = "1"
            Case "2nd Floor" : floorPrefix = "2"
            Case "3rd Floor" : floorPrefix = "3"
            Case "4th Floor" : floorPrefix = "4"
            Case "5th Floor" : floorPrefix = "5"
            Case Else : floorPrefix = ""
        End Select

        If floorPrefix <> "" Then
            sql &= " WHERE RoomNumber LIKE '" & floorPrefix & "%' "
        End If

        sql &= " ORDER BY RoomNumber ASC"

        Using myConn As New OleDbConnection(ConnectionString)
            Try
                Dim cmd As New OleDbCommand(sql, myConn)
                myConn.Open()
                Dim reader = cmd.ExecuteReader()
                While reader.Read()
                    Dim btn As New Button
                    btn.Text = "ROOM " & reader("RoomNumber").ToString()
                    btn.Width = 100 : btn.Height = 100 : btn.Margin = New Padding(5)
                    btn.FlatStyle = FlatStyle.Flat : btn.Font = New Font("Segoe UI", 10, FontStyle.Bold)

                    Dim status As String = reader("Status").ToString().Trim().ToLower()

                    If status.Contains("avail") Then
                        btn.BackColor = Color.SeaGreen : btn.ForeColor = Color.White
                    ElseIf status = "occupied" Then
                        btn.BackColor = Color.IndianRed : btn.ForeColor = Color.White
                    ElseIf status.Contains("clean") Then
                        btn.BackColor = Color.Gold : btn.ForeColor = Color.Black
                    Else
                        btn.BackColor = Color.SeaGreen : btn.ForeColor = Color.White
                    End If

                    AddHandler btn.Click, AddressOf Room_Click
                    flpRooms.Controls.Add(btn)
                End While
            Catch ex As Exception
                MsgBox("Error loading rooms: " & ex.Message)
            End Try
        End Using
    End Sub

    Private Sub Room_Click(sender As Object, e As EventArgs)
        Dim role As String = currentUserRole.ToUpper().Trim()
        If role.Contains("GUARD") Or role.Contains("SECURITY") Then
            MsgBox("Access Denied: View only for Security Staff.", MsgBoxStyle.Exclamation)
            Exit Sub
        End If

        Dim clickedButton = DirectCast(sender, Button)
        Dim roomNum As String = clickedButton.Text.Replace("ROOM ", "")

        If clickedButton.BackColor = Color.SeaGreen Then
            Dim ans = MsgBox("Room " & roomNum & " is empty. Register a new tenant?", MsgBoxStyle.YesNo + MsgBoxStyle.Question)
            If ans = MsgBoxResult.Yes Then
                frmTenantMgmt.ShowDialog()
                RefreshDashboard()
            End If

        ElseIf clickedButton.BackColor = Color.IndianRed Then
            Dim ans = MsgBox("Room " & roomNum & " is Occupied. Generate billing for this tenant?", MsgBoxStyle.YesNo + MsgBoxStyle.Information)
            If ans = MsgBoxResult.Yes Then
                frmBilling.ShowDialog()
                RefreshDashboard()
            End If

        ElseIf clickedButton.BackColor = Color.Gold Then
            Dim ans = MsgBox("Is Room " & roomNum & " finished cleaning?", MsgBoxStyle.YesNo + MsgBoxStyle.Question)
            If ans = MsgBoxResult.Yes Then
                UpdateRoomStatus(roomNum, "Available")
            End If
        End If
    End Sub

    Private Sub btnTenantMgmt_Click(sender As Object, e As EventArgs) Handles btnTenantMgmt.Click
        frmTenantMgmt.ShowDialog()
        RefreshDashboard()
    End Sub

    Private Sub btnBilling_Click(sender As Object, e As EventArgs) Handles btnBilling.Click
        frmBilling.ShowDialog()
        RefreshDashboard()
    End Sub

    Private Sub btnReports_Click(sender As Object, e As EventArgs) Handles btnReports.Click
        frmReports.ShowDialog()
    End Sub

    Private Sub btnRoom_Click(sender As Object, e As EventArgs) Handles btnRoom.Click
        frmRoomDetails.ShowDialog()
    End Sub

    Private Sub btnAnnouncement_Click(sender As Object, e As EventArgs) Handles btnAnnouncement.Click
        frmAnnouncement.ShowDialog()
    End Sub

    Private Sub btnLogout_Click(sender As Object, e As EventArgs) Handles btnLogout.Click
        Dim ans = MsgBox("Are you sure you want to logout?", MsgBoxStyle.YesNo + MsgBoxStyle.Question)
        If ans = MsgBoxResult.Yes Then
            currentUsername = "" : currentUserRole = ""
            frmLogin.Show() : Me.Close()
        End If
    End Sub

    Private Sub RefreshDashboard()
        LoadRoomGrid()
        UpdateStats()
    End Sub

    Private Sub UpdateRoomStatus(roomNumber As String, newStatus As String)
        Using myConn As New OleDbConnection(ConnectionString)
            Try
                myConn.Open()
                Dim cmd As New OleDbCommand("UPDATE tblRooms SET [Status] = @stat WHERE [RoomNumber] = @rnum", myConn)
                cmd.Parameters.AddWithValue("@stat", newStatus)
                cmd.Parameters.AddWithValue("@rnum", roomNumber)
                cmd.ExecuteNonQuery()
                RefreshDashboard()
            Catch ex As Exception
                MsgBox("Status Update Error: " & ex.Message)
            End Try
        End Using
    End Sub

    Private Sub UpdateStats()
        Using myConn As New OleDbConnection(ConnectionString)
            Try
                myConn.Open()
                Dim cmdOcc = New OleDbCommand("SELECT COUNT(*) FROM tblRooms WHERE Status='Occupied'", myConn)
                lblOccupiedCount.Text = cmdOcc.ExecuteScalar().ToString()

                Dim cmdAvail = New OleDbCommand("SELECT COUNT(*) FROM tblRooms WHERE Status LIKE 'avail%'", myConn)
                lblAvailableCount.Text = cmdAvail.ExecuteScalar().ToString()

                Dim cmdClean = New OleDbCommand("SELECT COUNT(*) FROM tblRooms WHERE Status LIKE 'clean%' OR Status LIKE 'needs%'", myConn)
                lblCleaningCount.Text = cmdClean.ExecuteScalar().ToString()
            Catch ex As Exception
            End Try
        End Using
    End Sub

    Private Sub ApplyRoleSecurity()
        lblWelcome.Text = "User: " & currentUsername & " [" & currentUserRole & "]"

        Dim role As String = currentUserRole.ToUpper().Trim()

        If role.Contains("GUARD") Or role.Contains("SECURITY") Then
            btnBilling.Visible = False
            btnTenantMgmt.Visible = False
            btnReports.Visible = False
            btnRoom.Visible = False

            btnAnnouncement.Visible = True
        Else
            btnBilling.Visible = True
            btnTenantMgmt.Visible = True
            btnReports.Visible = True
            btnRoom.Visible = True
            btnAnnouncement.Visible = True
        End If
    End Sub

End Class