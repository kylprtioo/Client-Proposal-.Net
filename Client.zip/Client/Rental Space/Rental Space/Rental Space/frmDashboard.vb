﻿Imports System.Data.OleDb

Public Class frmDashboard

    Private Sub frmDashboard_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        cmbFloorFilter.Items.Clear()
        cmbFloorFilter.Items.AddRange(New String() {"All Floors", "1st Floor", "2nd Floor", "3rd Floor", "4th Floor", "5th Floor"})
        cmbFloorFilter.SelectedIndex = 0

        ApplyRoleSecurity()
        RefreshDashboard()
    End Sub

    Private Sub cmbFloorFilter_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbFloorFilter.SelectedIndexChanged
        LoadRoomGrid()
    End Sub

    Private Sub LoadRoomGrid()
        flpRooms.Controls.Clear()

        Dim sql As String = "SELECT RoomNumber, Status FROM tblRooms "
        Dim floorPrefix As String = ""

        Select Case cmbFloorFilter.Text
            Case "1st Floor" : floorPrefix = "1"
            Case "2nd Floor" : floorPrefix = "2"
            Case "3rd Floor" : floorPrefix = "3"
            Case "4th Floor" : floorPrefix = "4"
            Case "5th Floor" : floorPrefix = "5"
            Case Else : floorPrefix = ""
        End Select

        If floorPrefix <> "" Then
            sql &= " WHERE RoomNumber LIKE '" & floorPrefix & "%' "
        End If

        sql &= " ORDER BY RoomNumber ASC"

        Using myConn As New OleDbConnection(ConnectionString)
            Try
                Dim cmd As New OleDbCommand(sql, myConn)
                myConn.Open()
                Dim reader = cmd.ExecuteReader()
                While reader.Read()
                    Dim btn As New Button
                    Dim rNum As String = reader("RoomNumber").ToString()
                    btn.Width = 100 : btn.Height = 100 : btn.Margin = New Padding(5)
                    btn.FlatStyle = FlatStyle.Flat : btn.Font = New Font("Segoe UI", 10, FontStyle.Bold)

                    Dim status As String = reader("Status").ToString().Trim().ToLower()

                    If status = "available" Then
                        btn.Text = "ROOM " & rNum
                        btn.BackColor = Color.SeaGreen : btn.ForeColor = Color.White
                    ElseIf status = "occupied - needs cleaning" Then
                        btn.Text = "ROOM " & rNum & vbCrLf & "(Clean)"
                        btn.BackColor = Color.IndianRed : btn.ForeColor = Color.Yellow
                    ElseIf status.Contains("occupied") Then
                        btn.Text = "ROOM " & rNum
                        btn.BackColor = Color.IndianRed : btn.ForeColor = Color.White
                    ElseIf status.Contains("clean") Or status.Contains("need") Then
                        btn.Text = "ROOM " & rNum
                        btn.BackColor = Color.Gold : btn.ForeColor = Color.Black
                    Else
                        btn.Text = "ROOM " & rNum
                        btn.BackColor = Color.SeaGreen : btn.ForeColor = Color.White
                    End If

                    AddHandler btn.Click, AddressOf Room_Click
                    flpRooms.Controls.Add(btn)
                End While
            Catch ex As Exception
            End Try
        End Using
    End Sub

    Private Sub Room_Click(sender As Object, e As EventArgs)
        Dim role As String = currentUserRole.ToUpper().Trim()
        Dim isGuard As Boolean = role.Contains("GUARD") Or role.Contains("SECURITY")

        Dim clickedButton = DirectCast(sender, Button)
        Dim parts As String() = clickedButton.Text.Split(New String() {vbCrLf, vbLf}, StringSplitOptions.None)
        Dim roomNum As String = parts(0).Replace("ROOM ", "").Trim()

        If clickedButton.BackColor = Color.SeaGreen Then
            If isGuard Then Exit Sub

            Dim ans = MsgBox("Room " & roomNum & " is empty. Register a new tenant?", MsgBoxStyle.YesNo + MsgBoxStyle.Question)
            If ans = MsgBoxResult.Yes Then
                frmTenantMgmt.ShowDialog()
                RefreshDashboard()
            End If

        ElseIf clickedButton.BackColor = Color.IndianRed Then
            Dim isCleaning As Boolean = clickedButton.Text.Contains("(Clean)")

            Dim tenantID As Integer = 0
            Dim tenantName As String = "No Active Tenant Found"
            Dim contact As String = "N/A"
            Dim rent As Decimal = 0
            Dim amountDue As Decimal = 0
            Dim dueDateStr As String = "Not Billed Yet"

            Using myConn As New OleDbConnection(ConnectionString)
                Try
                    myConn.Open()
                    Dim sql As String = "SELECT t.TenantID, t.FullName, t.ContactNo, t.BaseRent FROM tblTenants t INNER JOIN tblRooms r ON t.RoomID = r.RoomID WHERE r.RoomNumber = @rnum AND t.Status = 'Active'"
                    Dim cmd As New OleDbCommand(sql, myConn)
                    cmd.Parameters.AddWithValue("@rnum", roomNum)
                    Dim reader = cmd.ExecuteReader()
                    If reader.Read() Then
                        tenantID = Convert.ToInt32(reader("TenantID"))
                        tenantName = reader("FullName").ToString()
                        contact = reader("ContactNo").ToString()
                        If Not IsDBNull(reader("BaseRent")) Then
                            rent = Convert.ToDecimal(reader("BaseRent"))
                            amountDue = rent
                        End If
                    End If
                    reader.Close()

                    If tenantID > 0 Then
                        Dim sqlBill As String = "SELECT TOP 1 TotalAmount, BillingMonth FROM tblBillings WHERE TenantID = @tid AND IsPaid = 'No' ORDER BY BillID DESC"
                        Dim cmdBill As New OleDbCommand(sqlBill, myConn)
                        cmdBill.Parameters.AddWithValue("@tid", tenantID)
                        Dim readerBill = cmdBill.ExecuteReader()
                        If readerBill.Read() Then
                            If Not IsDBNull(readerBill("TotalAmount")) Then
                                amountDue = Convert.ToDecimal(readerBill("TotalAmount"))
                            End If
                            If Not IsDBNull(readerBill("BillingMonth")) Then
                                Dim rawDate As Object = readerBill("BillingMonth")
                                If TypeOf rawDate Is DateTime Then
                                    dueDateStr = DirectCast(rawDate, DateTime).ToString("MMMM dd, yyyy")
                                Else
                                    Dim parsedDate As DateTime
                                    If DateTime.TryParse(rawDate.ToString(), parsedDate) Then
                                        dueDateStr = parsedDate.ToString("MMMM dd, yyyy")
                                    Else
                                        dueDateStr = rawDate.ToString()
                                    End If
                                End If
                            End If
                        End If
                        readerBill.Close()
                    End If
                Catch ex As Exception
                End Try
            End Using

            Dim popup As New Form()
            popup.Text = "Room " & roomNum & " - Occupied"
            popup.Size = New Size(380, 310)
            popup.StartPosition = FormStartPosition.CenterParent
            popup.FormBorderStyle = FormBorderStyle.FixedDialog
            popup.MaximizeBox = False
            popup.MinimizeBox = False
            popup.BackColor = Color.White

            Dim lblInfo As New Label()
            lblInfo.Text = $"Tenant Name: {tenantName}{vbCrLf}Contact No: {contact}{vbCrLf}Base Rent: ₱{rent.ToString("N2")}{vbCrLf}Due Date: {dueDateStr}{vbCrLf}Current Balance: ₱{amountDue.ToString("N2")}"
            lblInfo.Location = New Point(20, 20)
            lblInfo.AutoSize = True
            lblInfo.Font = New Font("Segoe UI", 10, FontStyle.Bold)
            popup.Controls.Add(lblInfo)

            If isGuard Then
                Dim btnClose As New Button()
                btnClose.Text = "Close Info"
                btnClose.Location = New Point(115, 200)
                btnClose.Size = New Size(140, 40)
                btnClose.BackColor = Color.FromArgb(44, 62, 80)
                btnClose.ForeColor = Color.White
                btnClose.FlatStyle = FlatStyle.Flat
                btnClose.Cursor = Cursors.Hand
                AddHandler btnClose.Click, Sub() popup.DialogResult = DialogResult.OK
                popup.Controls.Add(btnClose)
            Else
                Dim btnEdit As New Button()
                btnEdit.Text = "Manage Tenant"
                btnEdit.Location = New Point(20, 140)
                btnEdit.Size = New Size(150, 40)
                btnEdit.BackColor = Color.FromArgb(31, 97, 141)
                btnEdit.ForeColor = Color.White
                btnEdit.FlatStyle = FlatStyle.Flat
                btnEdit.Cursor = Cursors.Hand
                AddHandler btnEdit.Click, Sub() popup.DialogResult = DialogResult.Yes
                popup.Controls.Add(btnEdit)

                Dim btnBill As New Button()
                btnBill.Text = "Add Billing"
                btnBill.Location = New Point(190, 140)
                btnBill.Size = New Size(150, 40)
                btnBill.BackColor = Color.SeaGreen
                btnBill.ForeColor = Color.White
                btnBill.FlatStyle = FlatStyle.Flat
                btnBill.Cursor = Cursors.Hand
                AddHandler btnBill.Click, Sub() popup.DialogResult = DialogResult.No
                popup.Controls.Add(btnBill)

                Dim btnClean As New Button()
                btnClean.Location = New Point(20, 190)
                btnClean.Size = New Size(320, 40)
                btnClean.FlatStyle = FlatStyle.Flat
                btnClean.Cursor = Cursors.Hand

                If isCleaning Then
                    btnClean.Text = "Mark as FINISHED Cleaning"
                    btnClean.BackColor = Color.SeaGreen
                    btnClean.ForeColor = Color.White
                    AddHandler btnClean.Click, Sub() popup.DialogResult = DialogResult.OK
                Else
                    btnClean.Text = "Mark as Needs Cleaning"
                    btnClean.BackColor = Color.Gold
                    btnClean.ForeColor = Color.Black
                    AddHandler btnClean.Click, Sub() popup.DialogResult = DialogResult.Ignore
                End If
                popup.Controls.Add(btnClean)
            End If

            Dim res = popup.ShowDialog()

            If Not isGuard Then
                If res = DialogResult.Yes Then
                    frmTenantMgmt.ShowDialog()
                    RefreshDashboard()
                ElseIf res = DialogResult.No Then
                    frmBilling.ShowDialog()
                    RefreshDashboard()
                ElseIf res = DialogResult.Ignore Then
                    UpdateRoomStatus(roomNum, "Occupied - Needs Cleaning")
                ElseIf res = DialogResult.OK Then
                    UpdateRoomStatus(roomNum, "Occupied")
                End If
            End If

        ElseIf clickedButton.BackColor = Color.Gold Then
            If isGuard Then Exit Sub

            Dim ans = MsgBox("Is Room " & roomNum & " finished cleaning?", MsgBoxStyle.YesNo + MsgBoxStyle.Question)
            If ans = MsgBoxResult.Yes Then
                UpdateRoomStatus(roomNum, "Available")
            End If
        End If
    End Sub

    Private Sub btnTenantMgmt_Click(sender As Object, e As EventArgs) Handles btnTenantMgmt.Click
        frmTenantMgmt.ShowDialog()
        RefreshDashboard()
    End Sub

    Private Sub btnManageUsers_Click(sender As Object, e As EventArgs) Handles btnManageUsers.Click
        frmUserMgmt.ShowDialog()
    End Sub

    Private Sub btnBilling_Click(sender As Object, e As EventArgs) Handles btnBilling.Click
        frmBilling.ShowDialog()
        RefreshDashboard()
    End Sub

    Private Sub btnReports_Click(sender As Object, e As EventArgs) Handles btnReports.Click
        frmReports.ShowDialog()
    End Sub

    Private Sub btnRoom_Click(sender As Object, e As EventArgs) Handles btnRoom.Click
        frmRoomDetails.ShowDialog()
    End Sub

    Private Sub btnAnnouncement_Click(sender As Object, e As EventArgs) Handles btnAnnouncement.Click
        frmAnnouncement.ShowDialog()
    End Sub

    Private Sub btnLogout_Click(sender As Object, e As EventArgs) Handles btnLogout.Click
        Dim ans = MsgBox("Are you sure you want to logout?", MsgBoxStyle.YesNo + MsgBoxStyle.Question)
        If ans = MsgBoxResult.Yes Then
            currentUsername = "" : currentUserRole = ""
            frmLogin.Show() : Me.Close()
        End If
    End Sub

    Private Sub RefreshDashboard()
        LoadRoomGrid()
        UpdateStats()
    End Sub

    Private Sub UpdateRoomStatus(roomNumber As String, newStatus As String)
        Using myConn As New OleDbConnection(ConnectionString)
            Try
                myConn.Open()
                Dim cmd As New OleDbCommand("UPDATE tblRooms SET [Status] = @stat WHERE [RoomNumber] = @rnum", myConn)
                cmd.Parameters.AddWithValue("@stat", newStatus)
                cmd.Parameters.AddWithValue("@rnum", roomNumber)
                cmd.ExecuteNonQuery()
                RefreshDashboard()
            Catch ex As Exception
            End Try
        End Using
    End Sub

    Private Sub UpdateStats()
        Using myConn As New OleDbConnection(ConnectionString)
            Try
                myConn.Open()
                Dim cmdOcc = New OleDbCommand("SELECT COUNT(*) FROM tblRooms WHERE Status LIKE 'Occupied%'", myConn)
                lblOccupiedCount.Text = cmdOcc.ExecuteScalar().ToString()

                Dim cmdAvail = New OleDbCommand("SELECT COUNT(*) FROM tblRooms WHERE Status = 'Available'", myConn)
                lblAvailableCount.Text = cmdAvail.ExecuteScalar().ToString()

                Dim cmdClean = New OleDbCommand("SELECT COUNT(*) FROM tblRooms WHERE Status LIKE '%clean%' OR Status LIKE '%need%'", myConn)
                lblCleaningCount.Text = cmdClean.ExecuteScalar().ToString()
            Catch ex As Exception
            End Try
        End Using
    End Sub

    Private Sub ApplyRoleSecurity()
        lblWelcome.Text = "User: " & currentUsername & " [" & currentUserRole & "]"

        Dim role As String = currentUserRole.ToUpper().Trim()

        If role = "ADMIN" Then
            btnManageUsers.Visible = True
        Else
            btnManageUsers.Visible = False
        End If

        If role.Contains("GUARD") Or role.Contains("SECURITY") Then
            btnBilling.Visible = False
            btnTenantMgmt.Visible = False
            btnReports.Visible = True
            btnRoom.Visible = False
            btnAnnouncement.Visible = True
        Else
            btnBilling.Visible = True
            btnTenantMgmt.Visible = True
            btnReports.Visible = True
            btnRoom.Visible = True
            btnAnnouncement.Visible = True
        End If
    End Sub

End Class