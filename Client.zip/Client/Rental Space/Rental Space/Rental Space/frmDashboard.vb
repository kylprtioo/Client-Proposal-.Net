﻿Imports System.Data.OleDb
Imports System.Net.Mail
Imports System.Net
Imports System.Drawing

Public Class frmDashboard

    Private Sub frmDashboard_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        RunAutoBilling()

        cmbFloorFilter.Items.Clear()
        cmbFloorFilter.Items.AddRange(New String() {"All Floors", "1st Floor", "2nd Floor", "3rd Floor", "4th Floor", "5th Floor"})
        cmbFloorFilter.SelectedIndex = 0

        lblDate.Text = DateTime.Now.ToString("dddd, MMMM dd, yyyy  hh:mm:ss tt")

        ApplyRoleSecurity()
        RefreshDashboard()
    End Sub

    Private Sub btnRefreshDashboard_Click(sender As Object, e As EventArgs) Handles btnRefreshDashboard.Click
        RefreshDashboard()
    End Sub

    Private Sub RunAutoBilling()
        If DateTime.Today.Day < 15 Then Exit Sub

        Dim currentMonthStart As New DateTime(DateTime.Today.Year, DateTime.Today.Month, 1)
        Dim currentMonthEnd As New DateTime(DateTime.Today.Year, DateTime.Today.Month, DateTime.DaysInMonth(DateTime.Today.Year, DateTime.Today.Month))

        Using myConn As New OleDbConnection(ConnectionString)
            Try
                myConn.Open()

                Dim sqlTenants As String = "SELECT TenantID, BaseRent FROM tblTenants WHERE Status = 'Active'"
                Dim cmdTenants As New OleDbCommand(sqlTenants, myConn)
                Dim reader = cmdTenants.ExecuteReader()
                Dim tenantsToBill As New List(Of Tuple(Of Integer, Decimal))

                While reader.Read()
                    If Not IsDBNull(reader("BaseRent")) Then
                        tenantsToBill.Add(New Tuple(Of Integer, Decimal)(CInt(reader("TenantID")), CDec(reader("BaseRent"))))
                    End If
                End While
                reader.Close()

                For Each t In tenantsToBill
                    Dim sqlCheck As String = "SELECT COUNT(*) FROM tblBillings WHERE TenantID = @tid AND BillingMonth BETWEEN @start AND @end"
                    Dim cmdCheck As New OleDbCommand(sqlCheck, myConn)
                    cmdCheck.Parameters.AddWithValue("@tid", t.Item1)
                    cmdCheck.Parameters.AddWithValue("@start", currentMonthStart)
                    cmdCheck.Parameters.AddWithValue("@end", currentMonthEnd)
                    Dim count As Integer = Convert.ToInt32(cmdCheck.ExecuteScalar())

                    If count = 0 Then
                        Dim sqlInsert As String = "INSERT INTO tblBillings ([TenantID], [BillingMonth], [TotalAmount], [Balance], [IsPaid]) VALUES (@tid, @bmonth, @bal, @bal, 'No')"
                        Dim cmdInsert As New OleDbCommand(sqlInsert, myConn)
                        cmdInsert.Parameters.AddWithValue("@tid", t.Item1)
                        cmdInsert.Parameters.Add("@bmonth", OleDbType.Date).Value = currentMonthStart
                        cmdInsert.Parameters.AddWithValue("@bal", t.Item2)
                        cmdInsert.ExecuteNonQuery()
                    End If
                Next
            Catch ex As Exception
            End Try
        End Using
    End Sub

    Private Sub tmrDate_Tick(sender As Object, e As EventArgs) Handles tmrDate.Tick
        lblDate.Text = DateTime.Now.ToString("dddd, MMMM dd, yyyy  hh:mm:ss tt")
    End Sub

    Private Sub cmbFloorFilter_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbFloorFilter.SelectedIndexChanged
        LoadRoomGrid()
    End Sub

    Private Function GetPendingBalance(roomNum As String) As Decimal
        Dim bal As Decimal = 0
        Using conn As New OleDbConnection(ConnectionString)
            Try
                conn.Open()
                Dim sqlGetTenant As String = "SELECT t.TenantID FROM tblTenants t INNER JOIN tblRooms r ON t.RoomID = r.RoomID WHERE r.RoomNumber = @rnum AND t.Status = 'Active'"
                Dim cmdGetTenant As New OleDbCommand(sqlGetTenant, conn)
                cmdGetTenant.Parameters.AddWithValue("@rnum", roomNum)
                Dim tIdObj = cmdGetTenant.ExecuteScalar()

                If tIdObj IsNot Nothing AndAlso Not IsDBNull(tIdObj) Then
                    Dim tid As Integer = Convert.ToInt32(tIdObj)
                    Dim sqlSum As String = "SELECT SUM([Balance]) FROM tblBillings WHERE TenantID = @tid AND ([IsPaid] = 'No' OR [IsPaid] = 'Partial')"
                    Dim cmdSum As New OleDbCommand(sqlSum, conn)
                    cmdSum.Parameters.AddWithValue("@tid", tid)
                    Dim sumObj = cmdSum.ExecuteScalar()

                    If sumObj IsNot Nothing AndAlso Not IsDBNull(sumObj) Then
                        bal = Convert.ToDecimal(sumObj)
                    End If
                End If
            Catch ex As Exception
            End Try
        End Using
        Return bal
    End Function

    Private Sub LoadRoomGrid()
        flpRooms.Controls.Clear()

        Dim sql As String = "SELECT RoomNumber, Status FROM tblRooms "
        Dim floorPrefix As String = ""

        Select Case cmbFloorFilter.Text
            Case "1st Floor" : floorPrefix = "1"
            Case "2nd Floor" : floorPrefix = "2"
            Case "3rd Floor" : floorPrefix = "3"
            Case "4th Floor" : floorPrefix = "4"
            Case "5th Floor" : floorPrefix = "5"
            Case Else : floorPrefix = ""
        End Select

        If floorPrefix <> "" Then
            sql &= " WHERE RoomNumber LIKE '" & floorPrefix & "%' "
        End If

        sql &= " ORDER BY RoomNumber ASC"

        Using myConn As New OleDbConnection(ConnectionString)
            Try
                Dim cmd As New OleDbCommand(sql, myConn)
                myConn.Open()
                Dim reader = cmd.ExecuteReader()
                While reader.Read()
                    Dim btn As New Button
                    Dim rNum As String = reader("RoomNumber").ToString()
                    btn.Width = 100 : btn.Height = 100 : btn.Margin = New Padding(5)
                    btn.FlatStyle = FlatStyle.Flat : btn.Font = New Font("Segoe UI", 10, FontStyle.Bold)

                    Dim status As String = reader("Status").ToString().Trim().ToLower()

                    Dim isPending As Boolean = False
                    If status.Contains("occupied") Then
                        If GetPendingBalance(rNum) > 0 Then
                            isPending = True
                        End If
                    End If

                    If status = "available" Then
                        btn.Text = "ROOM " & rNum
                        btn.BackColor = Color.SeaGreen : btn.ForeColor = Color.White
                    ElseIf isPending Then
                        btn.Text = "ROOM " & rNum & vbCrLf & "(Pending)"
                        btn.BackColor = Color.DarkOrange : btn.ForeColor = Color.White
                    ElseIf status = "occupied - maintenance room" Or status = "occupied - needs cleaning" Then
                        btn.Text = "ROOM " & rNum & vbCrLf & "(Maint.)"
                        btn.BackColor = Color.IndianRed : btn.ForeColor = Color.Yellow
                    ElseIf status.Contains("occupied") Then
                        btn.Text = "ROOM " & rNum
                        btn.BackColor = Color.IndianRed : btn.ForeColor = Color.White
                    ElseIf status.Contains("clean") Or status.Contains("need") Or status.Contains("maintenance") Then
                        btn.Text = "ROOM " & rNum
                        btn.BackColor = Color.Gold : btn.ForeColor = Color.Black
                    Else
                        btn.Text = "ROOM " & rNum
                        btn.BackColor = Color.SeaGreen : btn.ForeColor = Color.White
                    End If

                    AddHandler btn.Click, AddressOf Room_Click
                    flpRooms.Controls.Add(btn)
                End While
            Catch ex As Exception
            End Try
        End Using
    End Sub

    Private Sub Room_Click(sender As Object, e As EventArgs)
        Dim role As String = currentUserRole.ToUpper().Trim()
        Dim isGuard As Boolean = role.Contains("GUARD") Or role.Contains("SECURITY")

        Dim clickedButton = DirectCast(sender, Button)
        Dim parts As String() = clickedButton.Text.Split(New String() {vbCrLf, vbLf}, StringSplitOptions.None)
        Dim roomNum As String = parts(0).Replace("ROOM ", "").Trim()

        If clickedButton.BackColor = Color.SeaGreen Then
            If isGuard Then Exit Sub

            Dim ans = MsgBox("Room " & roomNum & " is empty." & vbCrLf & vbCrLf &
                             "YES - Register a new tenant" & vbCrLf &
                             "NO - Mark as Maintenance Room",
                             MsgBoxStyle.YesNoCancel + MsgBoxStyle.Question, "Available Room Options")

            If ans = MsgBoxResult.Yes Then
                frmTenantMgmt.preSelectedRoom = roomNum
                frmTenantMgmt.selectedTenantID = 0
                frmTenantMgmt.ShowDialog()
                RefreshDashboard()
            ElseIf ans = MsgBoxResult.No Then
                ExecuteStatusUpdate(roomNum, "Maintenance Room")
            End If

        ElseIf clickedButton.BackColor = Color.IndianRed OrElse clickedButton.BackColor = Color.DarkOrange Then
            Dim isMaintenance As Boolean = clickedButton.Text.Contains("(Maint.)") Or clickedButton.Text.Contains("(Clean)")

            Dim tenantID As Integer = 0
            Dim tenantName As String = "No Active Tenant Found"
            Dim contact As String = "N/A"
            Dim tenantEmail As String = "N/A"
            Dim rent As Decimal = 0
            Dim amountDue As Decimal = 0
            Dim dueDateStr As String = "Not Billed Yet"

            Dim meterNum As String = "N/A"
            Dim sDate As String = "N/A"
            Dim eDate As String = "N/A"
            Dim occupantCount As String = "0"
            Dim paymentStatus As String = "Paid"
            Dim overdueStatus As String = "🟢 CLEAR"
            Dim billRemarks As String = "None"

            Using myConn As New OleDbConnection(ConnectionString)
                Try
                    myConn.Open()
                    Dim sql As String = "SELECT t.TenantID, t.FullName, t.ContactNo, t.EmailAddress, t.BaseRent, " &
                                        "r.MeterNumber, t.StartDate, t.EndDate, t.NumberOfOccupants " &
                                        "FROM tblTenants t INNER JOIN tblRooms r ON t.RoomID = r.RoomID " &
                                        "WHERE r.RoomNumber = @rnum AND t.Status = 'Active'"
                    Dim cmd As New OleDbCommand(sql, myConn)
                    cmd.Parameters.AddWithValue("@rnum", roomNum)
                    Dim reader = cmd.ExecuteReader()

                    If reader.Read() Then
                        tenantID = Convert.ToInt32(reader("TenantID"))
                        tenantName = reader("FullName").ToString()
                        contact = reader("ContactNo").ToString()
                        tenantEmail = If(IsDBNull(reader("EmailAddress")), "N/A", reader("EmailAddress").ToString())
                        If Not IsDBNull(reader("BaseRent")) Then
                            rent = Convert.ToDecimal(reader("BaseRent"))
                        End If

                        If Not IsDBNull(reader("MeterNumber")) Then meterNum = reader("MeterNumber").ToString()
                        If Not IsDBNull(reader("NumberOfOccupants")) Then occupantCount = reader("NumberOfOccupants").ToString()
                        If Not IsDBNull(reader("StartDate")) Then sDate = Convert.ToDateTime(reader("StartDate")).ToString("MMM dd, yyyy")
                        If Not IsDBNull(reader("EndDate")) Then eDate = Convert.ToDateTime(reader("EndDate")).ToString("MMM dd, yyyy")
                    End If
                    reader.Close()

                    If tenantID > 0 Then
                        Dim sqlSum As String = "SELECT SUM([Balance]) FROM tblBillings WHERE TenantID = @tid AND ([IsPaid] = 'No' OR [IsPaid] = 'Partial')"
                        Dim cmdSum As New OleDbCommand(sqlSum, myConn)
                        cmdSum.Parameters.AddWithValue("@tid", tenantID)
                        Dim objSum = cmdSum.ExecuteScalar()
                        If objSum IsNot Nothing AndAlso Not IsDBNull(objSum) Then
                            amountDue = Convert.ToDecimal(objSum)
                        End If

                        If amountDue > 0 Then
                            Dim cmdDate As New OleDbCommand("SELECT TOP 1 [BillingMonth], [IsPaid], [Remarks] FROM tblBillings WHERE TenantID = @tid AND ([IsPaid] = 'No' OR [IsPaid] = 'Partial') ORDER BY [BillingMonth] ASC", myConn)
                            cmdDate.Parameters.AddWithValue("@tid", tenantID)
                            Dim readerDate = cmdDate.ExecuteReader()
                            If readerDate.Read() Then
                                paymentStatus = If(readerDate("IsPaid").ToString() = "No", "Unpaid", "Partial Payment")
                                billRemarks = If(IsDBNull(readerDate("Remarks")), "Pending resolution", readerDate("Remarks").ToString())

                                If Not IsDBNull(readerDate("BillingMonth")) Then
                                    Dim rawDate As Object = readerDate("BillingMonth")
                                    Dim parsedDate As DateTime
                                    If TypeOf rawDate Is DateTime Then
                                        parsedDate = DirectCast(rawDate, DateTime)
                                    Else
                                        DateTime.TryParse(rawDate.ToString(), parsedDate)
                                    End If
                                    Dim lastDay As New DateTime(parsedDate.Year, parsedDate.Month, DateTime.DaysInMonth(parsedDate.Year, parsedDate.Month))
                                    dueDateStr = lastDay.ToString("MMMM dd, yyyy")
                                    If DateTime.Today > lastDay Then
                                        overdueStatus = "🔴 OVERDUE"
                                    Else
                                        overdueStatus = "🟡 ON TIME (Pending)"
                                    End If
                                End If
                            End If
                            readerDate.Close()
                        End If
                    End If
                Catch ex As Exception
                End Try
            End Using

            Dim popup As New Form()
            popup.Text = "Room " & roomNum & " - Occupied"
            popup.Size = New Size(515, 650)
            popup.StartPosition = FormStartPosition.CenterParent
            popup.FormBorderStyle = FormBorderStyle.FixedDialog
            popup.MaximizeBox = False
            popup.MinimizeBox = False
            popup.BackColor = Color.White

            Dim pnlHeader As New Panel With {.Dock = DockStyle.Top, .Height = 60, .BackColor = Color.FromArgb(31, 41, 55)}
            Dim lblTitle As New Label With {.Text = "👤 Tenant Information", .ForeColor = Color.White, .Font = New Font("Segoe UI", 14, FontStyle.Bold), .AutoSize = True, .Location = New Point(20, 15)}
            pnlHeader.Controls.Add(lblTitle)
            popup.Controls.Add(pnlHeader)

            Dim pnlAction As New Panel With {.Dock = DockStyle.Bottom, .Height = 130, .BackColor = Color.White}

            If isGuard Then
                Dim lblGuardMsg As New Label With {.Text = "Actions are restricted for your role.", .ForeColor = Color.Gray, .Font = New Font("Segoe UI", 10, FontStyle.Italic), .AutoSize = True, .Location = New Point(20, 20)}
                pnlAction.Controls.Add(lblGuardMsg)
            Else
                Dim btnEdit As New Button With {.Text = "⚙️ Manage Tenant", .Location = New Point(15, 15), .Size = New Size(110, 40), .BackColor = Color.FromArgb(31, 97, 141), .ForeColor = Color.White, .FlatStyle = FlatStyle.Flat, .Cursor = Cursors.Hand, .Font = New Font("Segoe UI", 8.5F, FontStyle.Bold)}
                Dim btnBill As New Button With {.Text = "📝 Add Billing", .Location = New Point(135, 15), .Size = New Size(110, 40), .BackColor = Color.SeaGreen, .ForeColor = Color.White, .FlatStyle = FlatStyle.Flat, .Cursor = Cursors.Hand, .Font = New Font("Segoe UI", 8.5F, FontStyle.Bold)}
                Dim btnPay As New Button With {.Text = "💰 Payment", .Location = New Point(255, 15), .Size = New Size(110, 40), .BackColor = Color.DarkOrange, .ForeColor = Color.White, .FlatStyle = FlatStyle.Flat, .Cursor = Cursors.Hand, .Font = New Font("Segoe UI", 8.5F, FontStyle.Bold)}
                Dim btnEmail As New Button With {.Text = "✉️ Email Notice", .Location = New Point(375, 15), .Size = New Size(110, 40), .BackColor = Color.RoyalBlue, .ForeColor = Color.White, .FlatStyle = FlatStyle.Flat, .Cursor = Cursors.Hand, .Font = New Font("Segoe UI", 8.5F, FontStyle.Bold)}
                Dim btnClean As New Button With {.Location = New Point(15, 65), .Size = New Size(470, 40), .FlatStyle = FlatStyle.Flat, .Cursor = Cursors.Hand, .Font = New Font("Segoe UI", 9.5F, FontStyle.Bold)}

                If isMaintenance Then
                    btnClean.Text = "✅ Mark as FINISHED Maintenance"
                    btnClean.BackColor = Color.SeaGreen
                    btnClean.ForeColor = Color.White
                    AddHandler btnClean.Click, Sub() popup.DialogResult = DialogResult.OK
                Else
                    btnClean.Text = "🛠️ Mark as Maintenance Room"
                    btnClean.BackColor = Color.Gold
                    btnClean.ForeColor = Color.Black
                    AddHandler btnClean.Click, Sub() popup.DialogResult = DialogResult.Ignore
                End If

                AddHandler btnEdit.Click, Sub() popup.DialogResult = DialogResult.Yes
                AddHandler btnBill.Click, Sub() popup.DialogResult = DialogResult.No
                AddHandler btnPay.Click, Sub() popup.DialogResult = DialogResult.Retry
                AddHandler btnEmail.Click, Sub()
                                               If String.IsNullOrWhiteSpace(tenantEmail) Or tenantEmail = "N/A" Then
                                                   MsgBox("This tenant does not have a registered email address.", MsgBoxStyle.Exclamation)
                                                   Return
                                               End If

                                               Dim emailForm As New Form()
                                               emailForm.Text = "Send Email Reminder"
                                               emailForm.Size = New Size(450, 400)
                                               emailForm.StartPosition = FormStartPosition.CenterParent
                                               emailForm.FormBorderStyle = FormBorderStyle.FixedDialog
                                               emailForm.MaximizeBox = False
                                               emailForm.BackColor = Color.White

                                               Dim lblTo As New Label With {.Text = "To: " & tenantEmail, .Location = New Point(20, 20), .AutoSize = True, .Font = New Font("Segoe UI", 9.5F, FontStyle.Bold)}
                                               Dim lblSub As New Label With {.Text = "Subject:", .Location = New Point(20, 50), .AutoSize = True, .Font = New Font("Segoe UI", 9.5F, FontStyle.Bold)}
                                               Dim txtSub As New TextBox With {.Text = "Billing Reminder - Room " & roomNum, .Location = New Point(85, 47), .Width = 325, .Font = New Font("Segoe UI", 9.5F)}

                                               Dim lblMsg As New Label With {.Text = "Message:", .Location = New Point(20, 80), .AutoSize = True, .Font = New Font("Segoe UI", 9.5F, FontStyle.Bold)}
                                               Dim txtMsg As New TextBox With {
                                                   .Multiline = True,
                                                   .Location = New Point(20, 100),
                                                   .Size = New Size(390, 180),
                                                   .Font = New Font("Segoe UI", 9.5F),
                                                   .ScrollBars = ScrollBars.Vertical,
                                                   .Text = $"Hello {tenantName},{vbCrLf}{vbCrLf}This is a formal reminder regarding your pending balance of P {amountDue.ToString("N2")} for Room {roomNum}, which is due on {dueDateStr}.{vbCrLf}{vbCrLf}[Please type any additional message here...]{vbCrLf}{vbCrLf}Thank you,{vbCrLf}Cristina's Place Management"
                                               }

                                               Dim btnSend As New Button With {.Text = "Send Email", .Location = New Point(180, 300), .Size = New Size(110, 40), .BackColor = Color.SeaGreen, .ForeColor = Color.White, .FlatStyle = FlatStyle.Flat, .Font = New Font("Segoe UI", 9, FontStyle.Bold), .Cursor = Cursors.Hand}
                                               Dim btnCancel As New Button With {.Text = "Cancel", .Location = New Point(300, 300), .Size = New Size(110, 40), .BackColor = Color.IndianRed, .ForeColor = Color.White, .FlatStyle = FlatStyle.Flat, .Font = New Font("Segoe UI", 9, FontStyle.Bold), .Cursor = Cursors.Hand}

                                               AddHandler btnCancel.Click, Sub() emailForm.Close()
                                               AddHandler btnSend.Click, Sub()
                                                                             Try
                                                                                 emailForm.Cursor = Cursors.WaitCursor
                                                                                 Dim smtp As New SmtpClient("smtp.gmail.com")
                                                                                 smtp.Port = 587
                                                                                 smtp.EnableSsl = True
                                                                                 smtp.Credentials = New NetworkCredential("carlodowork@gmail.com", "xlko nqnb yhkl tbnv")

                                                                                 Dim mail As New MailMessage()
                                                                                 mail.From = New MailAddress("carlodowork@gmail.com", "Cristina's Place Management")
                                                                                 mail.To.Add(tenantEmail)
                                                                                 mail.Subject = txtSub.Text
                                                                                 mail.Body = txtMsg.Text

                                                                                 smtp.Send(mail)
                                                                                 emailForm.Cursor = Cursors.Default
                                                                                 MsgBox("Reminder email sent successfully!", MsgBoxStyle.Information)
                                                                                 emailForm.Close()
                                                                             Catch exc As Exception
                                                                                 emailForm.Cursor = Cursors.Default
                                                                                 MsgBox("Failed to send email: " & exc.Message, MsgBoxStyle.Critical)
                                                                             End Try
                                                                         End Sub

                                               emailForm.Controls.AddRange({lblTo, lblSub, txtSub, lblMsg, txtMsg, btnSend, btnCancel})
                                               emailForm.ShowDialog()
                                           End Sub

                pnlAction.Controls.AddRange({btnEdit, btnBill, btnPay, btnEmail, btnClean})
            End If

            popup.Controls.Add(pnlAction)

            Dim tlp As New TableLayoutPanel With {.Dock = DockStyle.Fill, .Padding = New Padding(20, 20, 20, 20), .ColumnCount = 2, .RowCount = 13}
            tlp.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 35.0F))
            tlp.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 65.0F))

            Dim fontLabel As New Font("Segoe UI", 10, FontStyle.Bold)
            Dim fontValue As New Font("Segoe UI", 10, FontStyle.Regular)
            Dim colorLabel As Color = Color.FromArgb(100, 116, 139)

            Dim addRow = Sub(iconText As String, valText As String, rIdx As Integer)
                             Dim l1 As New Label With {.Text = iconText, .Font = fontLabel, .ForeColor = colorLabel, .AutoSize = True, .Dock = DockStyle.Fill, .TextAlign = ContentAlignment.MiddleLeft}
                             Dim l2 As New Label With {.Text = valText, .Font = fontValue, .ForeColor = Color.Black, .AutoSize = True, .Dock = DockStyle.Fill, .TextAlign = ContentAlignment.MiddleLeft}
                             tlp.Controls.Add(l1, 0, rIdx)
                             tlp.Controls.Add(l2, 1, rIdx)
                         End Sub

            addRow("👤 Name:", tenantName, 0)
            addRow("🚪 Room:", roomNum, 1)
            addRow("📞 Contact:", contact, 2)
            addRow("✉️ Email:", tenantEmail, 3)
            addRow("⚡ Meter No:", meterNum, 4)
            addRow("💰 Base Rent:", "₱ " & rent.ToString("N2"), 5)
            addRow("📅 Start Date:", sDate, 6)
            addRow("⏳ End Date:", eDate, 7)
            addRow("💵 Balance:", "₱ " & amountDue.ToString("N2"), 8)
            addRow("📝 Remarks:", billRemarks, 9)
            addRow("📊 Pay Status:", paymentStatus, 10)
            addRow("📆 Due Date:", dueDateStr, 11)
            addRow("⚠️ Condition:", overdueStatus, 12)

            popup.Controls.Add(tlp)
            tlp.BringToFront()

            Dim res = popup.ShowDialog()

            If Not isGuard Then
                If res = DialogResult.Yes Then
                    frmTenantMgmt.selectedTenantID = tenantID
                    frmTenantMgmt.preSelectedRoom = ""
                    frmTenantMgmt.ShowDialog()
                    RefreshDashboard()
                ElseIf res = DialogResult.No Then
                    frmBilling.targetRoom = roomNum
                    frmBilling.ShowDialog()
                    RefreshDashboard()
                ElseIf res = DialogResult.Retry Then
                    frmPayment.targetRoom = roomNum
                    frmPayment.selectedTenantID = tenantID
                    frmPayment.ShowDialog()
                    RefreshDashboard()
                ElseIf res = DialogResult.Ignore Then
                    ExecuteStatusUpdate(roomNum, "Occupied - Maintenance Room")
                ElseIf res = DialogResult.OK Then
                    ExecuteStatusUpdate(roomNum, "Occupied")
                End If
            End If

        ElseIf clickedButton.BackColor = Color.Gold Then
            If isGuard Then Exit Sub

            Dim ans = MsgBox("Is Room " & roomNum & " finished maintenance?" & vbCrLf & "Click Yes to make it Available again.", MsgBoxStyle.YesNo + MsgBoxStyle.Question, "Room Maintenance Finished")
            If ans = MsgBoxResult.Yes Then
                ExecuteStatusUpdate(roomNum, "Available")
            End If
        End If
    End Sub

    Private Sub ExecuteStatusUpdate(roomNumber As String, newStatus As String)
        Using myConn As New OleDbConnection(ConnectionString)
            Try
                myConn.Open()
                Dim cmd As New OleDbCommand("UPDATE tblRooms SET [Status] = @stat WHERE [RoomNumber] = @rnum", myConn)
                cmd.Parameters.AddWithValue("@stat", newStatus)
                cmd.Parameters.AddWithValue("@rnum", roomNumber)
                cmd.ExecuteNonQuery()
                myConn.Close()
            Catch ex As Exception
            End Try
        End Using

        UpdateStatsImmediate()
        LoadRoomGrid()
    End Sub

    Private Sub UpdateStatsImmediate()
        Using myConn As New OleDbConnection(ConnectionString)
            Try
                myConn.Open()
                Dim cmdOcc = New OleDbCommand("SELECT COUNT(*) FROM tblRooms WHERE Status LIKE 'Occupied%'", myConn)
                lblOccupiedCount.Text = cmdOcc.ExecuteScalar().ToString()

                Dim cmdAvail = New OleDbCommand("SELECT COUNT(*) FROM tblRooms WHERE Status = 'Available'", myConn)
                lblAvailableCount.Text = cmdAvail.ExecuteScalar().ToString()

                Dim cmdClean = New OleDbCommand("SELECT COUNT(*) FROM tblRooms WHERE Status LIKE '%clean%' OR Status LIKE '%need%' OR Status LIKE '%maintenance%'", myConn)
                lblCleaningCount.Text = cmdClean.ExecuteScalar().ToString()

                lblOccupiedCount.Refresh()
                lblAvailableCount.Refresh()
                lblCleaningCount.Refresh()
            Catch ex As Exception
            End Try
        End Using
    End Sub

    Private Sub btnPayment_Click(sender As Object, e As EventArgs) Handles btnPayment.Click
        frmPayment.targetRoom = ""
        frmPayment.selectedTenantID = 0
        frmPayment.ShowDialog()
        RefreshDashboard()
    End Sub

    Private Sub btnTenantMgmt_Click(sender As Object, e As EventArgs) Handles btnTenantMgmt.Click
        frmTenantMgmt.preSelectedRoom = ""
        frmTenantMgmt.selectedTenantID = 0
        frmTenantMgmt.ShowDialog()
        RefreshDashboard()
    End Sub

    Private Sub btnManageUsers_Click(sender As Object, e As EventArgs) Handles btnManageUsers.Click
        frmUserMgmt.ShowDialog()
    End Sub

    Private Sub btnBilling_Click(sender As Object, e As EventArgs) Handles btnBilling.Click
        frmBilling.targetRoom = ""
        frmBilling.ShowDialog()
        RefreshDashboard()
    End Sub

    Private Sub btnReports_Click(sender As Object, e As EventArgs) Handles btnReports.Click
        frmReports.ShowDialog()
    End Sub

    Private Sub btnRoom_Click(sender As Object, e As EventArgs) Handles btnRoom.Click
        frmRoomDetails.ShowDialog()
    End Sub

    Private Sub btnAnnouncement_Click(sender As Object, e As EventArgs) Handles btnAnnouncement.Click
        frmAnnouncement.ShowDialog()
    End Sub

    Private Sub btnLogout_Click(sender As Object, e As EventArgs) Handles btnLogout.Click
        Dim ans = MsgBox("Are you sure you want to logout?", MsgBoxStyle.YesNo + MsgBoxStyle.Question)
        If ans = MsgBoxResult.Yes Then
            currentUsername = "" : currentUserRole = ""
            frmLogin.Show() : Me.Close()
        End If
    End Sub

    Private Sub RefreshDashboard()
        LoadRoomGrid()
        UpdateStats()
    End Sub

    Private Sub UpdateRoomStatus(roomNumber As String, newStatus As String)
        ExecuteStatusUpdate(roomNumber, newStatus)
    End Sub

    Private Sub UpdateStats()
        Using myConn As New OleDbConnection(ConnectionString)
            Try
                myConn.Open()
                Dim cmdOcc = New OleDbCommand("SELECT COUNT(*) FROM tblRooms WHERE Status LIKE 'Occupied%'", myConn)
                lblOccupiedCount.Text = cmdOcc.ExecuteScalar().ToString()

                Dim cmdAvail = New OleDbCommand("SELECT COUNT(*) FROM tblRooms WHERE Status = 'Available'", myConn)
                lblAvailableCount.Text = cmdAvail.ExecuteScalar().ToString()

                Dim cmdClean = New OleDbCommand("SELECT COUNT(*) FROM tblRooms WHERE Status LIKE '%clean%' OR Status LIKE '%need%' OR Status LIKE '%maintenance%'", myConn)
                lblCleaningCount.Text = cmdClean.ExecuteScalar().ToString()
            Catch ex As Exception
            End Try
        End Using
    End Sub

    Private Sub ApplyRoleSecurity()
        lblWelcome.Text = "User: " & currentUsername & " [" & currentUserRole & "]"

        Dim role As String = currentUserRole.ToUpper().Trim()

        If role = "ADMIN" Then
            btnManageUsers.Visible = True
        Else
            btnManageUsers.Visible = False
        End If

        If role.Contains("GUARD") Or role.Contains("SECURITY") Then
            btnBilling.Visible = False
            btnPayment.Visible = False
            btnTenantMgmt.Visible = False
            btnReports.Visible = True
            btnRoom.Visible = False
            btnAnnouncement.Visible = True
        Else
            btnBilling.Visible = True
            btnPayment.Visible = True
            btnTenantMgmt.Visible = True
            btnReports.Visible = True
            btnRoom.Visible = True
            btnAnnouncement.Visible = True
        End If
    End Sub

End Class