﻿Imports System.Data.OleDb

Public Class frmUserMgmt
    Dim selectedUserID As Integer = 0
    Dim isViewingArchive As Boolean = False

    Private Sub frmUserMgmt_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        LoadUsers()
        ClearFields()
    End Sub

    Private Sub LoadUsers(Optional searchTerm As String = "")
        Using myConn As New OleDbConnection(ConnectionString)
            Try
                myConn.Open()
                Dim statusFilter As String = If(isViewingArchive, "Inactive", "Active")
                Dim sql As String = "SELECT [UserID], [FullName], [Username], [UserRole], [Status] FROM [tblUsers] WHERE [Status] = @status"

                If searchTerm <> "" Then
                    sql &= " AND ([FullName] LIKE @search OR [Username] LIKE @search)"
                End If

                sql &= " ORDER BY [FullName] ASC"

                Dim cmd As New OleDbCommand(sql, myConn)
                cmd.Parameters.AddWithValue("@status", statusFilter)

                If searchTerm <> "" Then
                    cmd.Parameters.AddWithValue("@search", "%" & searchTerm & "%")
                End If

                Dim adapter As New OleDbDataAdapter(cmd)
                Dim dt As New DataTable
                adapter.Fill(dt)
                dgvUsers.DataSource = dt
            Catch ex As Exception
                MsgBox("Error Loading Users: " & ex.Message, MsgBoxStyle.Critical)
            End Try
        End Using
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        If isViewingArchive Then Exit Sub

        If txtFirstName.Text.Trim() = "" Or txtLastName.Text.Trim() = "" Or txtUsername.Text.Trim() = "" Or txtPassword.Text.Trim() = "" Or cmbRole.SelectedIndex = -1 Then
            MsgBox("Pakikumpleto ang impormasyon ng user.", MsgBoxStyle.Exclamation)
            Exit Sub
        End If

        Dim combinedName As String = ""
        If txtMiddleName.Text.Trim() <> "" Then
            combinedName = $"{txtLastName.Text.Trim()}, {txtFirstName.Text.Trim()} {txtMiddleName.Text.Trim()}"
        Else
            combinedName = $"{txtLastName.Text.Trim()}, {txtFirstName.Text.Trim()}"
        End If

        Using myConn As New OleDbConnection(ConnectionString)
            Try
                myConn.Open()
                Dim sql As String = "INSERT INTO [tblUsers] ([FullName], [Username], [Password], [UserRole], [Status]) " &
                                   "VALUES (@fname, @un, @pw, @role, 'Active')"
                Dim cmd As New OleDbCommand(sql, myConn)
                cmd.Parameters.AddWithValue("@fname", combinedName)
                cmd.Parameters.AddWithValue("@un", txtUsername.Text.Trim())
                cmd.Parameters.AddWithValue("@pw", txtPassword.Text.Trim())
                cmd.Parameters.AddWithValue("@role", cmbRole.Text)

                cmd.ExecuteNonQuery()
                MsgBox("User personnel saved successfully!", MsgBoxStyle.Information)
                LoadUsers()
                ClearFields()
            Catch ex As Exception
                MsgBox("Save Error: " & ex.Message, MsgBoxStyle.Critical)
            End Try
        End Using
    End Sub

    Private Sub dgvUsers_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgvUsers.CellClick
        If e.RowIndex >= 0 Then
            Try
                Dim row = dgvUsers.Rows(e.RowIndex)
                selectedUserID = CInt(row.Cells("UserID").Value)
                Dim full As String = row.Cells("FullName").Value.ToString()

                txtLastName.Clear()
                txtFirstName.Clear()
                txtMiddleName.Clear()

                If full.Contains(",") Then
                    Dim parts() As String = full.Split(","c)
                    txtLastName.Text = parts(0).Trim()

                    Dim firstAndMiddle As String = parts(1).Trim()
                    Dim nameParts() As String = firstAndMiddle.Split(New Char() {" "c}, StringSplitOptions.RemoveEmptyEntries)

                    If nameParts.Length = 1 Then
                        txtFirstName.Text = nameParts(0)
                    ElseIf nameParts.Length > 1 Then
                        txtMiddleName.Text = nameParts(nameParts.Length - 1)
                        txtFirstName.Text = String.Join(" ", nameParts, 0, nameParts.Length - 1)
                    End If
                Else
                    txtLastName.Text = full
                End If

                txtUsername.Text = row.Cells("Username").Value.ToString()
                cmbRole.Text = row.Cells("UserRole").Value.ToString()
                txtPassword.Clear()
                btnSave.Enabled = False
            Catch ex As Exception
            End Try
        End If
    End Sub

    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        If isViewingArchive Or selectedUserID = 0 Then Exit Sub

        If txtFirstName.Text.Trim() = "" Or txtLastName.Text.Trim() = "" Or txtUsername.Text.Trim() = "" Or cmbRole.SelectedIndex = -1 Then
            MsgBox("Please complete all required fields.", MsgBoxStyle.Exclamation)
            Exit Sub
        End If

        Dim combinedName As String = ""
        If txtMiddleName.Text.Trim() <> "" Then
            combinedName = $"{txtLastName.Text.Trim()}, {txtFirstName.Text.Trim()} {txtMiddleName.Text.Trim()}"
        Else
            combinedName = $"{txtLastName.Text.Trim()}, {txtFirstName.Text.Trim()}"
        End If

        Using myConn As New OleDbConnection(ConnectionString)
            Try
                myConn.Open()
                Dim sql As String = "UPDATE [tblUsers] SET [FullName]=@fname, [Username]=@un, [UserRole]=@role"

                If txtPassword.Text.Trim() <> "" Then
                    sql &= ", [Password]=@pw"
                End If

                sql &= " WHERE [UserID]=@id"

                Dim cmd As New OleDbCommand(sql, myConn)
                cmd.Parameters.AddWithValue("@fname", combinedName)
                cmd.Parameters.AddWithValue("@un", txtUsername.Text.Trim())
                cmd.Parameters.AddWithValue("@role", cmbRole.Text)
                If txtPassword.Text.Trim() <> "" Then
                    cmd.Parameters.AddWithValue("@pw", txtPassword.Text.Trim())
                End If
                cmd.Parameters.AddWithValue("@id", selectedUserID)

                cmd.ExecuteNonQuery()
                MsgBox("Personnel record updated!", MsgBoxStyle.Information)
                LoadUsers()
                ClearFields()
            Catch ex As Exception
                MsgBox("Update Error: " & ex.Message, MsgBoxStyle.Critical)
            End Try
        End Using
    End Sub

    Private Sub btnArchive_Click(sender As Object, e As EventArgs) Handles btnArchive.Click
        If selectedUserID = 0 Then Exit Sub

        If isViewingArchive Then
            If MsgBox("Restore this user to Active status?", MsgBoxStyle.YesNo + MsgBoxStyle.Question) = MsgBoxResult.Yes Then
                Using myConn As New OleDbConnection(ConnectionString)
                    Try
                        myConn.Open()
                        Dim cmd As New OleDbCommand("UPDATE [tblUsers] SET [Status] = 'Active' WHERE [UserID] = @id", myConn)
                        cmd.Parameters.AddWithValue("@id", selectedUserID)
                        cmd.ExecuteNonQuery()
                        MsgBox("User restored successfully.")
                        LoadUsers()
                        ClearFields()
                    Catch ex As Exception
                    End Try
                End Using
            End If
        Else
            If MsgBox("Are you sure you want to archive this user?", MsgBoxStyle.YesNo + MsgBoxStyle.Question) = MsgBoxResult.Yes Then
                Using myConn As New OleDbConnection(ConnectionString)
                    Try
                        myConn.Open()
                        Dim cmd As New OleDbCommand("UPDATE [tblUsers] SET [Status] = 'Inactive' WHERE [UserID] = @id", myConn)
                        cmd.Parameters.AddWithValue("@id", selectedUserID)
                        cmd.ExecuteNonQuery()
                        MsgBox("User archived successfully.")
                        LoadUsers()
                        ClearFields()
                    Catch ex As Exception
                    End Try
                End Using
            End If
        End If
    End Sub

    Private Sub btnViewArchive_Click(sender As Object, e As EventArgs) Handles btnViewArchive.Click
        isViewingArchive = Not isViewingArchive
        If isViewingArchive Then
            btnViewArchive.Text = "VIEW ACTIVE"
            lblViewStatus.Text = "VIEWING: ARCHIVED"
            lblViewStatus.ForeColor = Color.IndianRed
            btnArchive.Text = "RESTORE USER"
            btnArchive.BackColor = Color.SeaGreen
            btnSave.Enabled = False
            btnUpdate.Enabled = False
        Else
            btnViewArchive.Text = "VIEW ARCHIVE"
            lblViewStatus.Text = "VIEWING: ACTIVE"
            lblViewStatus.ForeColor = Color.FromArgb(31, 97, 141)
            btnArchive.Text = "ARCHIVE USER"
            btnArchive.BackColor = Color.FromArgb(192, 57, 43)
            btnSave.Enabled = True
            btnUpdate.Enabled = True
        End If
        ClearFields()
        LoadUsers()
    End Sub

    Private Sub txtSearch_TextChanged(sender As Object, e As EventArgs) Handles txtSearch.TextChanged
        LoadUsers(txtSearch.Text.Trim())
    End Sub

    Private Sub btnRefresh_Click(sender As Object, e As EventArgs) Handles btnRefresh.Click
        txtSearch.Clear()
        LoadUsers()
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        ClearFields()
    End Sub

    Private Sub ClearFields()
        selectedUserID = 0
        txtFirstName.Clear()
        txtMiddleName.Clear()
        txtLastName.Clear()
        txtUsername.Clear()
        txtPassword.Clear()
        cmbRole.SelectedIndex = -1
        If Not isViewingArchive Then btnSave.Enabled = True
    End Sub
End Class