﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmAnnouncement
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As DataGridViewCellStyle = New DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As DataGridViewCellStyle = New DataGridViewCellStyle()
        lblTitle = New Label()
        pnlCreate = New Panel()
        btnPost = New Button()
        chkSendEmail = New CheckBox()
        Label3 = New Label()
        txtMessage = New TextBox()
        txtTitle = New TextBox()
        Label2 = New Label()
        Label1 = New Label()
        pnlHistory = New Panel()
        dgvAnnouncements = New DataGridView()
        Label4 = New Label()
        pnlCreate.SuspendLayout()
        pnlHistory.SuspendLayout()
        CType(dgvAnnouncements, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' lblTitle
        ' 
        lblTitle.AutoSize = True
        lblTitle.Font = New Font("Segoe UI", 20.25F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblTitle.ForeColor = Color.FromArgb(CByte(31), CByte(41), CByte(55))
        lblTitle.Location = New Point(20, 20)
        lblTitle.Name = "lblTitle"
        lblTitle.Size = New Size(371, 37)
        lblTitle.TabIndex = 1
        lblTitle.Text = "SYSTEM ANNOUNCEMENTS"
        ' 
        ' pnlCreate
        ' 
        pnlCreate.BackColor = Color.White
        pnlCreate.Controls.Add(btnPost)
        pnlCreate.Controls.Add(chkSendEmail)
        pnlCreate.Controls.Add(Label3)
        pnlCreate.Controls.Add(txtMessage)
        pnlCreate.Controls.Add(txtTitle)
        pnlCreate.Controls.Add(Label2)
        pnlCreate.Controls.Add(Label1)
        pnlCreate.Location = New Point(27, 80)
        pnlCreate.Name = "pnlCreate"
        pnlCreate.Size = New Size(420, 420)
        pnlCreate.TabIndex = 2
        ' 
        ' btnPost
        ' 
        btnPost.BackColor = Color.FromArgb(CByte(31), CByte(97), CByte(141))
        btnPost.Cursor = Cursors.Hand
        btnPost.FlatAppearance.BorderSize = 0
        btnPost.FlatStyle = FlatStyle.Flat
        btnPost.Font = New Font("Segoe UI", 11.25F, FontStyle.Bold)
        btnPost.ForeColor = Color.White
        btnPost.Location = New Point(25, 350)
        btnPost.Name = "btnPost"
        btnPost.Size = New Size(370, 45)
        btnPost.TabIndex = 6
        btnPost.Text = "POST ANNOUNCEMENT"
        btnPost.UseVisualStyleBackColor = False
        ' 
        ' chkSendEmail
        ' 
        chkSendEmail.AutoSize = True
        chkSendEmail.Font = New Font("Segoe UI", 10F)
        chkSendEmail.ForeColor = Color.FromArgb(CByte(31), CByte(41), CByte(55))
        chkSendEmail.Location = New Point(25, 310)
        chkSendEmail.Name = "chkSendEmail"
        chkSendEmail.Size = New Size(238, 23)
        chkSendEmail.TabIndex = 5
        chkSendEmail.Text = "Send to all active tenants via Email"
        chkSendEmail.UseVisualStyleBackColor = True
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Font = New Font("Segoe UI Semibold", 10F, FontStyle.Bold)
        Label3.ForeColor = Color.FromArgb(CByte(100), CByte(116), CByte(139))
        Label3.Location = New Point(20, 125)
        Label3.Name = "Label3"
        Label3.Size = New Size(66, 19)
        Label3.TabIndex = 4
        Label3.Text = "Message:"
        ' 
        ' txtMessage
        ' 
        txtMessage.Font = New Font("Segoe UI", 11F)
        txtMessage.Location = New Point(25, 150)
        txtMessage.Multiline = True
        txtMessage.Name = "txtMessage"
        txtMessage.ScrollBars = ScrollBars.Vertical
        txtMessage.Size = New Size(370, 140)
        txtMessage.TabIndex = 3
        ' 
        ' txtTitle
        ' 
        txtTitle.Font = New Font("Segoe UI", 11F)
        txtTitle.Location = New Point(25, 85)
        txtTitle.Name = "txtTitle"
        txtTitle.Size = New Size(370, 27)
        txtTitle.TabIndex = 2
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("Segoe UI Semibold", 10F, FontStyle.Bold)
        Label2.ForeColor = Color.FromArgb(CByte(100), CByte(116), CByte(139))
        Label2.Location = New Point(20, 60)
        Label2.Name = "Label2"
        Label2.Size = New Size(139, 19)
        Label2.TabIndex = 1
        Label2.Text = "Announcement Title:"
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label1.ForeColor = Color.FromArgb(CByte(31), CByte(41), CByte(55))
        Label1.Location = New Point(20, 20)
        Label1.Name = "Label1"
        Label1.Size = New Size(212, 25)
        Label1.TabIndex = 0
        Label1.Text = "Create Announcement"
        ' 
        ' pnlHistory
        ' 
        pnlHistory.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right
        pnlHistory.BackColor = Color.White
        pnlHistory.Controls.Add(dgvAnnouncements)
        pnlHistory.Controls.Add(Label4)
        pnlHistory.Location = New Point(470, 80)
        pnlHistory.Name = "pnlHistory"
        pnlHistory.Size = New Size(550, 420)
        pnlHistory.TabIndex = 3
        ' 
        ' dgvAnnouncements
        ' 
        dgvAnnouncements.AllowUserToAddRows = False
        dgvAnnouncements.AllowUserToDeleteRows = False
        dgvAnnouncements.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right
        dgvAnnouncements.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
        dgvAnnouncements.BackgroundColor = Color.White
        dgvAnnouncements.BorderStyle = BorderStyle.None
        dgvAnnouncements.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal
        DataGridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = Color.FromArgb(CByte(243), CByte(244), CByte(246))
        DataGridViewCellStyle1.Font = New Font("Segoe UI Semibold", 10F, FontStyle.Bold)
        DataGridViewCellStyle1.ForeColor = Color.FromArgb(CByte(31), CByte(41), CByte(55))
        DataGridViewCellStyle1.SelectionBackColor = Color.FromArgb(CByte(243), CByte(244), CByte(246))
        DataGridViewCellStyle1.SelectionForeColor = Color.FromArgb(CByte(31), CByte(41), CByte(55))
        DataGridViewCellStyle1.WrapMode = DataGridViewTriState.True
        dgvAnnouncements.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        dgvAnnouncements.ColumnHeadersHeight = 40
        DataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = Color.White
        DataGridViewCellStyle2.Font = New Font("Segoe UI", 10F)
        DataGridViewCellStyle2.ForeColor = Color.FromArgb(CByte(31), CByte(41), CByte(55))
        DataGridViewCellStyle2.SelectionBackColor = Color.FromArgb(CByte(31), CByte(97), CByte(141))
        DataGridViewCellStyle2.SelectionForeColor = Color.White
        DataGridViewCellStyle2.WrapMode = DataGridViewTriState.False
        dgvAnnouncements.DefaultCellStyle = DataGridViewCellStyle2
        dgvAnnouncements.EnableHeadersVisualStyles = False
        dgvAnnouncements.Location = New Point(20, 60)
        dgvAnnouncements.Name = "dgvAnnouncements"
        dgvAnnouncements.ReadOnly = True
        dgvAnnouncements.RowHeadersVisible = False
        dgvAnnouncements.RowTemplate.Height = 35
        dgvAnnouncements.SelectionMode = DataGridViewSelectionMode.FullRowSelect
        dgvAnnouncements.Size = New Size(510, 340)
        dgvAnnouncements.TabIndex = 8
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Font = New Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label4.ForeColor = Color.FromArgb(CByte(31), CByte(41), CByte(55))
        Label4.Location = New Point(15, 20)
        Label4.Name = "Label4"
        Label4.Size = New Size(200, 25)
        Label4.TabIndex = 1
        Label4.Text = "Past Announcements"
        ' 
        ' frmAnnouncement
        ' 
        AutoScaleDimensions = New SizeF(7F, 17F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.FromArgb(CByte(243), CByte(244), CByte(246))
        ClientSize = New Size(1050, 540)
        Controls.Add(pnlHistory)
        Controls.Add(pnlCreate)
        Controls.Add(lblTitle)
        Font = New Font("Segoe UI", 9.75F)
        Name = "frmAnnouncement"
        StartPosition = FormStartPosition.CenterScreen
        Text = "System Announcements"
        pnlCreate.ResumeLayout(False)
        pnlCreate.PerformLayout()
        pnlHistory.ResumeLayout(False)
        pnlHistory.PerformLayout()
        CType(dgvAnnouncements, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()

    End Sub

    Friend WithEvents lblTitle As Label
    Friend WithEvents pnlCreate As Panel
    Friend WithEvents Label3 As Label
    Friend WithEvents txtMessage As TextBox
    Friend WithEvents txtTitle As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents btnPost As Button
    Friend WithEvents chkSendEmail As CheckBox
    Friend WithEvents pnlHistory As Panel
    Friend WithEvents Label4 As Label
    Friend WithEvents dgvAnnouncements As DataGridView
End Class