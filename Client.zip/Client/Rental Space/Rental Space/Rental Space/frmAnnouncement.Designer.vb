﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmAnnouncement
    Inherits System.Windows.Forms.Form

    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    Private components As System.ComponentModel.IContainer

    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.pnlCreate = New System.Windows.Forms.Panel()
        Me.btnPost = New System.Windows.Forms.Button()
        Me.chkSendEmail = New System.Windows.Forms.CheckBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtMessage = New System.Windows.Forms.TextBox()
        Me.txtTitle = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.pnlHistory = New System.Windows.Forms.Panel()
        Me.dgvAnnouncements = New System.Windows.Forms.DataGridView()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.pnlCreate.SuspendLayout()
        Me.pnlHistory.SuspendLayout()
        CType(Me.dgvAnnouncements, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblTitle
        '
        Me.lblTitle.AutoSize = True
        Me.lblTitle.Font = New System.Drawing.Font("Segoe UI", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CByte(0))
        Me.lblTitle.ForeColor = System.Drawing.Color.FromArgb(CByte(31), CByte(41), CByte(55))
        Me.lblTitle.Location = New System.Drawing.Point(20, 20)
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.Size = New System.Drawing.Size(371, 37)
        Me.lblTitle.TabIndex = 1
        Me.lblTitle.Text = "SYSTEM ANNOUNCEMENTS"
        '
        'pnlCreate
        '
        Me.pnlCreate.BackColor = System.Drawing.Color.White
        Me.pnlCreate.Controls.Add(Me.btnPost)
        Me.pnlCreate.Controls.Add(Me.chkSendEmail)
        Me.pnlCreate.Controls.Add(Me.Label3)
        Me.pnlCreate.Controls.Add(Me.txtMessage)
        Me.pnlCreate.Controls.Add(Me.txtTitle)
        Me.pnlCreate.Controls.Add(Me.Label2)
        Me.pnlCreate.Controls.Add(Me.Label1)
        Me.pnlCreate.Location = New System.Drawing.Point(27, 80)
        Me.pnlCreate.Name = "pnlCreate"
        Me.pnlCreate.Size = New System.Drawing.Size(420, 420)
        Me.pnlCreate.TabIndex = 2
        '
        'btnPost
        '
        Me.btnPost.BackColor = System.Drawing.Color.FromArgb(CByte(31), CByte(97), CByte(141))
        Me.btnPost.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnPost.FlatAppearance.BorderSize = 0
        Me.btnPost.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnPost.Font = New System.Drawing.Font("Segoe UI", 11.25!, System.Drawing.FontStyle.Bold)
        Me.btnPost.ForeColor = System.Drawing.Color.White
        Me.btnPost.Location = New System.Drawing.Point(25, 350)
        Me.btnPost.Name = "btnPost"
        Me.btnPost.Size = New System.Drawing.Size(370, 45)
        Me.btnPost.TabIndex = 6
        Me.btnPost.Text = "POST ANNOUNCEMENT"
        Me.btnPost.UseVisualStyleBackColor = False
        '
        'chkSendEmail
        '
        Me.chkSendEmail.AutoSize = True
        Me.chkSendEmail.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.chkSendEmail.ForeColor = System.Drawing.Color.FromArgb(CByte(31), CByte(41), CByte(55))
        Me.chkSendEmail.Location = New System.Drawing.Point(25, 310)
        Me.chkSendEmail.Name = "chkSendEmail"
        Me.chkSendEmail.Size = New System.Drawing.Size(238, 23)
        Me.chkSendEmail.TabIndex = 5
        Me.chkSendEmail.Text = "Send to all active tenants via Email"
        Me.chkSendEmail.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Segoe UI Semibold", 10.0!, System.Drawing.FontStyle.Bold)
        Me.Label3.ForeColor = System.Drawing.Color.FromArgb(CByte(100), CByte(116), CByte(139))
        Me.Label3.Location = New System.Drawing.Point(20, 125)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(66, 19)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Message:"
        '
        'txtMessage
        '
        Me.txtMessage.Font = New System.Drawing.Font("Segoe UI", 11.0!)
        Me.txtMessage.Location = New System.Drawing.Point(25, 150)
        Me.txtMessage.Multiline = True
        Me.txtMessage.Name = "txtMessage"
        Me.txtMessage.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtMessage.Size = New System.Drawing.Size(370, 140)
        Me.txtMessage.TabIndex = 3
        '
        'txtTitle
        '
        Me.txtTitle.Font = New System.Drawing.Font("Segoe UI", 11.0!)
        Me.txtTitle.Location = New System.Drawing.Point(25, 85)
        Me.txtTitle.Name = "txtTitle"
        Me.txtTitle.Size = New System.Drawing.Size(370, 27)
        Me.txtTitle.TabIndex = 2
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Segoe UI Semibold", 10.0!, System.Drawing.FontStyle.Bold)
        Me.Label2.ForeColor = System.Drawing.Color.FromArgb(CByte(100), CByte(116), CByte(139))
        Me.Label2.Location = New System.Drawing.Point(20, 60)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(139, 19)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Announcement Title:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CByte(0))
        Me.Label1.ForeColor = System.Drawing.Color.FromArgb(CByte(31), CByte(41), CByte(55))
        Me.Label1.Location = New System.Drawing.Point(20, 20)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(212, 25)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Create Announcement"
        '
        'pnlHistory
        '
        Me.pnlHistory.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.pnlHistory.BackColor = System.Drawing.Color.White
        Me.pnlHistory.Controls.Add(Me.dgvAnnouncements)
        Me.pnlHistory.Controls.Add(Me.Label4)
        Me.pnlHistory.Location = New System.Drawing.Point(470, 80)
        Me.pnlHistory.Name = "pnlHistory"
        Me.pnlHistory.Size = New System.Drawing.Size(550, 420)
        Me.pnlHistory.TabIndex = 3
        '
        'dgvAnnouncements
        '
        Me.dgvAnnouncements.AllowUserToAddRows = False
        Me.dgvAnnouncements.AllowUserToDeleteRows = False
        Me.dgvAnnouncements.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.dgvAnnouncements.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.dgvAnnouncements.BackgroundColor = System.Drawing.Color.White
        Me.dgvAnnouncements.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.dgvAnnouncements.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(CByte(243), CByte(244), CByte(246))
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Segoe UI Semibold", 10.0!, System.Drawing.FontStyle.Bold)
        DataGridViewCellStyle1.ForeColor = System.Drawing.Color.FromArgb(CByte(31), CByte(41), CByte(55))
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.FromArgb(CByte(243), CByte(244), CByte(246))
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.FromArgb(CByte(31), CByte(41), CByte(55))
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgvAnnouncements.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.dgvAnnouncements.ColumnHeadersHeight = 40
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.Color.White
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        DataGridViewCellStyle2.ForeColor = System.Drawing.Color.FromArgb(CByte(31), CByte(41), CByte(55))
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(CByte(31), CByte(97), CByte(141))
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.White
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgvAnnouncements.DefaultCellStyle = DataGridViewCellStyle2
        Me.dgvAnnouncements.EnableHeadersVisualStyles = False
        Me.dgvAnnouncements.Location = New System.Drawing.Point(20, 60)
        Me.dgvAnnouncements.Name = "dgvAnnouncements"
        Me.dgvAnnouncements.ReadOnly = True
        Me.dgvAnnouncements.RowHeadersVisible = False
        Me.dgvAnnouncements.RowTemplate.Height = 35
        Me.dgvAnnouncements.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgvAnnouncements.Size = New System.Drawing.Size(510, 340)
        Me.dgvAnnouncements.TabIndex = 8
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CByte(0))
        Me.Label4.ForeColor = System.Drawing.Color.FromArgb(CByte(31), CByte(41), CByte(55))
        Me.Label4.Location = New System.Drawing.Point(15, 20)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(200, 25)
        Me.Label4.TabIndex = 1
        Me.Label4.Text = "Past Announcements"
        '
        'frmAnnouncement
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 17.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CByte(243), CByte(244), CByte(246))
        Me.ClientSize = New System.Drawing.Size(1050, 540)
        Me.Controls.Add(Me.pnlHistory)
        Me.Controls.Add(Me.pnlCreate)
        Me.Controls.Add(Me.lblTitle)
        Me.Font = New System.Drawing.Font("Segoe UI", 9.75!)
        Me.Name = "frmAnnouncement"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "System Announcements"
        Me.pnlCreate.ResumeLayout(False)
        Me.pnlCreate.PerformLayout()
        Me.pnlHistory.ResumeLayout(False)
        Me.pnlHistory.PerformLayout()
        CType(Me.dgvAnnouncements, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblTitle As System.Windows.Forms.Label
    Friend WithEvents pnlCreate As System.Windows.Forms.Panel
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txtMessage As System.Windows.Forms.TextBox
    Friend WithEvents txtTitle As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents btnPost As System.Windows.Forms.Button
    Friend WithEvents chkSendEmail As System.Windows.Forms.CheckBox
    Friend WithEvents pnlHistory As System.Windows.Forms.Panel
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents dgvAnnouncements As System.Windows.Forms.DataGridView
End Class