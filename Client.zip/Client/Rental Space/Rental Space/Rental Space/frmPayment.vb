﻿Imports System.Data.OleDb

Public Class frmPayment

    Public selectedTenantID As Integer = 0
    Public targetRoom As String = ""
    Private pendingBillIDs As String = ""

    Private Sub frmPayment_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ClearFields()
        LoadTenants()

        If selectedTenantID > 0 Then
            AutoSelectTenant()
        End If
    End Sub

    Private Sub ClearFields()
        pendingBillIDs = ""
        cmbTenant.SelectedIndex = -1
        txtRoom.Clear()
        txtAmountDue.Text = "0.00"
        txtAmountPaid.Clear()
        If cmbPaymentMethod.Items.Count > 0 Then
            cmbPaymentMethod.SelectedIndex = 0
        End If
        txtReference.Clear()
        txtReference.Enabled = False
        txtReference.BackColor = Color.WhiteSmoke
        dtpPaymentDate.Value = DateTime.Now
        dtpPaymentDate.Enabled = False
    End Sub

    Private Sub frmPayment_FormClosed(sender As Object, e As FormClosedEventArgs) Handles MyBase.FormClosed
        selectedTenantID = 0
        targetRoom = ""
        ClearFields()
    End Sub

    Private Sub AutoSelectTenant()
        Using myConn As New OleDbConnection(ConnectionString)
            Try
                myConn.Open()
                Dim sql As String = "SELECT FullName FROM tblTenants WHERE TenantID = @tid"
                Dim cmd As New OleDbCommand(sql, myConn)
                cmd.Parameters.AddWithValue("@tid", selectedTenantID)
                Dim tName As Object = cmd.ExecuteScalar()

                If tName IsNot Nothing AndAlso Not IsDBNull(tName) Then
                    cmbTenant.Text = tName.ToString()
                End If
            Catch ex As Exception
            End Try
        End Using
    End Sub

    Private Sub LoadTenants()
        cmbTenant.Items.Clear()
        Using myConn As New OleDbConnection(ConnectionString)
            Try
                myConn.Open()
                Dim sql As String = "SELECT FullName FROM tblTenants WHERE Status = 'Active'"
                Dim cmd As New OleDbCommand(sql, myConn)
                Dim reader As OleDbDataReader = cmd.ExecuteReader()

                While reader.Read()
                    cmbTenant.Items.Add(reader("FullName").ToString())
                End While
                reader.Close()
            Catch ex As Exception
                MsgBox("Error: " & ex.Message, MsgBoxStyle.Critical)
            End Try
        End Using
    End Sub

    Private Sub cmbTenant_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbTenant.SelectedIndexChanged
        selectedTenantID = 0
        pendingBillIDs = ""
        txtRoom.Text = ""
        txtAmountDue.Text = "0.00"

        If cmbTenant.Text = "" Then Exit Sub

        Using myConn As New OleDbConnection(ConnectionString)
            Try
                myConn.Open()
                Dim sqlTenant As String = "SELECT t.TenantID, r.RoomNumber FROM tblTenants t INNER JOIN tblRooms r ON t.RoomID = r.RoomID WHERE t.FullName = @fname AND t.Status = 'Active'"
                Dim cmdTenant As New OleDbCommand(sqlTenant, myConn)
                cmdTenant.Parameters.AddWithValue("@fname", cmbTenant.Text)
                Dim reader As OleDbDataReader = cmdTenant.ExecuteReader()

                If reader.Read() Then
                    selectedTenantID = Convert.ToInt32(reader("TenantID"))
                    txtRoom.Text = reader("RoomNumber").ToString()
                End If
                reader.Close()

                If selectedTenantID > 0 Then
                    Dim sqlBill As String = "SELECT [BillID], [Balance] FROM tblBillings WHERE TenantID = @tid AND ([IsPaid] = 'No' OR [IsPaid] = 'Partial') ORDER BY [BillingMonth] ASC"
                    Dim cmdBill As New OleDbCommand(sqlBill, myConn)
                    cmdBill.Parameters.AddWithValue("@tid", selectedTenantID)
                    Dim readerBill As OleDbDataReader = cmdBill.ExecuteReader()

                    Dim totalDue As Decimal = 0
                    Dim idList As New List(Of String)

                    While readerBill.Read()
                        If Not IsDBNull(readerBill("Balance")) Then
                            totalDue += Convert.ToDecimal(readerBill("Balance"))
                            idList.Add(readerBill("BillID").ToString())
                        End If
                    End While
                    readerBill.Close()

                    txtAmountDue.Text = totalDue.ToString("N2")
                    pendingBillIDs = String.Join(", ", idList)
                End If

            Catch ex As Exception
                MsgBox("Error fetching balance: " & ex.Message, MsgBoxStyle.Critical)
            End Try
        End Using
    End Sub

    Private Sub cmbPaymentMethod_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbPaymentMethod.SelectedIndexChanged
        If cmbPaymentMethod.Text = "Cash" Then
            txtReference.Clear()
            txtReference.Enabled = False
            txtReference.BackColor = Color.WhiteSmoke
        Else
            txtReference.Enabled = True
            txtReference.BackColor = Color.White
        End If
    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        Me.Close()
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        If String.IsNullOrWhiteSpace(cmbTenant.Text) Then
            MsgBox("Please select a tenant.", MsgBoxStyle.Exclamation)
            cmbTenant.Focus()
            Exit Sub
        End If

        If String.IsNullOrWhiteSpace(txtAmountPaid.Text) OrElse Not IsNumeric(txtAmountPaid.Text) Then
            MsgBox("Please enter a valid amount.", MsgBoxStyle.Exclamation)
            txtAmountPaid.Focus()
            Exit Sub
        End If

        Dim paymentLeft As Decimal = Convert.ToDecimal(txtAmountPaid.Text)
        If paymentLeft <= 0 Then
            MsgBox("Ang bayad ay dapat higit sa zero.", MsgBoxStyle.Exclamation)
            Exit Sub
        End If

        If cmbPaymentMethod.Text <> "Cash" AndAlso String.IsNullOrWhiteSpace(txtReference.Text) Then
            MsgBox("Please enter Reference Number.", MsgBoxStyle.Exclamation)
            txtReference.Focus()
            Exit Sub
        End If

        If selectedTenantID = 0 OrElse String.IsNullOrWhiteSpace(pendingBillIDs) Then
            MsgBox("No pending bills found for this tenant.", MsgBoxStyle.Exclamation)
            Exit Sub
        End If

        Using myConn As New OleDbConnection(ConnectionString)
            Try
                myConn.Open()
                Dim trans = myConn.BeginTransaction()

                Dim newOR As Integer = 10001
                Dim sqlOR As String = "SELECT MAX(OR_Number) FROM tblPayments"
                Dim cmdOR As New OleDbCommand(sqlOR, myConn, trans)
                Dim maxOR = cmdOR.ExecuteScalar()
                If Not IsDBNull(maxOR) AndAlso maxOR IsNot Nothing Then
                    If Convert.ToInt32(maxOR) > 0 Then
                        newOR = Convert.ToInt32(maxOR) + 1
                    End If
                End If

                Dim sqlInsert As String = "INSERT INTO tblPayments ([BillID], [AmountPaid], [DatePaid], [OR_Number], [TenantName], [RoomNumber], [PaymentMethod], [ReferenceNo]) VALUES (@bill, @amt, @dpaid, @ornum, @tname, @room, @pmethod, @ref)"
                Dim cmdInsert As New OleDbCommand(sqlInsert, myConn, trans)
                cmdInsert.Parameters.AddWithValue("@bill", pendingBillIDs)
                cmdInsert.Parameters.AddWithValue("@amt", Convert.ToDecimal(txtAmountPaid.Text))
                cmdInsert.Parameters.AddWithValue("@dpaid", dtpPaymentDate.Value.Date)
                cmdInsert.Parameters.AddWithValue("@ornum", newOR)
                cmdInsert.Parameters.AddWithValue("@tname", cmbTenant.Text)
                cmdInsert.Parameters.AddWithValue("@room", txtRoom.Text)
                cmdInsert.Parameters.AddWithValue("@pmethod", cmbPaymentMethod.Text)
                cmdInsert.Parameters.AddWithValue("@ref", txtReference.Text)
                cmdInsert.ExecuteNonQuery()

                Dim cmdGetBills As New OleDbCommand("SELECT [BillID], [Balance] FROM tblBillings WHERE TenantID = @tid AND ([IsPaid] = 'No' OR [IsPaid] = 'Partial') ORDER BY [BillingMonth] ASC", myConn, trans)
                cmdGetBills.Parameters.AddWithValue("@tid", selectedTenantID)
                Dim reader = cmdGetBills.ExecuteReader()

                Dim updates As New Dictionary(Of Integer, Tuple(Of Decimal, String))()

                While reader.Read()
                    Dim bID = Convert.ToInt32(reader("BillID"))
                    Dim bal = Convert.ToDecimal(reader("Balance"))

                    If paymentLeft >= bal Then
                        updates.Add(bID, New Tuple(Of Decimal, String)(0, "Yes"))
                        paymentLeft -= bal
                    ElseIf paymentLeft > 0 Then
                        updates.Add(bID, New Tuple(Of Decimal, String)(bal - paymentLeft, "Partial"))
                        paymentLeft = 0
                    End If
                End While
                reader.Close()

                For Each kvp In updates
                    Dim cmdUpd As New OleDbCommand("UPDATE tblBillings SET [Balance] = @bal, [IsPaid] = @stat WHERE [BillID] = @bid", myConn, trans)
                    cmdUpd.Parameters.AddWithValue("@bal", kvp.Value.Item1)
                    cmdUpd.Parameters.AddWithValue("@stat", kvp.Value.Item2)
                    cmdUpd.Parameters.AddWithValue("@bid", kvp.Key)
                    cmdUpd.ExecuteNonQuery()
                Next

                trans.Commit()
                MsgBox("Payment successfully recorded! OR Number: " & newOR, MsgBoxStyle.Information)
                Me.Close()
            Catch ex As Exception
                MsgBox("Error processing payment: " & ex.Message, MsgBoxStyle.Critical)
            End Try
        End Using
    End Sub

    Private Sub txtAmountPaid_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtAmountPaid.KeyPress
        If Not Char.IsControl(e.KeyChar) AndAlso Not Char.IsDigit(e.KeyChar) AndAlso e.KeyChar <> "."c Then
            e.Handled = True
        End If

        If e.KeyChar = "."c AndAlso txtAmountPaid.Text.IndexOf("."c) > -1 Then
            e.Handled = True
        End If
    End Sub

End Class