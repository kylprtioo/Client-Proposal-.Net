﻿Imports System.Data.OleDb

Public Class frmPayment

    Private selectedTenantID As Integer = 0
    Private pendingBillIDs As String = ""

    Private Sub frmPayment_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ClearFields()
        LoadTenants()
    End Sub

    Private Sub ClearFields()
        selectedTenantID = 0
        pendingBillIDs = ""
        cmbTenant.SelectedIndex = -1
        txtRoom.Clear()
        txtAmountDue.Text = "0.00"
        txtAmountPaid.Clear()
        If cmbPaymentMethod.Items.Count > 0 Then
            cmbPaymentMethod.SelectedIndex = 0
        End If
        txtReference.Clear()
        txtReference.Enabled = False
        txtReference.BackColor = Color.WhiteSmoke
        dtpPaymentDate.Value = DateTime.Now
    End Sub

    Private Sub frmPayment_FormClosed(sender As Object, e As FormClosedEventArgs) Handles MyBase.FormClosed
        ClearFields()
    End Sub

    Private Sub LoadTenants()
        cmbTenant.Items.Clear()
        Using myConn As New OleDbConnection(ConnectionString)
            Try
                myConn.Open()
                Dim sql As String = "SELECT FullName FROM tblTenants WHERE Status = 'Active'"
                Dim cmd As New OleDbCommand(sql, myConn)
                Dim reader As OleDbDataReader = cmd.ExecuteReader()

                While reader.Read()
                    cmbTenant.Items.Add(reader("FullName").ToString())
                End While
                reader.Close()
            Catch ex As Exception
                MsgBox("Error: " & ex.Message, MsgBoxStyle.Critical)
            End Try
        End Using
    End Sub

    Private Sub cmbTenant_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbTenant.SelectedIndexChanged
        selectedTenantID = 0
        pendingBillIDs = ""
        txtRoom.Text = ""
        txtAmountDue.Text = "0.00"

        If cmbTenant.Text = "" Then Exit Sub

        Using myConn As New OleDbConnection(ConnectionString)
            Try
                myConn.Open()

                Dim sqlTenant As String = "SELECT t.TenantID, r.RoomNumber FROM tblTenants t INNER JOIN tblRooms r ON t.RoomID = r.RoomID WHERE t.FullName = @fname AND t.Status = 'Active'"
                Dim cmdTenant As New OleDbCommand(sqlTenant, myConn)
                cmdTenant.Parameters.AddWithValue("@fname", cmbTenant.Text)
                Dim reader As OleDbDataReader = cmdTenant.ExecuteReader()

                If reader.Read() Then
                    selectedTenantID = Convert.ToInt32(reader("TenantID"))
                    txtRoom.Text = reader("RoomNumber").ToString()
                End If
                reader.Close()

                If selectedTenantID > 0 Then
                    Dim sqlBill As String = "SELECT BillID, TotalAmount FROM tblBillings WHERE TenantID = @tid AND IsPaid = 'No'"
                    Dim cmdBill As New OleDbCommand(sqlBill, myConn)
                    cmdBill.Parameters.AddWithValue("@tid", selectedTenantID)
                    Dim readerBill As OleDbDataReader = cmdBill.ExecuteReader()

                    Dim totalDue As Decimal = 0
                    Dim idList As New List(Of String)

                    While readerBill.Read()
                        totalDue += Convert.ToDecimal(readerBill("TotalAmount"))
                        idList.Add(readerBill("BillID").ToString())
                    End While
                    readerBill.Close()

                    txtAmountDue.Text = totalDue.ToString("N2")
                    pendingBillIDs = String.Join(", ", idList)
                End If

            Catch ex As Exception
                MsgBox("Error: " & ex.Message, MsgBoxStyle.Critical)
            End Try
        End Using
    End Sub

    Private Sub cmbPaymentMethod_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbPaymentMethod.SelectedIndexChanged
        If cmbPaymentMethod.Text = "Cash" Then
            txtReference.Clear()
            txtReference.Enabled = False
            txtReference.BackColor = Color.WhiteSmoke
        Else
            txtReference.Enabled = True
            txtReference.BackColor = Color.White
        End If
    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        Me.Close()
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        If String.IsNullOrWhiteSpace(cmbTenant.Text) Then
            MsgBox("Please select a tenant.", MsgBoxStyle.Exclamation)
            cmbTenant.Focus()
            Exit Sub
        End If

        If String.IsNullOrWhiteSpace(txtAmountPaid.Text) OrElse Not IsNumeric(txtAmountPaid.Text) Then
            MsgBox("Please enter a valid amount.", MsgBoxStyle.Exclamation)
            txtAmountPaid.Focus()
            Exit Sub
        End If

        If cmbPaymentMethod.Text <> "Cash" AndAlso String.IsNullOrWhiteSpace(txtReference.Text) Then
            MsgBox("Please enter Reference Number.", MsgBoxStyle.Exclamation)
            txtReference.Focus()
            Exit Sub
        End If

        If selectedTenantID = 0 OrElse String.IsNullOrWhiteSpace(pendingBillIDs) Then
            MsgBox("No pending bills found for this tenant.", MsgBoxStyle.Exclamation)
            Exit Sub
        End If

        Using myConn As New OleDbConnection(ConnectionString)
            Try
                myConn.Open()

                Dim newOR As Integer = 10001
                Dim sqlOR As String = "SELECT MAX(OR_Number) FROM tblPayments"
                Dim cmdOR As New OleDbCommand(sqlOR, myConn)
                Dim maxOR = cmdOR.ExecuteScalar()
                If Not IsDBNull(maxOR) AndAlso maxOR IsNot Nothing Then
                    If Convert.ToInt32(maxOR) > 0 Then
                        newOR = Convert.ToInt32(maxOR) + 1
                    End If
                End If

                Dim sqlInsert As String = "INSERT INTO tblPayments ([BillID], [AmountPaid], [DatePaid], [OR_Number], [TenantName], [RoomNumber], [PaymentMethod], [ReferenceNo]) VALUES (@bill, @amt, @dpaid, @ornum, @tname, @room, @pmethod, @ref)"
                Dim cmdInsert As New OleDbCommand(sqlInsert, myConn)
                cmdInsert.Parameters.AddWithValue("@bill", pendingBillIDs)
                cmdInsert.Parameters.AddWithValue("@amt", Convert.ToDecimal(txtAmountPaid.Text))
                cmdInsert.Parameters.AddWithValue("@dpaid", dtpPaymentDate.Value.Date)
                cmdInsert.Parameters.AddWithValue("@ornum", newOR)
                cmdInsert.Parameters.AddWithValue("@tname", cmbTenant.Text)
                cmdInsert.Parameters.AddWithValue("@room", txtRoom.Text)
                cmdInsert.Parameters.AddWithValue("@pmethod", cmbPaymentMethod.Text)
                cmdInsert.Parameters.AddWithValue("@ref", txtReference.Text)
                cmdInsert.ExecuteNonQuery()

                Dim sqlUpdate As String = "UPDATE tblBillings SET IsPaid = 'Yes' WHERE TenantID = @tid AND IsPaid = 'No'"
                Dim cmdUpdate As New OleDbCommand(sqlUpdate, myConn)
                cmdUpdate.Parameters.AddWithValue("@tid", selectedTenantID)
                cmdUpdate.ExecuteNonQuery()

                MsgBox("Payment saved! OR Number: " & newOR, MsgBoxStyle.Information)
                Me.Close()
            Catch ex As Exception
                MsgBox("Error: " & ex.Message, MsgBoxStyle.Critical)
            End Try
        End Using
    End Sub

    Private Sub txtAmountPaid_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtAmountPaid.KeyPress
        If Not Char.IsControl(e.KeyChar) AndAlso Not Char.IsDigit(e.KeyChar) AndAlso e.KeyChar <> "."c Then
            e.Handled = True
        End If

        If e.KeyChar = "."c AndAlso txtAmountPaid.Text.IndexOf("."c) > -1 Then
            e.Handled = True
        End If
    End Sub

End Class