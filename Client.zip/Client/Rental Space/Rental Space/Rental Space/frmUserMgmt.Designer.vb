﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmUserMgmt
    Inherits System.Windows.Forms.Form

    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    Private components As System.ComponentModel.IContainer

    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.pnlInput = New System.Windows.Forms.Panel()
        Me.LabelFirst = New System.Windows.Forms.Label()
        Me.txtFirstName = New System.Windows.Forms.TextBox()
        Me.LabelMiddle = New System.Windows.Forms.Label()
        Me.txtMiddleName = New System.Windows.Forms.TextBox()
        Me.LabelLast = New System.Windows.Forms.Label()
        Me.txtLastName = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtUsername = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtPassword = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.cmbRole = New System.Windows.Forms.ComboBox()
        Me.btnSave = New System.Windows.Forms.Button()
        Me.btnUpdate = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnArchive = New System.Windows.Forms.Button()
        Me.lblInputTitle = New System.Windows.Forms.Label()
        Me.pnlTop = New System.Windows.Forms.Panel()
        Me.lblViewStatus = New System.Windows.Forms.Label()
        Me.btnViewArchive = New System.Windows.Forms.Button()
        Me.btnRefresh = New System.Windows.Forms.Button()
        Me.txtSearch = New System.Windows.Forms.TextBox()
        Me.lblSearch = New System.Windows.Forms.Label()
        Me.lblMainTitle = New System.Windows.Forms.Label()
        Me.dgvUsers = New System.Windows.Forms.DataGridView()
        Me.pnlInput.SuspendLayout()
        Me.pnlTop.SuspendLayout()
        CType(Me.dgvUsers, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'pnlInput
        '
        Me.pnlInput.BackColor = System.Drawing.Color.White
        Me.pnlInput.Controls.Add(Me.LabelFirst)
        Me.pnlInput.Controls.Add(Me.txtFirstName)
        Me.pnlInput.Controls.Add(Me.LabelMiddle)
        Me.pnlInput.Controls.Add(Me.txtMiddleName)
        Me.pnlInput.Controls.Add(Me.LabelLast)
        Me.pnlInput.Controls.Add(Me.txtLastName)
        Me.pnlInput.Controls.Add(Me.Label2)
        Me.pnlInput.Controls.Add(Me.txtUsername)
        Me.pnlInput.Controls.Add(Me.Label3)
        Me.pnlInput.Controls.Add(Me.txtPassword)
        Me.pnlInput.Controls.Add(Me.Label4)
        Me.pnlInput.Controls.Add(Me.cmbRole)
        Me.pnlInput.Controls.Add(Me.btnSave)
        Me.pnlInput.Controls.Add(Me.btnUpdate)
        Me.pnlInput.Controls.Add(Me.btnClear)
        Me.pnlInput.Controls.Add(Me.btnArchive)
        Me.pnlInput.Controls.Add(Me.lblInputTitle)
        Me.pnlInput.Dock = System.Windows.Forms.DockStyle.Left
        Me.pnlInput.Location = New System.Drawing.Point(0, 0)
        Me.pnlInput.Name = "pnlInput"
        Me.pnlInput.Padding = New System.Windows.Forms.Padding(20)
        Me.pnlInput.Size = New System.Drawing.Size(320, 680)
        Me.pnlInput.TabIndex = 0
        '
        'LabelFirst
        '
        Me.LabelFirst.AutoSize = True
        Me.LabelFirst.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.LabelFirst.ForeColor = System.Drawing.Color.Gray
        Me.LabelFirst.Location = New System.Drawing.Point(20, 65)
        Me.LabelFirst.Name = "LabelFirst"
        Me.LabelFirst.Size = New System.Drawing.Size(67, 15)
        Me.LabelFirst.TabIndex = 1
        Me.LabelFirst.Text = "First Name:"
        '
        'txtFirstName
        '
        Me.txtFirstName.Font = New System.Drawing.Font("Segoe UI", 11.0!)
        Me.txtFirstName.Location = New System.Drawing.Point(23, 85)
        Me.txtFirstName.Name = "txtFirstName"
        Me.txtFirstName.Size = New System.Drawing.Size(275, 27)
        Me.txtFirstName.TabIndex = 1
        '
        'LabelMiddle
        '
        Me.LabelMiddle.AutoSize = True
        Me.LabelMiddle.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.LabelMiddle.ForeColor = System.Drawing.Color.Gray
        Me.LabelMiddle.Location = New System.Drawing.Point(20, 125)
        Me.LabelMiddle.Name = "LabelMiddle"
        Me.LabelMiddle.Size = New System.Drawing.Size(82, 15)
        Me.LabelMiddle.TabIndex = 3
        Me.LabelMiddle.Text = "Middle Name:"
        '
        'txtMiddleName
        '
        Me.txtMiddleName.Font = New System.Drawing.Font("Segoe UI", 11.0!)
        Me.txtMiddleName.Location = New System.Drawing.Point(23, 145)
        Me.txtMiddleName.Name = "txtMiddleName"
        Me.txtMiddleName.Size = New System.Drawing.Size(275, 27)
        Me.txtMiddleName.TabIndex = 2
        '
        'LabelLast
        '
        Me.LabelLast.AutoSize = True
        Me.LabelLast.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.LabelLast.ForeColor = System.Drawing.Color.Gray
        Me.LabelLast.Location = New System.Drawing.Point(20, 185)
        Me.LabelLast.Name = "LabelLast"
        Me.LabelLast.Size = New System.Drawing.Size(66, 15)
        Me.LabelLast.TabIndex = 5
        Me.LabelLast.Text = "Last Name:"
        '
        'txtLastName
        '
        Me.txtLastName.Font = New System.Drawing.Font("Segoe UI", 11.0!)
        Me.txtLastName.Location = New System.Drawing.Point(23, 205)
        Me.txtLastName.Name = "txtLastName"
        Me.txtLastName.Size = New System.Drawing.Size(275, 27)
        Me.txtLastName.TabIndex = 3
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Label2.ForeColor = System.Drawing.Color.Gray
        Me.Label2.Location = New System.Drawing.Point(20, 245)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(63, 15)
        Me.Label2.TabIndex = 7
        Me.Label2.Text = "Username:"
        '
        'txtUsername
        '
        Me.txtUsername.Font = New System.Drawing.Font("Segoe UI", 11.0!)
        Me.txtUsername.Location = New System.Drawing.Point(23, 265)
        Me.txtUsername.Name = "txtUsername"
        Me.txtUsername.Size = New System.Drawing.Size(275, 27)
        Me.txtUsername.TabIndex = 4
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Label3.ForeColor = System.Drawing.Color.Gray
        Me.Label3.Location = New System.Drawing.Point(20, 305)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(60, 15)
        Me.Label3.TabIndex = 9
        Me.Label3.Text = "Password:"
        '
        'txtPassword
        '
        Me.txtPassword.Font = New System.Drawing.Font("Segoe UI", 11.0!)
        Me.txtPassword.Location = New System.Drawing.Point(23, 325)
        Me.txtPassword.Name = "txtPassword"
        Me.txtPassword.PasswordChar = Global.Microsoft.VisualBasic.ChrW(8226)
        Me.txtPassword.Size = New System.Drawing.Size(275, 27)
        Me.txtPassword.TabIndex = 5
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Label4.ForeColor = System.Drawing.Color.Gray
        Me.Label4.Location = New System.Drawing.Point(20, 365)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(60, 15)
        Me.Label4.TabIndex = 11
        Me.Label4.Text = "User Role:"
        '
        'cmbRole
        '
        Me.cmbRole.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbRole.Font = New System.Drawing.Font("Segoe UI", 11.0!)
        Me.cmbRole.FormattingEnabled = True
        Me.cmbRole.Items.AddRange(New Object() {"Manager", "Security", "Admin"})
        Me.cmbRole.Location = New System.Drawing.Point(23, 385)
        Me.cmbRole.Name = "cmbRole"
        Me.cmbRole.Size = New System.Drawing.Size(275, 28)
        Me.cmbRole.TabIndex = 6
        '
        'btnSave
        '
        Me.btnSave.BackColor = System.Drawing.Color.SeaGreen
        Me.btnSave.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnSave.FlatAppearance.BorderSize = 0
        Me.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnSave.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold)
        Me.btnSave.ForeColor = System.Drawing.Color.White
        Me.btnSave.Location = New System.Drawing.Point(23, 440)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(275, 40)
        Me.btnSave.TabIndex = 7
        Me.btnSave.Text = "SAVE USER"
        Me.btnSave.UseVisualStyleBackColor = False
        '
        'btnUpdate
        '
        Me.btnUpdate.BackColor = System.Drawing.Color.FromArgb(CByte(31), CByte(97), CByte(141))
        Me.btnUpdate.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnUpdate.FlatAppearance.BorderSize = 0
        Me.btnUpdate.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnUpdate.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold)
        Me.btnUpdate.ForeColor = System.Drawing.Color.White
        Me.btnUpdate.Location = New System.Drawing.Point(23, 490)
        Me.btnUpdate.Name = "btnUpdate"
        Me.btnUpdate.Size = New System.Drawing.Size(275, 40)
        Me.btnUpdate.TabIndex = 8
        Me.btnUpdate.Text = "UPDATE"
        Me.btnUpdate.UseVisualStyleBackColor = False
        '
        'btnClear
        '
        Me.btnClear.BackColor = System.Drawing.Color.FromArgb(CByte(226), CByte(232), CByte(240))
        Me.btnClear.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnClear.FlatAppearance.BorderSize = 0
        Me.btnClear.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnClear.Font = New System.Drawing.Font("Segoe UI Semibold", 10.0!)
        Me.btnClear.ForeColor = System.Drawing.Color.FromArgb(CByte(31), CByte(41), CByte(55))
        Me.btnClear.Location = New System.Drawing.Point(23, 540)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(275, 40)
        Me.btnClear.TabIndex = 9
        Me.btnClear.Text = "CLEAR"
        Me.btnClear.UseVisualStyleBackColor = False
        '
        'btnArchive
        '
        Me.btnArchive.BackColor = System.Drawing.Color.FromArgb(CByte(192), CByte(57), CByte(43))
        Me.btnArchive.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnArchive.FlatAppearance.BorderSize = 0
        Me.btnArchive.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnArchive.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold)
        Me.btnArchive.ForeColor = System.Drawing.Color.White
        Me.btnArchive.Location = New System.Drawing.Point(23, 590)
        Me.btnArchive.Name = "btnArchive"
        Me.btnArchive.Size = New System.Drawing.Size(275, 40)
        Me.btnArchive.TabIndex = 10
        Me.btnArchive.Text = "ARCHIVE USER"
        Me.btnArchive.UseVisualStyleBackColor = False
        '
        'lblInputTitle
        '
        Me.lblInputTitle.AutoSize = True
        Me.lblInputTitle.Font = New System.Drawing.Font("Segoe UI", 14.0!, System.Drawing.FontStyle.Bold)
        Me.lblInputTitle.ForeColor = System.Drawing.Color.FromArgb(CByte(31), CByte(97), CByte(141))
        Me.lblInputTitle.Location = New System.Drawing.Point(20, 20)
        Me.lblInputTitle.Name = "lblInputTitle"
        Me.lblInputTitle.Size = New System.Drawing.Size(155, 25)
        Me.lblInputTitle.TabIndex = 0
        Me.lblInputTitle.Text = "User Form Setup"
        '
        'pnlTop
        '
        Me.pnlTop.BackColor = System.Drawing.Color.FromArgb(CByte(243), CByte(244), CByte(246))
        Me.pnlTop.Controls.Add(Me.lblViewStatus)
        Me.pnlTop.Controls.Add(Me.btnViewArchive)
        Me.pnlTop.Controls.Add(Me.btnRefresh)
        Me.pnlTop.Controls.Add(Me.txtSearch)
        Me.pnlTop.Controls.Add(Me.lblSearch)
        Me.pnlTop.Controls.Add(Me.lblMainTitle)
        Me.pnlTop.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlTop.Location = New System.Drawing.Point(320, 0)
        Me.pnlTop.Name = "pnlTop"
        Me.pnlTop.Size = New System.Drawing.Size(730, 80)
        Me.pnlTop.TabIndex = 1
        '
        'lblViewStatus
        '
        Me.lblViewStatus.AutoSize = True
        Me.lblViewStatus.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold)
        Me.lblViewStatus.ForeColor = System.Drawing.Color.FromArgb(CByte(31), CByte(97), CByte(141))
        Me.lblViewStatus.Location = New System.Drawing.Point(20, 52)
        Me.lblViewStatus.Name = "lblViewStatus"
        Me.lblViewStatus.Size = New System.Drawing.Size(126, 19)
        Me.lblViewStatus.TabIndex = 5
        Me.lblViewStatus.Text = "VIEWING: ACTIVE"
        '
        'btnViewArchive
        '
        Me.btnViewArchive.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnViewArchive.BackColor = System.Drawing.Color.FromArgb(CByte(44), CByte(62), CByte(80))
        Me.btnViewArchive.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnViewArchive.FlatAppearance.BorderSize = 0
        Me.btnViewArchive.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnViewArchive.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold)
        Me.btnViewArchive.ForeColor = System.Drawing.Color.White
        Me.btnViewArchive.Location = New System.Drawing.Point(480, 25)
        Me.btnViewArchive.Name = "btnViewArchive"
        Me.btnViewArchive.Size = New System.Drawing.Size(120, 30)
        Me.btnViewArchive.TabIndex = 4
        Me.btnViewArchive.Text = "VIEW ARCHIVE"
        Me.btnViewArchive.UseVisualStyleBackColor = False
        '
        'btnRefresh
        '
        Me.btnRefresh.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnRefresh.BackColor = System.Drawing.Color.FromArgb(CByte(31), CByte(97), CByte(141))
        Me.btnRefresh.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnRefresh.FlatAppearance.BorderSize = 0
        Me.btnRefresh.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnRefresh.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold)
        Me.btnRefresh.ForeColor = System.Drawing.Color.White
        Me.btnRefresh.Location = New System.Drawing.Point(610, 25)
        Me.btnRefresh.Name = "btnRefresh"
        Me.btnRefresh.Size = New System.Drawing.Size(90, 30)
        Me.btnRefresh.TabIndex = 3
        Me.btnRefresh.Text = "REFRESH"
        Me.btnRefresh.UseVisualStyleBackColor = False
        '
        'txtSearch
        '
        Me.txtSearch.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtSearch.Font = New System.Drawing.Font("Segoe UI", 11.0!)
        Me.txtSearch.Location = New System.Drawing.Point(260, 27)
        Me.txtSearch.Name = "txtSearch"
        Me.txtSearch.Size = New System.Drawing.Size(200, 27)
        Me.txtSearch.TabIndex = 2
        '
        'lblSearch
        '
        Me.lblSearch.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblSearch.AutoSize = True
        Me.lblSearch.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.lblSearch.Location = New System.Drawing.Point(205, 31)
        Me.lblSearch.Name = "lblSearch"
        Me.lblSearch.Size = New System.Drawing.Size(52, 19)
        Me.lblSearch.TabIndex = 1
        Me.lblSearch.Text = "Search:"
        '
        'lblMainTitle
        '
        Me.lblMainTitle.AutoSize = True
        Me.lblMainTitle.Font = New System.Drawing.Font("Segoe UI", 18.0!, System.Drawing.FontStyle.Bold)
        Me.lblMainTitle.ForeColor = System.Drawing.Color.FromArgb(CByte(31), CByte(41), CByte(55))
        Me.lblMainTitle.Location = New System.Drawing.Point(20, 22)
        Me.lblMainTitle.Name = "lblMainTitle"
        Me.lblMainTitle.Size = New System.Drawing.Size(185, 32)
        Me.lblMainTitle.TabIndex = 0
        Me.lblMainTitle.Text = "Manage Personnel"
        '
        'dgvUsers
        '
        Me.dgvUsers.AllowUserToAddRows = False
        Me.dgvUsers.AllowUserToDeleteRows = False
        Me.dgvUsers.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.dgvUsers.BackgroundColor = System.Drawing.Color.White
        Me.dgvUsers.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.dgvUsers.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(CByte(243), CByte(244), CByte(246))
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Segoe UI Semibold", 10.0!, System.Drawing.FontStyle.Bold)
        DataGridViewCellStyle1.ForeColor = System.Drawing.Color.FromArgb(CByte(31), CByte(41), CByte(55))
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.FromArgb(CByte(243), CByte(244), CByte(246))
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.FromArgb(CByte(31), CByte(41), CByte(55))
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgvUsers.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.dgvUsers.ColumnHeadersHeight = 40
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.Color.White
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        DataGridViewCellStyle2.ForeColor = System.Drawing.Color.FromArgb(CByte(31), CByte(41), CByte(55))
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(CByte(31), CByte(97), CByte(141))
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.White
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgvUsers.DefaultCellStyle = DataGridViewCellStyle2
        Me.dgvUsers.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgvUsers.EnableHeadersVisualStyles = False
        Me.dgvUsers.Location = New System.Drawing.Point(320, 80)
        Me.dgvUsers.Name = "dgvUsers"
        Me.dgvUsers.ReadOnly = True
        Me.dgvUsers.RowHeadersVisible = False
        Me.dgvUsers.RowTemplate.Height = 35
        Me.dgvUsers.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgvUsers.Size = New System.Drawing.Size(730, 600)
        Me.dgvUsers.TabIndex = 2
        '
        'frmUserMgmt
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 17.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(1050, 680)
        Me.Controls.Add(Me.dgvUsers)
        Me.Controls.Add(Me.pnlTop)
        Me.Controls.Add(Me.pnlInput)
        Me.Font = New System.Drawing.Font("Segoe UI", 9.75!)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.Name = "frmUserMgmt"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Security Personnel Management"
        Me.pnlInput.ResumeLayout(False)
        Me.pnlInput.PerformLayout()
        Me.pnlTop.ResumeLayout(False)
        Me.pnlTop.PerformLayout()
        CType(Me.dgvUsers, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents pnlInput As System.Windows.Forms.Panel
    Friend WithEvents lblInputTitle As System.Windows.Forms.Label
    Friend WithEvents txtFirstName As System.Windows.Forms.TextBox
    Friend WithEvents LabelFirst As System.Windows.Forms.Label
    Friend WithEvents txtMiddleName As System.Windows.Forms.TextBox
    Friend WithEvents LabelMiddle As System.Windows.Forms.Label
    Friend WithEvents txtLastName As System.Windows.Forms.TextBox
    Friend WithEvents LabelLast As System.Windows.Forms.Label
    Friend WithEvents txtUsername As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtPassword As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents cmbRole As System.Windows.Forms.ComboBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents btnSave As System.Windows.Forms.Button
    Friend WithEvents btnUpdate As System.Windows.Forms.Button
    Friend WithEvents btnClear As System.Windows.Forms.Button
    Friend WithEvents btnArchive As System.Windows.Forms.Button
    Friend WithEvents pnlTop As System.Windows.Forms.Panel
    Friend WithEvents lblMainTitle As System.Windows.Forms.Label
    Friend WithEvents txtSearch As System.Windows.Forms.TextBox
    Friend WithEvents lblSearch As System.Windows.Forms.Label
    Friend WithEvents btnRefresh As System.Windows.Forms.Button
    Friend WithEvents btnViewArchive As System.Windows.Forms.Button
    Friend WithEvents lblViewStatus As System.Windows.Forms.Label
    Friend WithEvents dgvUsers As System.Windows.Forms.DataGridView
End Class