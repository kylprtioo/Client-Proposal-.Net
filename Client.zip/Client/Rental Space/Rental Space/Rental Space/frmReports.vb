﻿Imports System.Data.OleDb
Imports System.IO
Imports iTextSharp.text
Imports iTextSharp.text.pdf
Imports Excel = Microsoft.Office.Interop.Excel

Public Class frmReports

    Private Sub frmReports_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        dtpReportMonth.Format = DateTimePickerFormat.Custom
        dtpReportMonth.CustomFormat = "MMMM yyyy"
        RefreshReportData()
    End Sub

    Private Sub RefreshReportData()
        LoadMonthlyReport()
        LoadOccupancyStats()
    End Sub

    Private Sub LoadMonthlyReport()
        Using myConn As New OleDbConnection(connString)
            Try
                Dim selectedDate As DateTime = dtpReportMonth.Value
                Dim sql As String = "SELECT t.[FullName], r.[RoomNumber], b.[BillingMonth], b.[TotalAmount], b.[IsPaid] " &
                                   "FROM (tblBillings AS b INNER JOIN tblTenants AS t ON b.ContractID = t.TenantID) " &
                                   "INNER JOIN tblRooms AS r ON t.RoomID = r.RoomID " &
                                   "WHERE MONTH(b.[BillingMonth]) = @month AND YEAR(b.[BillingMonth]) = @year"

                Dim cmd As New OleDbCommand(sql, myConn)
                cmd.Parameters.AddWithValue("@month", selectedDate.Month)
                cmd.Parameters.AddWithValue("@year", selectedDate.Year)

                Dim adapter As New OleDbDataAdapter(cmd)
                Dim dt As New DataTable
                adapter.Fill(dt)
                dgvReports.DataSource = dt

                Dim totalBilled As Decimal = 0
                Dim unpaidCount As Integer = 0

                For Each row As DataRow In dt.Rows
                    totalBilled += CDec(row("TotalAmount"))
                    If row("IsPaid").ToString().Trim() = "No" Then unpaidCount += 1
                Next

                lblTotalCollection.Text = "Total Billed for this Month: ₱" & totalBilled.ToString("N2")
                lblUnpaidCount.Text = unpaidCount.ToString()
                lblUnpaidCount.ForeColor = If(unpaidCount > 0, Color.Red, Color.SeaGreen)

            Catch ex As Exception
                MsgBox("Error loading reports: " & ex.Message, MsgBoxStyle.Critical)
            End Try
        End Using
    End Sub

    Private Sub LoadOccupancyStats()
        Using myConn As New OleDbConnection(connString)
            Try
                myConn.Open()
                Dim cmdOcc As New OleDbCommand("SELECT COUNT(*) FROM tblRooms WHERE [Status] = 'Occupied'", myConn)
                Dim cmdTotal As New OleDbCommand("SELECT COUNT(*) FROM tblRooms", myConn)
                Dim occupied As Integer = CInt(cmdOcc.ExecuteScalar())
                Dim totalRooms As Integer = CInt(cmdTotal.ExecuteScalar())
                Dim percentage As Integer = If(totalRooms > 0, Math.Round((occupied / totalRooms) * 100), 0)
                lblOccupancyRate.Text = String.Format("Occupancy: {0} / {1} Rooms ({2}%)", occupied, totalRooms, percentage)
            Catch ex As Exception
            End Try
        End Using
    End Sub

    Private Sub btnExportPDF_Click(sender As Object, e As EventArgs) Handles btnPrint.Click
        If dgvReports.Rows.Count = 0 Then
            MsgBox("Walang data na pwedeng i-print.", MsgBoxStyle.Exclamation)
            Exit Sub
        End If

        Dim sfd As New SaveFileDialog()
        sfd.Filter = "PDF Files (*.pdf)|*.pdf"
        sfd.FileName = "Report_" & dtpReportMonth.Value.ToString("MMMM_yyyy") & ".pdf"

        If sfd.ShowDialog() = DialogResult.OK Then
            Try
                Dim pdfTable As New PdfPTable(dgvReports.ColumnCount)
                pdfTable.DefaultCell.Padding = 3
                pdfTable.WidthPercentage = 100
                pdfTable.HorizontalAlignment = Element.ALIGN_LEFT

                For Each column As DataGridViewColumn In dgvReports.Columns
                    Dim cell As New PdfPCell(New Phrase(column.HeaderText))
                    cell.BackgroundColor = New BaseColor(240, 240, 240)
                    pdfTable.AddCell(cell)
                Next

                For Each row As DataGridViewRow In dgvReports.Rows
                    For Each cell As DataGridViewCell In row.Cells
                        pdfTable.AddCell(cell.Value.ToString())
                    Next
                Next

                Using stream As New FileStream(sfd.FileName, FileMode.Create)
                    Dim pdfDoc As New Document(PageSize.A4, 10.0F, 10.0F, 10.0F, 0.0F)
                    PdfWriter.GetInstance(pdfDoc, stream)
                    pdfDoc.Open()
                    pdfDoc.Add(New Phrase("CRISTINA'S PLACE - MONTHLY PERFORMANCE REPORT"))
                    pdfDoc.Add(New Phrase(Environment.NewLine))
                    pdfDoc.Add(New Phrase("Month: " & dtpReportMonth.Text))
                    pdfDoc.Add(New Phrase(Environment.NewLine & Environment.NewLine))
                    pdfDoc.Add(pdfTable)
                    pdfDoc.Add(New Phrase(Environment.NewLine & lblTotalCollection.Text))
                    pdfDoc.Close()
                    stream.Close()
                End Using

                MsgBox("PDF Report successfully generated!", MsgBoxStyle.Information)
            Catch ex As Exception
                MsgBox("Error: " & ex.Message)
            End Try
        End If
    End Sub

    Private Sub btnExportExcel_Click(sender As Object, e As EventArgs) Handles btnExport.Click
        If dgvReports.Rows.Count = 0 Then
            MessageBox.Show("Walang data na pwedeng i-export. Mag-generate muna ng report.", "Empty Report", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return
        End If

        Dim strFolder As String = "C:\Code\Rental Space"
        Dim strFilename As String = strFolder & "\MonthlyReport_" & dtpReportMonth.Value.ToString("MMMM_yyyy") & ".xlsx"

        Dim xlApp As Object = Nothing
        Dim xlWorkBook As Object = Nothing
        Dim xlWorkSheet As Object = Nothing

        Try
            If Not Directory.Exists(strFolder) Then
                Directory.CreateDirectory(strFolder)
            End If

            xlApp = CreateObject("Excel.Application")

            If Not File.Exists(strFilename) Then
                xlWorkBook = xlApp.Workbooks.Add
                xlWorkSheet = xlWorkBook.ActiveSheet
                xlWorkBook.SaveAs(strFilename)
            Else
                xlWorkBook = xlApp.Workbooks.Open(strFilename)
                xlWorkSheet = xlWorkBook.Worksheets(1)
            End If

            xlWorkSheet.Cells.ClearContents()

            For i As Integer = 0 To dgvReports.Columns.Count - 1
                xlWorkSheet.Cells(1, i + 1).Value = dgvReports.Columns(i).HeaderText
            Next

            For i As Integer = 0 To dgvReports.Rows.Count - 1
                For j As Integer = 0 To dgvReports.Columns.Count - 1
                    If dgvReports.Rows(i).Cells(j).Value IsNot Nothing Then
                        xlWorkSheet.Cells(i + 2, j + 1).Value = dgvReports.Rows(i).Cells(j).Value.ToString()
                    End If
                Next
            Next

            xlWorkSheet.Rows(1).Font.Bold = True
            xlWorkSheet.Columns.AutoFit()

            xlWorkBook.Save()
            xlApp.Visible = True
            MessageBox.Show("Report Successfully Exported to: " & strFilename, "Export Success", MessageBoxButtons.OK, MessageBoxIcon.Information)

        Catch ex As Exception
            MessageBox.Show("Excel Export Error: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            ReleaseObject(xlWorkSheet)
            ReleaseObject(xlWorkBook)
            ReleaseObject(xlApp)
        End Try
    End Sub

    Private Sub ReleaseObject(ByVal obj As Object)
        Try
            If obj IsNot Nothing Then
                System.Runtime.InteropServices.Marshal.ReleaseComObject(obj)
                obj = Nothing
            End If
        Catch ex As Exception
            obj = Nothing
        Finally
            GC.Collect()
            GC.WaitForPendingFinalizers()
        End Try
    End Sub

    Private Sub dtpReportMonth_ValueChanged(sender As Object, e As EventArgs) Handles dtpReportMonth.ValueChanged
        RefreshReportData()
    End Sub

    Private Sub btnRefresh_Click(sender As Object, e As EventArgs) Handles btnRefresh.Click
        RefreshReportData()
    End Sub

End Class