﻿Imports System.Data.OleDb
Imports System.IO
Imports iTextSharp.text
Imports iTextSharp.text.pdf
Imports Excel = Microsoft.Office.Interop.Excel

Public Class frmReports

    Private isLoaded As Boolean = False

    Private Sub frmReports_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        dtpReportMonth.Format = DateTimePickerFormat.Custom
        dtpReportMonth.CustomFormat = "MMMM yyyy"

        cmbFilter.Items.Clear()
        cmbFilter.Items.AddRange(New String() {"All Records", "Paid Only", "Unpaid & Partial Only", "Contract Expiring Soon"})

        isLoaded = True
        cmbFilter.SelectedIndex = 0
    End Sub

    Private Sub RefreshReportData(Optional ByVal searchTerm As String = "")
        If Not isLoaded Then Exit Sub
        LoadMonthlyReport(searchTerm)
        LoadOccupancyStats()
        LoadMissingBillings()
    End Sub

    Private Sub btnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click
        RefreshReportData(txtSearch.Text.Trim())
    End Sub

    Private Sub btnRefresh_Click(sender As Object, e As EventArgs) Handles btnRefresh.Click
        txtSearch.Clear()
        cmbFilter.SelectedIndex = 0
        RefreshReportData()
    End Sub

    Private Sub dtpReportMonth_ValueChanged(sender As Object, e As EventArgs) Handles dtpReportMonth.ValueChanged
        RefreshReportData(txtSearch.Text.Trim())
    End Sub

    Private Sub cmbFilter_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbFilter.SelectedIndexChanged
        RefreshReportData(txtSearch.Text.Trim())
    End Sub

    Private Sub LoadMonthlyReport(ByVal searchTerm As String)
        Using myConn As New OleDbConnection(ConnectionString)
            Try
                myConn.Open()

                Dim selDate As DateTime = dtpReportMonth.Value
                Dim firstDay As New DateTime(selDate.Year, selDate.Month, 1)
                Dim lastDay As New DateTime(selDate.Year, selDate.Month, DateTime.DaysInMonth(selDate.Year, selDate.Month))

                Dim sql As String = "SELECT t.[FullName], r.[RoomNumber], MAX(b.[BillingMonth]) AS BillingMonth, " &
                                    "SUM(b.[TotalAmount]) AS BilledAmount, SUM(b.[Balance]) AS UnpaidBalance, t.[EndDate] " &
                                    "FROM (tblBillings AS b INNER JOIN tblTenants AS t ON b.TenantID = t.TenantID) " &
                                    "INNER JOIN tblRooms AS r ON t.RoomID = r.RoomID " &
                                    "WHERE b.[BillingMonth] <= @end "

                Select Case cmbFilter.Text
                    Case "Paid Only"
                        sql &= " AND b.[IsPaid] = 'Yes' "
                    Case "Unpaid & Partial Only"
                        sql &= " AND b.[IsPaid] IN ('No', 'Partial') "
                    Case "Contract Expiring Soon"
                        sql &= " AND t.[EndDate] <= @expDate "
                End Select

                If searchTerm <> "" Then
                    sql &= " AND t.[FullName] LIKE '%" & searchTerm & "%' "
                End If

                sql &= " GROUP BY t.[FullName], r.[RoomNumber], t.[EndDate]"

                Dim cmd As New OleDbCommand(sql, myConn)
                cmd.Parameters.AddWithValue("@end", lastDay)
                If cmbFilter.Text = "Contract Expiring Soon" Then
                    cmd.Parameters.AddWithValue("@expDate", DateTime.Today.AddDays(30))
                End If

                Dim adapter As New OleDbDataAdapter(cmd)
                Dim dt As New DataTable
                adapter.Fill(dt)

                dt.Columns.Add("Payment Status", GetType(String))
                For Each row As DataRow In dt.Rows
                    Dim bal As Decimal = 0
                    If Not IsDBNull(row("UnpaidBalance")) AndAlso row("UnpaidBalance") IsNot Nothing Then
                        bal = Convert.ToDecimal(row("UnpaidBalance"))
                    End If

                    If bal <= 0 Then
                        row("Payment Status") = "Paid"
                    Else
                        row("Payment Status") = "Pending Bal: ₱" & bal.ToString("N2")
                    End If
                Next

                dgvReports.DataSource = dt

                Dim totalCollected As Decimal = 0
                Dim totalToCollect As Decimal = 0
                Dim unpaidCount As Integer = 0

                For Each row As DataGridViewRow In dgvReports.Rows
                    If row.Cells("EndDate").Value IsNot DBNull.Value AndAlso row.Cells("EndDate").Value IsNot Nothing Then
                        If CDate(row.Cells("EndDate").Value) < DateTime.Today Then
                            row.DefaultCellStyle.BackColor = System.Drawing.Color.MistyRose
                        End If
                    End If

                    Dim dr As DataRowView = DirectCast(row.DataBoundItem, DataRowView)

                    Dim billed As Decimal = 0
                    If Not IsDBNull(dr("BilledAmount")) AndAlso dr("BilledAmount") IsNot Nothing Then
                        billed = Convert.ToDecimal(dr("BilledAmount"))
                    End If

                    Dim bal As Decimal = 0
                    If Not IsDBNull(dr("UnpaidBalance")) AndAlso dr("UnpaidBalance") IsNot Nothing Then
                        bal = Convert.ToDecimal(dr("UnpaidBalance"))
                    End If

                    totalCollected += (billed - bal)
                    totalToCollect += bal

                    If bal > 0 Then unpaidCount += 1
                Next

                lblTotalCollection.Text = "₱" & totalCollected.ToString("N2")
                If totalToCollect > 0 Then
                    lblToCollect.Text = "-₱" & totalToCollect.ToString("N2")
                Else
                    lblToCollect.Text = "₱0.00"
                End If
                lblUnpaidCount.Text = unpaidCount.ToString()
                lblUnpaidCount.ForeColor = If(unpaidCount > 0, System.Drawing.Color.Crimson, System.Drawing.Color.SeaGreen)

                If dgvReports.Columns.Count > 0 Then
                    dgvReports.Columns("BilledAmount").HeaderText = "Total Bill"
                    dgvReports.Columns("UnpaidBalance").HeaderText = "Unpaid Balance"
                    dgvReports.Columns("BillingMonth").DefaultCellStyle.Format = "MM/dd/yyyy"
                    dgvReports.Columns("EndDate").DefaultCellStyle.Format = "MM/dd/yyyy"
                End If

            Catch ex As Exception
                MsgBox("Error in LoadMonthlyReport: " & ex.Message, MsgBoxStyle.Critical)
            End Try
        End Using
    End Sub

    Private Sub LoadOccupancyStats()
        Using myConn As New OleDbConnection(ConnectionString)
            Try
                myConn.Open()
                Dim cmdOcc As New OleDbCommand("SELECT COUNT(*) FROM tblRooms WHERE [Status] LIKE 'Occupied%'", myConn)
                Dim cmdTotal As New OleDbCommand("SELECT COUNT(*) FROM tblRooms", myConn)
                Dim occupied As Integer = CInt(cmdOcc.ExecuteScalar())
                Dim totalRooms As Integer = CInt(cmdTotal.ExecuteScalar())
                Dim percentage As Integer = If(totalRooms > 0, Math.Round((occupied / totalRooms) * 100), 0)
                lblOccupancyRate.Text = String.Format("{0}%", percentage)
            Catch ex As Exception
                MsgBox("Error in LoadOccupancyStats: " & ex.Message, MsgBoxStyle.Critical)
            End Try
        End Using
    End Sub

    Private Sub LoadMissingBillings()
        Using myConn As New OleDbConnection(ConnectionString)
            Try
                myConn.Open()
                Dim selDate As DateTime = dtpReportMonth.Value
                Dim firstDay As New DateTime(selDate.Year, selDate.Month, 1)
                Dim lastDay As New DateTime(selDate.Year, selDate.Month, DateTime.DaysInMonth(selDate.Year, selDate.Month))

                Dim sql As String = "SELECT t.TenantID, t.FullName, t.BaseRent FROM tblTenants t " &
                                    "WHERE t.Status = 'Active' AND t.TenantID NOT IN " &
                                    "(SELECT TenantID FROM tblBillings WHERE BillingMonth BETWEEN @start AND @end)"

                Dim cmd As New OleDbCommand(sql, myConn)
                cmd.Parameters.AddWithValue("@start", firstDay)
                cmd.Parameters.AddWithValue("@end", lastDay)

                Dim adapter As New OleDbDataAdapter(cmd)
                Dim dtMissing As New DataTable
                adapter.Fill(dtMissing)
                dgvMissingBillings.DataSource = dtMissing

            Catch ex As Exception
                MsgBox("Error in LoadMissingBillings: " & ex.Message, MsgBoxStyle.Critical)
            End Try
        End Using
    End Sub

    Private Sub btnAutoBill_Click(sender As Object, e As EventArgs) Handles btnAutoBill.Click
        If dgvMissingBillings.Rows.Count = 0 Then
            MsgBox("All active tenants are already billed for this month.", MsgBoxStyle.Information)
            Exit Sub
        End If

        Dim ans = MsgBox($"Generate auto-billing for {dgvMissingBillings.Rows.Count} tenants using their Base Rent?", MsgBoxStyle.YesNo + MsgBoxStyle.Question)
        If ans = MsgBoxResult.Yes Then
            Using myConn As New OleDbConnection(ConnectionString)
                Try
                    myConn.Open()
                    Dim trans = myConn.BeginTransaction()
                    Dim bMonth As DateTime = dtpReportMonth.Value
                    Dim firstDayOfMonth As New DateTime(bMonth.Year, bMonth.Month, 1)

                    For Each row As DataGridViewRow In dgvMissingBillings.Rows
                        Dim tid = row.Cells("TenantID").Value
                        Dim rent = row.Cells("BaseRent").Value

                        Dim sqlInsert = "INSERT INTO tblBillings (TenantID, BillingMonth, TotalAmount, Balance, IsPaid, MeralcoReading) " &
                                        "VALUES (@tid, @bmon, @amt, @bal, 'No', 0)"
                        Dim cmd = New OleDbCommand(sqlInsert, myConn, trans)
                        cmd.Parameters.AddWithValue("@tid", tid)
                        cmd.Parameters.AddWithValue("@bmon", firstDayOfMonth.ToShortDateString())
                        cmd.Parameters.AddWithValue("@amt", rent)
                        cmd.Parameters.AddWithValue("@bal", rent)
                        cmd.ExecuteNonQuery()
                    Next

                    trans.Commit()
                    MsgBox("Batch billing successful!", MsgBoxStyle.Information)
                    RefreshReportData()
                Catch ex As Exception
                    MsgBox("Error in Batch Auto-Bill: " & ex.Message, MsgBoxStyle.Critical)
                End Try
            End Using
        End If
    End Sub

    Private Sub dgvReports_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgvReports.CellClick
        If e.RowIndex >= 0 Then
            Dim tenantName As String = dgvReports.Rows(e.RowIndex).Cells("FullName").Value.ToString()

            Using conn As New OleDbConnection(ConnectionString)
                Try
                    conn.Open()
                    Dim sql As String = "SELECT t.TenantID, t.ContactNo, t.BaseRent, t.StartDate, t.EndDate, r.MeterNumber, r.RoomNumber " &
                                        "FROM tblTenants t INNER JOIN tblRooms r ON t.RoomID = r.RoomID WHERE t.FullName = @name"
                    Dim cmd As New OleDbCommand(sql, conn)
                    cmd.Parameters.AddWithValue("@name", tenantName)
                    Dim reader = cmd.ExecuteReader()

                    If reader.Read() Then
                        Dim popup As New Form()
                        popup.Text = "Tenant Details"
                        popup.Size = New System.Drawing.Size(420, 480)
                        popup.StartPosition = FormStartPosition.CenterParent
                        popup.FormBorderStyle = FormBorderStyle.FixedDialog
                        popup.MaximizeBox = False
                        popup.MinimizeBox = False
                        popup.BackColor = System.Drawing.Color.White

                        Dim pnlHeader As New Panel With {.Dock = DockStyle.Top, .Height = 60, .BackColor = System.Drawing.Color.FromArgb(31, 41, 55)}
                        Dim lblTitle As New Label With {.Text = "👤 Tenant Information", .ForeColor = System.Drawing.Color.White, .Font = New System.Drawing.Font("Segoe UI", 14, FontStyle.Bold), .AutoSize = True, .Location = New System.Drawing.Point(20, 15)}
                        pnlHeader.Controls.Add(lblTitle)
                        popup.Controls.Add(pnlHeader)

                        Dim pnlFooter As New Panel With {.Dock = DockStyle.Bottom, .Height = 60, .BackColor = System.Drawing.Color.FromArgb(243, 244, 246)}
                        Dim btnClose As New Button With {.Text = "CLOSE", .Size = New System.Drawing.Size(100, 35), .BackColor = System.Drawing.Color.FromArgb(31, 97, 141), .ForeColor = System.Drawing.Color.White, .FlatStyle = FlatStyle.Flat, .Font = New System.Drawing.Font("Segoe UI", 9, FontStyle.Bold), .Cursor = Cursors.Hand}
                        btnClose.FlatAppearance.BorderSize = 0
                        btnClose.Location = New System.Drawing.Point(popup.ClientSize.Width - btnClose.Width - 20, 12)
                        AddHandler btnClose.Click, Sub(s, ev) popup.Close()
                        pnlFooter.Controls.Add(btnClose)
                        popup.Controls.Add(pnlFooter)

                        Dim tlp As New TableLayoutPanel With {.Dock = DockStyle.Fill, .Padding = New Padding(20, 20, 20, 20), .ColumnCount = 2, .RowCount = 7}
                        tlp.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 35.0F))
                        tlp.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 65.0F))

                        Dim fontLabel As New System.Drawing.Font("Segoe UI", 10, FontStyle.Bold)
                        Dim fontValue As New System.Drawing.Font("Segoe UI", 10, FontStyle.Regular)
                        Dim colorLabel As System.Drawing.Color = System.Drawing.Color.FromArgb(100, 116, 139)

                        Dim addRow = Sub(iconText As String, valText As String, rIdx As Integer)
                                         Dim l1 As New Label With {.Text = iconText, .Font = fontLabel, .ForeColor = colorLabel, .AutoSize = True, .Dock = DockStyle.Fill, .TextAlign = ContentAlignment.MiddleLeft}
                                         Dim l2 As New Label With {.Text = valText, .Font = fontValue, .ForeColor = System.Drawing.Color.Black, .AutoSize = True, .Dock = DockStyle.Fill, .TextAlign = ContentAlignment.MiddleLeft}
                                         tlp.Controls.Add(l1, 0, rIdx)
                                         tlp.Controls.Add(l2, 1, rIdx)
                                     End Sub

                        addRow("👤 Name:", tenantName, 0)
                        addRow("🚪 Room:", reader("RoomNumber").ToString(), 1)
                        addRow("📞 Contact:", reader("ContactNo").ToString(), 2)
                        addRow("⚡ Meter No:", reader("MeterNumber").ToString(), 3)
                        addRow("💰 Base Rent:", "₱ " & CDec(reader("BaseRent")).ToString("N2"), 4)
                        addRow("📅 Start Date:", CDate(reader("StartDate")).ToString("MMMM dd, yyyy"), 5)
                        addRow("⏳ End Date:", CDate(reader("EndDate")).ToString("MMMM dd, yyyy"), 6)

                        popup.Controls.Add(tlp)
                        tlp.BringToFront()

                        popup.ShowDialog()
                    End If
                Catch ex As Exception
                    MsgBox("Error getting details: " & ex.Message, MsgBoxStyle.Exclamation)
                End Try
            End Using
        End If
    End Sub

    Private Sub btnPrint_Click(sender As Object, e As EventArgs) Handles btnPrint.Click
        If dgvReports.Rows.Count = 0 Then
            MsgBox("Walang data na pwedeng i-print.", MsgBoxStyle.Exclamation)
            Exit Sub
        End If

        Dim sfd As New SaveFileDialog()
        sfd.Filter = "PDF Files (*.pdf)|*.pdf"
        sfd.FileName = "Report_" & dtpReportMonth.Value.ToString("MMMM_yyyy") & ".pdf"

        If sfd.ShowDialog() = DialogResult.OK Then
            Try
                Dim pdfTable As New PdfPTable(dgvReports.ColumnCount)
                pdfTable.DefaultCell.Padding = 3
                pdfTable.WidthPercentage = 100
                pdfTable.HorizontalAlignment = Element.ALIGN_LEFT

                For Each column As DataGridViewColumn In dgvReports.Columns
                    Dim cell As New PdfPCell(New Phrase(column.HeaderText))
                    cell.BackgroundColor = New BaseColor(240, 240, 240)
                    pdfTable.AddCell(cell)
                Next

                For Each row As DataGridViewRow In dgvReports.Rows
                    For Each cell As DataGridViewCell In row.Cells
                        pdfTable.AddCell(If(cell.Value IsNot Nothing, cell.Value.ToString(), ""))
                    Next
                Next

                Using stream As New FileStream(sfd.FileName, FileMode.Create)
                    Dim pdfDoc As New Document(PageSize.A4, 10.0F, 10.0F, 10.0F, 0.0F)
                    PdfWriter.GetInstance(pdfDoc, stream)
                    pdfDoc.Open()
                    pdfDoc.Add(New Phrase("CRISTINA'S PLACE - MONTHLY PERFORMANCE REPORT"))
                    pdfDoc.Add(New Phrase(Environment.NewLine))
                    pdfDoc.Add(New Phrase("Month: " & dtpReportMonth.Text))
                    pdfDoc.Add(New Phrase(Environment.NewLine & Environment.NewLine))
                    pdfDoc.Add(pdfTable)
                    pdfDoc.Add(New Phrase(Environment.NewLine & "Total Collected: " & lblTotalCollection.Text))
                    pdfDoc.Add(New Phrase("Total To Collect: " & lblToCollect.Text))
                    pdfDoc.Close()
                    stream.Close()
                End Using

                MsgBox("PDF Report successfully generated!", MsgBoxStyle.Information)
            Catch ex As Exception
                MsgBox("Error: " & ex.Message)
            End Try
        End If
    End Sub

    Private Sub btnExport_Click(sender As Object, e As EventArgs) Handles btnExport.Click
        If dgvReports.Rows.Count = 0 Then
            MessageBox.Show("Walang data na pwedeng i-export. Mag-generate muna ng report.", "Empty Report", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return
        End If

        Dim strFolder As String = "C:\Client"
        Dim strFilename As String = strFolder & "\MonthlyReport_" & dtpReportMonth.Value.ToString("MMMM_yyyy") & ".xlsx"

        Dim xlApp As Object = Nothing
        Dim xlWorkBook As Object = Nothing
        Dim xlWorkSheet As Object = Nothing

        Try
            If Not Directory.Exists(strFolder) Then
                Directory.CreateDirectory(strFolder)
            End If

            xlApp = CreateObject("Excel.Application")

            If Not File.Exists(strFilename) Then
                xlWorkBook = xlApp.Workbooks.Add
                xlWorkSheet = xlWorkBook.ActiveSheet
                xlWorkBook.SaveAs(strFilename)
            Else
                xlWorkBook = xlApp.Workbooks.Open(strFilename)
                xlWorkSheet = xlWorkBook.Worksheets(1)
            End If

            xlWorkSheet.Cells.ClearContents()

            For i As Integer = 0 To dgvReports.Columns.Count - 1
                xlWorkSheet.Cells(1, i + 1).Value = dgvReports.Columns(i).HeaderText
            Next

            For i As Integer = 0 To dgvReports.Rows.Count - 1
                For j As Integer = 0 To dgvReports.Columns.Count - 1
                    If dgvReports.Rows(i).Cells(j).Value IsNot Nothing Then
                        xlWorkSheet.Cells(i + 2, j + 1).Value = dgvReports.Rows(i).Cells(j).Value.ToString()
                    End If
                Next
            Next

            xlWorkSheet.Rows(1).Font.Bold = True
            xlWorkSheet.Columns.AutoFit()

            xlWorkBook.Save()
            xlApp.Visible = True
            MessageBox.Show("Report Successfully Exported to: " & strFilename, "Export Success", MessageBoxButtons.OK, MessageBoxIcon.Information)

        Catch ex As Exception
            MessageBox.Show("Excel Export Error: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            ReleaseObject(xlWorkSheet)
            ReleaseObject(xlWorkBook)
            ReleaseObject(xlApp)
        End Try
    End Sub

    Private Sub ReleaseObject(ByVal obj As Object)
        Try
            If obj IsNot Nothing Then
                System.Runtime.InteropServices.Marshal.ReleaseComObject(obj)
                obj = Nothing
            End If
        Catch ex As Exception
            obj = Nothing
        Finally
            GC.Collect()
            GC.WaitForPendingFinalizers()
        End Try
    End Sub

End Class