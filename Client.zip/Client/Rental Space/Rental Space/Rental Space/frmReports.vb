﻿Imports System.Data.OleDb
Imports System.IO
Imports iTextSharp.text
Imports iTextSharp.text.pdf

Public Class frmReports

    Private isLoaded As Boolean = False

    Private Sub frmReports_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        dtpReportMonth.Format = DateTimePickerFormat.Custom
        dtpReportMonth.CustomFormat = "MMMM yyyy"

        cmbViewType.Items.Clear()
        cmbViewType.Items.AddRange(New String() {"Monthly View", "All-Time View"})

        cmbFilter.Items.Clear()
        cmbFilter.Items.AddRange(New String() {"All Records", "Paid Only", "Unpaid & Partial Only", "Contract Expiring Soon"})

        isLoaded = True
        cmbViewType.SelectedIndex = 0
        cmbFilter.SelectedIndex = 0

        ApplyRoleSecurity()
    End Sub

    Private Sub ApplyRoleSecurity()
        Dim role As String = currentUserRole.ToUpper().Trim()
        If role.Contains("GUARD") Or role.Contains("SECURITY") Then
            btnPrint.Enabled = False
            btnPrint.Visible = False
        End If
    End Sub

    Private Sub RefreshReportData(Optional ByVal searchTerm As String = "")
        If Not isLoaded Then Exit Sub
        LoadMonthlyReport(searchTerm)
        LoadOccupancyStats()
    End Sub

    Private Sub btnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click
        RefreshReportData(txtSearch.Text.Trim())
    End Sub

    Private Sub btnRefresh_Click(sender As Object, e As EventArgs) Handles btnRefresh.Click
        txtSearch.Clear()
        cmbViewType.SelectedIndex = 0
        cmbFilter.SelectedIndex = 0
        dtpReportMonth.Value = DateTime.Today
        RefreshReportData()
    End Sub

    Private Sub dtpReportMonth_ValueChanged(sender As Object, e As EventArgs) Handles dtpReportMonth.ValueChanged
        RefreshReportData(txtSearch.Text.Trim())
    End Sub

    Private Sub cmbViewType_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbViewType.SelectedIndexChanged
        If cmbViewType.Text = "All-Time View" Then
            dtpReportMonth.Enabled = False
        Else
            dtpReportMonth.Enabled = True
        End If
        RefreshReportData(txtSearch.Text.Trim())
    End Sub

    Private Sub cmbFilter_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbFilter.SelectedIndexChanged
        RefreshReportData(txtSearch.Text.Trim())
    End Sub

    Private Sub LoadMonthlyReport(ByVal searchTerm As String)
        Using myConn As New OleDbConnection(ConnectionString)
            Try
                myConn.Open()

                Dim selDate As DateTime = dtpReportMonth.Value
                Dim firstDay As New DateTime(selDate.Year, selDate.Month, 1)
                Dim lastDay As New DateTime(selDate.Year, selDate.Month, DateTime.DaysInMonth(selDate.Year, selDate.Month))

                Dim sql As String = "SELECT t.[FullName], r.[RoomNumber], MAX(b.[BillingMonth]) AS LatestBilling, " &
                                    "SUM(b.[TotalAmount]) AS BilledAmount, (SUM(b.[TotalAmount]) - SUM(b.[Balance])) AS AmountPaid, SUM(b.[Balance]) AS UnpaidBalance, t.[EndDate] " &
                                    "FROM (tblBillings AS b INNER JOIN tblTenants AS t ON b.TenantID = t.TenantID) " &
                                    "INNER JOIN tblRooms AS r ON t.RoomID = r.RoomID " &
                                    "WHERE 1=1 "

                If cmbViewType.Text = "Monthly View" Then
                    sql &= " AND b.[BillingMonth] BETWEEN @start AND @end "
                End If

                Select Case cmbFilter.Text
                    Case "Paid Only"
                        sql &= " AND b.[IsPaid] = 'Yes' "
                    Case "Unpaid & Partial Only"
                        sql &= " AND b.[IsPaid] IN ('No', 'Partial') "
                    Case "Contract Expiring Soon"
                        sql &= " AND t.[EndDate] <= @expDate AND t.[Status] = 'Active' "
                End Select

                If searchTerm <> "" Then
                    sql &= " AND t.[FullName] LIKE '%" & searchTerm & "%' "
                End If

                sql &= " GROUP BY t.[FullName], r.[RoomNumber], t.[EndDate]"

                Dim cmd As New OleDbCommand(sql, myConn)

                If cmbViewType.Text = "Monthly View" Then
                    cmd.Parameters.AddWithValue("@start", firstDay)
                    cmd.Parameters.AddWithValue("@end", lastDay)
                End If

                If cmbFilter.Text = "Contract Expiring Soon" Then
                    cmd.Parameters.AddWithValue("@expDate", DateTime.Today.AddDays(30))
                End If

                Dim adapter As New OleDbDataAdapter(cmd)
                Dim dt As New DataTable
                adapter.Fill(dt)

                dt.Columns.Add("Remarks", GetType(String))
                dt.Columns.Add("Payment Status", GetType(String))

                For Each row As DataRow In dt.Rows
                    Dim bal As Decimal = 0
                    If Not IsDBNull(row("UnpaidBalance")) AndAlso row("UnpaidBalance") IsNot Nothing Then
                        bal = Convert.ToDecimal(row("UnpaidBalance"))
                    End If

                    Dim amtPaid As Decimal = 0
                    If Not IsDBNull(row("AmountPaid")) Then
                        amtPaid = Convert.ToDecimal(row("AmountPaid"))
                        If amtPaid < 0 Then
                            amtPaid = 0
                            row("AmountPaid") = 0
                        End If
                    End If

                    If bal <= 0 Then
                        row("Payment Status") = "Paid"
                    Else
                        row("Payment Status") = "Pending Bal: ₱" & bal.ToString("N2")
                    End If

                    ' Get latest remarks for the tenant
                    Dim cmdRem As New OleDbCommand("SELECT TOP 1 b.Remarks FROM tblBillings b INNER JOIN tblTenants t ON b.TenantID = t.TenantID WHERE t.FullName = @fname AND b.Remarks IS NOT NULL ORDER BY b.BillingMonth DESC", myConn)
                    cmdRem.Parameters.AddWithValue("@fname", row("FullName").ToString())
                    Dim remObj = cmdRem.ExecuteScalar()
                    row("Remarks") = If(remObj IsNot Nothing AndAlso Not IsDBNull(remObj), remObj.ToString(), "None")
                Next

                dgvReports.DataSource = dt

                Dim totalCollected As Decimal = 0
                Dim totalToCollect As Decimal = 0
                Dim unpaidCount As Integer = 0

                For Each row As DataGridViewRow In dgvReports.Rows
                    If row.Cells("EndDate").Value IsNot DBNull.Value AndAlso row.Cells("EndDate").Value IsNot Nothing Then
                        If CDate(row.Cells("EndDate").Value) < DateTime.Today Then
                            row.DefaultCellStyle.BackColor = System.Drawing.Color.MistyRose
                        End If
                    End If

                    Dim dr As DataRowView = DirectCast(row.DataBoundItem, DataRowView)

                    Dim paidThisBill As Decimal = 0
                    If Not IsDBNull(dr("AmountPaid")) AndAlso dr("AmountPaid") IsNot Nothing Then
                        paidThisBill = Convert.ToDecimal(dr("AmountPaid"))
                    End If

                    Dim bal As Decimal = 0
                    If Not IsDBNull(dr("UnpaidBalance")) AndAlso dr("UnpaidBalance") IsNot Nothing Then
                        bal = Convert.ToDecimal(dr("UnpaidBalance"))
                    End If

                    totalCollected += paidThisBill
                    totalToCollect += bal

                    If bal > 0 Then unpaidCount += 1
                Next

                lblTotalCollection.Text = "₱" & totalCollected.ToString("N2")
                lblToCollect.Text = "₱" & totalToCollect.ToString("N2")

                lblUnpaidCount.Text = unpaidCount.ToString()
                lblUnpaidCount.ForeColor = If(unpaidCount > 0, System.Drawing.Color.Crimson, System.Drawing.Color.SeaGreen)

                If dgvReports.Columns.Count > 0 Then
                    dgvReports.Columns("BilledAmount").HeaderText = "Total Bill"
                    dgvReports.Columns("AmountPaid").HeaderText = "Amount Paid"
                    dgvReports.Columns("UnpaidBalance").HeaderText = "Remaining Balance"
                    dgvReports.Columns("Remarks").HeaderText = "Remarks"
                    dgvReports.Columns("LatestBilling").HeaderText = If(cmbViewType.Text = "Monthly View", "Billing Month", "Latest Billing")
                    dgvReports.Columns("LatestBilling").DefaultCellStyle.Format = "MM/dd/yyyy"
                    dgvReports.Columns("EndDate").DefaultCellStyle.Format = "MM/dd/yyyy"

                    dgvReports.Columns("BilledAmount").DisplayIndex = 3
                    dgvReports.Columns("AmountPaid").DisplayIndex = 4
                    dgvReports.Columns("UnpaidBalance").DisplayIndex = 5
                    dgvReports.Columns("Remarks").DisplayIndex = 6
                End If

            Catch ex As Exception
                MsgBox("Error in LoadMonthlyReport: " & ex.Message, MsgBoxStyle.Critical)
            End Try
        End Using
    End Sub

    Private Sub LoadOccupancyStats()
        Using myConn As New OleDbConnection(ConnectionString)
            Try
                myConn.Open()
                Dim cmdOcc As New OleDbCommand("SELECT COUNT(*) FROM tblRooms WHERE [Status] LIKE 'Occupied%'", myConn)
                Dim cmdTotal As New OleDbCommand("SELECT COUNT(*) FROM tblRooms", myConn)
                Dim occupied As Integer = CInt(cmdOcc.ExecuteScalar())
                Dim totalRooms As Integer = CInt(cmdTotal.ExecuteScalar())
                Dim percentage As Integer = If(totalRooms > 0, CInt(Math.Round((occupied / totalRooms) * 100)), 0)
                lblOccupancyRate.Text = String.Format("{0}%", percentage)
            Catch ex As Exception
                MsgBox("Error in LoadOccupancyStats: " & ex.Message, MsgBoxStyle.Critical)
            End Try
        End Using
    End Sub

    Private Sub dgvReports_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgvReports.CellClick
        If e.RowIndex >= 0 Then
            Dim tenantName As String = dgvReports.Rows(e.RowIndex).Cells("FullName").Value.ToString()

            Using conn As New OleDbConnection(ConnectionString)
                Try
                    conn.Open()
                    Dim sql As String = "SELECT t.TenantID, t.ContactNo, t.BaseRent, t.StartDate, t.EndDate, r.MeterNumber, r.RoomNumber " &
                                        "FROM tblTenants t INNER JOIN tblRooms r ON t.RoomID = r.RoomID WHERE t.FullName = @name"
                    Dim cmd As New OleDbCommand(sql, conn)
                    cmd.Parameters.AddWithValue("@name", tenantName)
                    Dim reader = cmd.ExecuteReader()

                    If reader.Read() Then
                        Dim tenantID As Integer = Convert.ToInt32(reader("TenantID"))

                        Dim amountDue As Decimal = 0
                        Dim dueDateStr As String = "N/A"
                        Dim paymentStatus As String = "Paid"
                        Dim overdueStatus As String = "🟢 CLEAR"
                        Dim billRemarks As String = "None"

                        Dim cmdSum As New OleDbCommand("SELECT SUM([Balance]) FROM tblBillings WHERE TenantID = @tid AND ([IsPaid] = 'No' OR [IsPaid] = 'Partial')", conn)
                        cmdSum.Parameters.AddWithValue("@tid", tenantID)
                        Dim objSum = cmdSum.ExecuteScalar()
                        If objSum IsNot Nothing AndAlso Not IsDBNull(objSum) Then
                            amountDue = Convert.ToDecimal(objSum)
                        End If

                        ' Get latest Remarks independently to ensure we capture the newest note
                        Dim cmdRem As New OleDbCommand("SELECT TOP 1 [Remarks] FROM tblBillings WHERE TenantID = @tid AND [Remarks] IS NOT NULL ORDER BY [BillingMonth] DESC", conn)
                        cmdRem.Parameters.AddWithValue("@tid", tenantID)
                        Dim remObj = cmdRem.ExecuteScalar()
                        If remObj IsNot Nothing AndAlso Not IsDBNull(remObj) Then
                            billRemarks = remObj.ToString()
                        End If

                        If amountDue > 0 Then
                            Dim cmdDate As New OleDbCommand("SELECT TOP 1 [BillingMonth], [IsPaid] FROM tblBillings WHERE TenantID = @tid AND ([IsPaid] = 'No' OR [IsPaid] = 'Partial') ORDER BY [BillingMonth] ASC", conn)
                            cmdDate.Parameters.AddWithValue("@tid", tenantID)
                            Dim readerDate = cmdDate.ExecuteReader()

                            If readerDate.Read() Then
                                paymentStatus = If(readerDate("IsPaid").ToString() = "No", "Unpaid", "Partial Payment")

                                If Not IsDBNull(readerDate("BillingMonth")) Then
                                    Dim rawDate As Object = readerDate("BillingMonth")
                                    Dim parsedDate As DateTime

                                    If TypeOf rawDate Is DateTime Then
                                        parsedDate = DirectCast(rawDate, DateTime)
                                    Else
                                        DateTime.TryParse(rawDate.ToString(), parsedDate)
                                    End If

                                    Dim lastDay As New DateTime(parsedDate.Year, parsedDate.Month, DateTime.DaysInMonth(parsedDate.Year, parsedDate.Month))
                                    dueDateStr = lastDay.ToString("MMMM dd, yyyy")

                                    If DateTime.Today > lastDay Then
                                        overdueStatus = "🔴 OVERDUE"
                                    Else
                                        overdueStatus = "🟡 ON TIME (Pending)"
                                    End If
                                End If
                            End If
                            readerDate.Close()
                        End If

                        Dim popup As New Form()
                        popup.Text = "Tenant Details"
                        popup.Size = New System.Drawing.Size(440, 600)
                        popup.StartPosition = FormStartPosition.CenterParent
                        popup.FormBorderStyle = FormBorderStyle.FixedDialog
                        popup.MaximizeBox = False
                        popup.MinimizeBox = False
                        popup.BackColor = System.Drawing.Color.White

                        Dim pnlHeader As New Panel With {.Dock = DockStyle.Top, .Height = 60, .BackColor = System.Drawing.Color.FromArgb(31, 41, 55)}
                        Dim lblTitle As New Label With {.Text = "👤 Tenant Information", .ForeColor = System.Drawing.Color.White, .Font = New System.Drawing.Font("Segoe UI", 14, FontStyle.Bold), .AutoSize = True, .Location = New System.Drawing.Point(20, 15)}
                        pnlHeader.Controls.Add(lblTitle)
                        popup.Controls.Add(pnlHeader)

                        Dim pnlFooter As New Panel With {.Dock = DockStyle.Bottom, .Height = 60, .BackColor = System.Drawing.Color.FromArgb(243, 244, 246)}
                        Dim btnClose As New Button With {.Text = "CLOSE", .Size = New System.Drawing.Size(100, 35), .BackColor = System.Drawing.Color.FromArgb(31, 97, 141), .ForeColor = System.Drawing.Color.White, .FlatStyle = FlatStyle.Flat, .Font = New System.Drawing.Font("Segoe UI", 9, FontStyle.Bold), .Cursor = Cursors.Hand}
                        btnClose.FlatAppearance.BorderSize = 0
                        btnClose.Location = New System.Drawing.Point(popup.ClientSize.Width - btnClose.Width - 20, 12)
                        AddHandler btnClose.Click, Sub(s, ev) popup.Close()
                        pnlFooter.Controls.Add(btnClose)
                        popup.Controls.Add(pnlFooter)

                        Dim tlp As New TableLayoutPanel With {.Dock = DockStyle.Fill, .Padding = New Padding(20, 20, 20, 20), .ColumnCount = 2, .RowCount = 12}
                        tlp.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 35.0F))
                        tlp.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 65.0F))

                        Dim fontLabel As New System.Drawing.Font("Segoe UI", 10, FontStyle.Bold)
                        Dim fontValue As New System.Drawing.Font("Segoe UI", 10, FontStyle.Regular)
                        Dim colorLabel As System.Drawing.Color = System.Drawing.Color.FromArgb(100, 116, 139)

                        Dim addRow = Sub(iconText As String, valText As String, rIdx As Integer)
                                         Dim l1 As New Label With {.Text = iconText, .Font = fontLabel, .ForeColor = colorLabel, .AutoSize = True, .Dock = DockStyle.Fill, .TextAlign = ContentAlignment.MiddleLeft}
                                         Dim l2 As New Label With {.Text = valText, .Font = fontValue, .ForeColor = System.Drawing.Color.Black, .AutoSize = True, .Dock = DockStyle.Fill, .TextAlign = ContentAlignment.MiddleLeft}
                                         tlp.Controls.Add(l1, 0, rIdx)
                                         tlp.Controls.Add(l2, 1, rIdx)
                                     End Sub

                        addRow("👤 Name:", tenantName, 0)
                        addRow("🚪 Room:", reader("RoomNumber").ToString(), 1)
                        addRow("📞 Contact:", reader("ContactNo").ToString(), 2)
                        addRow("⚡ Meter No:", reader("MeterNumber").ToString(), 3)
                        addRow("💰 Base Rent:", "₱ " & CDec(reader("BaseRent")).ToString("N2"), 4)
                        addRow("📅 Start Date:", CDate(reader("StartDate")).ToString("MMMM dd, yyyy"), 5)
                        addRow("⏳ End Date:", CDate(reader("EndDate")).ToString("MMMM dd, yyyy"), 6)
                        addRow("💵 Balance:", "₱ " & amountDue.ToString("N2"), 7)
                        addRow("📝 Remarks:", billRemarks, 8)
                        addRow("📊 Pay Status:", paymentStatus, 9)
                        addRow("📆 Due Date:", dueDateStr, 10)
                        addRow("⚠️ Condition:", overdueStatus, 11)

                        popup.Controls.Add(tlp)
                        tlp.BringToFront()

                        popup.ShowDialog()
                    End If
                Catch ex As Exception
                    MsgBox("Error getting details: " & ex.Message, MsgBoxStyle.Exclamation)
                End Try
            End Using
        End If
    End Sub

    Private Sub btnPrint_Click(sender As Object, e As EventArgs) Handles btnPrint.Click
        If dgvReports.Rows.Count = 0 Then
            MsgBox("Walang data na pwedeng i-print.", MsgBoxStyle.Exclamation)
            Exit Sub
        End If

        Dim sfd As New SaveFileDialog()
        sfd.Filter = "PDF Files (*.pdf)|*.pdf"
        sfd.FileName = "Report_" & If(cmbViewType.Text = "All-Time View", "Overall", dtpReportMonth.Value.ToString("MMM_yyyy")) & ".pdf"

        If sfd.ShowDialog() = DialogResult.OK Then
            Try
                Using stream As New FileStream(sfd.FileName, FileMode.Create)
                    Dim pdfDoc As New Document(PageSize.A4.Rotate(), 20.0F, 20.0F, 30.0F, 30.0F)
                    PdfWriter.GetInstance(pdfDoc, stream)
                    pdfDoc.Open()

                    Dim titleFont As Font = FontFactory.GetFont(FontFactory.HELVETICA_BOLD, 22, BaseColor.BLACK)
                    Dim subTitleFont As Font = FontFactory.GetFont(FontFactory.HELVETICA_BOLD, 14, BaseColor.DARK_GRAY)
                    Dim normalFont As Font = FontFactory.GetFont(FontFactory.HELVETICA, 10, BaseColor.BLACK)
                    Dim boldFont As Font = FontFactory.GetFont(FontFactory.HELVETICA_BOLD, 11, BaseColor.BLACK)
                    Dim whiteBoldFont As Font = FontFactory.GetFont(FontFactory.HELVETICA_BOLD, 11, BaseColor.WHITE)

                    Dim pTitle As New Paragraph("CRISTINA'S PLACE", titleFont)
                    pTitle.Alignment = Element.ALIGN_CENTER
                    pdfDoc.Add(pTitle)

                    Dim rTitle As String = If(cmbViewType.Text = "All-Time View", "OVERALL STATEMENT OF ACCOUNT", "MONTHLY PERFORMANCE REPORT")
                    Dim pSub As New Paragraph(rTitle, subTitleFont)
                    pSub.Alignment = Element.ALIGN_CENTER
                    pdfDoc.Add(pSub)

                    Dim dateRange As String = If(cmbViewType.Text = "All-Time View", "As of: " & DateTime.Now.ToString("MMMM dd, yyyy"), "For the month of: " & dtpReportMonth.Text)
                    Dim pDate As New Paragraph(dateRange, normalFont)
                    pDate.Alignment = Element.ALIGN_CENTER
                    pDate.SpacingAfter = 20.0F
                    pdfDoc.Add(pDate)

                    Dim pSummary As New Paragraph($"Total Collected: {lblTotalCollection.Text}   |   To Collect (Unpaid): {lblToCollect.Text}   |   Occupancy Rate: {lblOccupancyRate.Text}   |   Unpaid Bills: {lblUnpaidCount.Text}", boldFont)
                    pSummary.Alignment = Element.ALIGN_CENTER
                    pSummary.SpacingAfter = 20.0F
                    pdfDoc.Add(pSummary)

                    Dim pdfTable As New PdfPTable(dgvReports.ColumnCount)
                    pdfTable.WidthPercentage = 100

                    For Each column As DataGridViewColumn In dgvReports.Columns
                        Dim cell As New PdfPCell(New Phrase(column.HeaderText, whiteBoldFont))
                        cell.BackgroundColor = New BaseColor(31, 41, 55)
                        cell.HorizontalAlignment = Element.ALIGN_CENTER
                        cell.VerticalAlignment = Element.ALIGN_MIDDLE
                        cell.Padding = 8
                        pdfTable.AddCell(cell)
                    Next

                    Dim isAltRow As Boolean = False
                    For Each row As DataGridViewRow In dgvReports.Rows
                        For Each cell As DataGridViewCell In row.Cells
                            Dim cellText As String = If(cell.Value IsNot Nothing, cell.Value.ToString(), "")

                            If TypeOf cell.Value Is DateTime Then
                                cellText = DirectCast(cell.Value, DateTime).ToString("MMMM dd, yyyy")
                            End If

                            Dim pdfCell As New PdfPCell(New Phrase(cellText, normalFont))
                            pdfCell.Padding = 6
                            pdfCell.VerticalAlignment = Element.ALIGN_MIDDLE

                            If cell.OwningColumn.HeaderText.Contains("Amount") Or cell.OwningColumn.HeaderText.Contains("Balance") Or cell.OwningColumn.HeaderText.Contains("Total Bill") Then
                                pdfCell.HorizontalAlignment = Element.ALIGN_RIGHT
                            Else
                                pdfCell.HorizontalAlignment = Element.ALIGN_LEFT
                            End If

                            If isAltRow Then
                                pdfCell.BackgroundColor = New BaseColor(245, 245, 245)
                            End If

                            pdfTable.AddCell(pdfCell)
                        Next
                        isAltRow = Not isAltRow
                    Next

                    pdfDoc.Add(pdfTable)
                    pdfDoc.Close()
                    stream.Close()
                End Using

                MsgBox("PDF Report successfully generated and saved!", MsgBoxStyle.Information)
            Catch ex As Exception
                MsgBox("Error Generating PDF: " & ex.Message, MsgBoxStyle.Critical)
            End Try
        End If
    End Sub

End Class