﻿Imports System.Data.OleDb
Imports System.IO
Imports iTextSharp.text
Imports iTextSharp.text.pdf
Imports Excel = Microsoft.Office.Interop.Excel

Public Class frmReports

    Private Sub frmReports_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        dtpReportMonth.Format = DateTimePickerFormat.Custom
        dtpReportMonth.CustomFormat = "MMMM yyyy"
        RefreshReportData()
    End Sub

    Private Sub RefreshReportData(Optional ByVal searchTerm As String = "")
        LoadMonthlyReport(searchTerm)
        LoadOccupancyStats()
    End Sub

    Private Sub btnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click
        RefreshReportData(txtSearch.Text.Trim())
    End Sub

    Private Sub btnRefresh_Click(sender As Object, e As EventArgs) Handles btnRefresh.Click
        txtSearch.Clear()
        RefreshReportData()
    End Sub

    Private Sub dtpReportMonth_ValueChanged(sender As Object, e As EventArgs) Handles dtpReportMonth.ValueChanged
        RefreshReportData(txtSearch.Text.Trim())
    End Sub

    Private Sub LoadMonthlyReport(ByVal searchTerm As String)
        Using myConn As New OleDbConnection(ConnectionString)
            Try
                Dim selectedDate As DateTime = dtpReportMonth.Value
                Dim sql As String = "SELECT t.[FullName], r.[RoomNumber], b.[BillingMonth], b.[TotalAmount], b.[IsPaid] " &
                                   "FROM (tblBillings AS b INNER JOIN tblTenants AS t ON b.ContractID = t.TenantID) " &
                                   "INNER JOIN tblRooms AS r ON t.RoomID = r.RoomID " &
                                   "WHERE MONTH(b.[BillingMonth]) = @month AND YEAR(b.[BillingMonth]) = @year"

                If searchTerm <> "" Then
                    sql &= " AND t.[FullName] LIKE '%" & searchTerm & "%'"
                End If

                Dim cmd As New OleDbCommand(sql, myConn)
                cmd.Parameters.AddWithValue("@month", selectedDate.Month)
                cmd.Parameters.AddWithValue("@year", selectedDate.Year)

                Dim adapter As New OleDbDataAdapter(cmd)
                Dim dt As New DataTable
                adapter.Fill(dt)
                dgvReports.DataSource = dt

                Dim totalBilled As Decimal = 0
                Dim unpaidCount As Integer = 0

                For Each row As DataRow In dt.Rows
                    totalBilled += CDec(row("TotalAmount"))
                    If row("IsPaid").ToString().Trim() = "No" Then unpaidCount += 1
                Next

                lblTotalCollection.Text = "₱" & totalBilled.ToString("N2")
                lblUnpaidCount.Text = unpaidCount.ToString()
                lblUnpaidCount.ForeColor = If(unpaidCount > 0, Color.Crimson, Color.SeaGreen)

            Catch ex As Exception
            End Try
        End Using
    End Sub

    Private Sub LoadOccupancyStats()
        Using myConn As New OleDbConnection(ConnectionString)
            Try
                myConn.Open()
                Dim cmdOcc As New OleDbCommand("SELECT COUNT(*) FROM tblRooms WHERE [Status] LIKE 'Occupied%'", myConn)
                Dim cmdTotal As New OleDbCommand("SELECT COUNT(*) FROM tblRooms", myConn)
                Dim occupied As Integer = CInt(cmdOcc.ExecuteScalar())
                Dim totalRooms As Integer = CInt(cmdTotal.ExecuteScalar())
                Dim percentage As Integer = If(totalRooms > 0, Math.Round((occupied / totalRooms) * 100), 0)
                lblOccupancyRate.Text = String.Format("{0}%", percentage)
            Catch ex As Exception
            End Try
        End Using
    End Sub

    Private Sub dgvReports_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgvReports.CellClick
        If e.RowIndex >= 0 Then
            Dim tenantName As String = dgvReports.Rows(e.RowIndex).Cells("FullName").Value.ToString()
            Dim roomNum As String = dgvReports.Rows(e.RowIndex).Cells("RoomNumber").Value.ToString()

            Dim tID As Integer = 0
            Dim contactNo As String = "N/A"
            Dim baseRent As String = "0.00"

            Using conn As New OleDbConnection(ConnectionString)
                Try
                    conn.Open()
                    Dim cmd As New OleDbCommand("SELECT TenantID, ContactNo, BaseRent FROM tblTenants WHERE FullName = @name", conn)
                    cmd.Parameters.AddWithValue("@name", tenantName)
                    Dim reader = cmd.ExecuteReader()
                    If reader.Read() Then
                        tID = CInt(reader("TenantID"))
                        contactNo = reader("ContactNo").ToString()
                        If Not IsDBNull(reader("BaseRent")) Then
                            baseRent = CDec(reader("BaseRent")).ToString("N2")
                        End If
                    End If
                Catch ex As Exception
                End Try
            End Using

            If tID = 0 Then Exit Sub

            Dim popup As New Form()
            popup.Text = "Tenant History - " & tenantName
            popup.Size = New System.Drawing.Size(600, 450)
            popup.StartPosition = FormStartPosition.CenterParent
            popup.FormBorderStyle = FormBorderStyle.FixedDialog
            popup.MaximizeBox = False
            popup.MinimizeBox = False
            popup.BackColor = Color.White

            Dim lblInfo As New Label()
            lblInfo.Text = $"Name: {tenantName}{vbCrLf}Room: {roomNum}{vbCrLf}Contact: {contactNo}{vbCrLf}Base Rent: ₱{baseRent}"
            lblInfo.Location = New System.Drawing.Point(20, 20)
            lblInfo.AutoSize = True
            lblInfo.Font = New System.Drawing.Font("Segoe UI", 10, FontStyle.Bold)
            popup.Controls.Add(lblInfo)

            Dim dgvHistory As New DataGridView()
            dgvHistory.Location = New System.Drawing.Point(20, 110)
            dgvHistory.Size = New System.Drawing.Size(540, 280)
            dgvHistory.AllowUserToAddRows = False
            dgvHistory.ReadOnly = True
            dgvHistory.SelectionMode = DataGridViewSelectionMode.FullRowSelect
            dgvHistory.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
            dgvHistory.BackgroundColor = Color.FromArgb(243, 244, 246)
            dgvHistory.RowHeadersVisible = False

            Using conn As New OleDbConnection(ConnectionString)
                Try
                    Dim sql As String = "SELECT FORMAT(BillingMonth, 'mmmm yyyy') AS [Month & Year], TotalAmount AS [Amount], IsPaid AS [Status] FROM tblBillings WHERE ContractID = @tid ORDER BY BillingMonth DESC"
                    Dim cmd As New OleDbCommand(sql, conn)
                    cmd.Parameters.AddWithValue("@tid", tID)
                    Dim adapter As New OleDbDataAdapter(cmd)
                    Dim dtHistory As New DataTable()
                    adapter.Fill(dtHistory)
                    dgvHistory.DataSource = dtHistory
                Catch ex As Exception
                End Try
            End Using

            popup.Controls.Add(dgvHistory)
            popup.ShowDialog()
        End If
    End Sub

    Private Sub btnPrint_Click(sender As Object, e As EventArgs) Handles btnPrint.Click
        If dgvReports.Rows.Count = 0 Then
            MsgBox("Walang data na pwedeng i-print.", MsgBoxStyle.Exclamation)
            Exit Sub
        End If

        Dim sfd As New SaveFileDialog()
        sfd.Filter = "PDF Files (*.pdf)|*.pdf"
        sfd.FileName = "Report_" & dtpReportMonth.Value.ToString("MMMM_yyyy") & ".pdf"

        If sfd.ShowDialog() = DialogResult.OK Then
            Try
                Dim pdfTable As New PdfPTable(dgvReports.ColumnCount)
                pdfTable.DefaultCell.Padding = 3
                pdfTable.WidthPercentage = 100
                pdfTable.HorizontalAlignment = Element.ALIGN_LEFT

                For Each column As DataGridViewColumn In dgvReports.Columns
                    Dim cell As New PdfPCell(New Phrase(column.HeaderText))
                    cell.BackgroundColor = New BaseColor(240, 240, 240)
                    pdfTable.AddCell(cell)
                Next

                For Each row As DataGridViewRow In dgvReports.Rows
                    For Each cell As DataGridViewCell In row.Cells
                        pdfTable.AddCell(If(cell.Value IsNot Nothing, cell.Value.ToString(), ""))
                    Next
                Next

                Using stream As New FileStream(sfd.FileName, FileMode.Create)
                    Dim pdfDoc As New Document(PageSize.A4, 10.0F, 10.0F, 10.0F, 0.0F)
                    PdfWriter.GetInstance(pdfDoc, stream)
                    pdfDoc.Open()
                    pdfDoc.Add(New Phrase("CRISTINA'S PLACE - MONTHLY PERFORMANCE REPORT"))
                    pdfDoc.Add(New Phrase(Environment.NewLine))
                    pdfDoc.Add(New Phrase("Month: " & dtpReportMonth.Text))
                    pdfDoc.Add(New Phrase(Environment.NewLine & Environment.NewLine))
                    pdfDoc.Add(pdfTable)
                    pdfDoc.Add(New Phrase(Environment.NewLine & "Total Billed: " & lblTotalCollection.Text))
                    pdfDoc.Close()
                    stream.Close()
                End Using

                MsgBox("PDF Report successfully generated!", MsgBoxStyle.Information)
            Catch ex As Exception
                MsgBox("Error: " & ex.Message)
            End Try
        End If
    End Sub

    Private Sub btnExport_Click(sender As Object, e As EventArgs) Handles btnExport.Click
        If dgvReports.Rows.Count = 0 Then
            MessageBox.Show("Walang data na pwedeng i-export. Mag-generate muna ng report.", "Empty Report", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return
        End If

        Dim strFolder As String = "C:\Client"
        Dim strFilename As String = strFolder & "\MonthlyReport_" & dtpReportMonth.Value.ToString("MMMM_yyyy") & ".xlsx"

        Dim xlApp As Object = Nothing
        Dim xlWorkBook As Object = Nothing
        Dim xlWorkSheet As Object = Nothing

        Try
            If Not Directory.Exists(strFolder) Then
                Directory.CreateDirectory(strFolder)
            End If

            xlApp = CreateObject("Excel.Application")

            If Not File.Exists(strFilename) Then
                xlWorkBook = xlApp.Workbooks.Add
                xlWorkSheet = xlWorkBook.ActiveSheet
                xlWorkBook.SaveAs(strFilename)
            Else
                xlWorkBook = xlApp.Workbooks.Open(strFilename)
                xlWorkSheet = xlWorkBook.Worksheets(1)
            End If

            xlWorkSheet.Cells.ClearContents()

            For i As Integer = 0 To dgvReports.Columns.Count - 1
                xlWorkSheet.Cells(1, i + 1).Value = dgvReports.Columns(i).HeaderText
            Next

            For i As Integer = 0 To dgvReports.Rows.Count - 1
                For j As Integer = 0 To dgvReports.Columns.Count - 1
                    If dgvReports.Rows(i).Cells(j).Value IsNot Nothing Then
                        xlWorkSheet.Cells(i + 2, j + 1).Value = dgvReports.Rows(i).Cells(j).Value.ToString()
                    End If
                Next
            Next

            xlWorkSheet.Rows(1).Font.Bold = True
            xlWorkSheet.Columns.AutoFit()

            xlWorkBook.Save()
            xlApp.Visible = True
            MessageBox.Show("Report Successfully Exported to: " & strFilename, "Export Success", MessageBoxButtons.OK, MessageBoxIcon.Information)

        Catch ex As Exception
            MessageBox.Show("Excel Export Error: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            ReleaseObject(xlWorkSheet)
            ReleaseObject(xlWorkBook)
            ReleaseObject(xlApp)
        End Try
    End Sub

    Private Sub ReleaseObject(ByVal obj As Object)
        Try
            If obj IsNot Nothing Then
                System.Runtime.InteropServices.Marshal.ReleaseComObject(obj)
                obj = Nothing
            End If
        Catch ex As Exception
            obj = Nothing
        Finally
            GC.Collect()
            GC.WaitForPendingFinalizers()
        End Try
    End Sub

End Class