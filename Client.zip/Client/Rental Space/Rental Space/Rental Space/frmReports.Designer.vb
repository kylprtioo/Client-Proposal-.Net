﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmReports
    Inherits System.Windows.Forms.Form

    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    Private components As System.ComponentModel.IContainer

    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As DataGridViewCellStyle = New DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As DataGridViewCellStyle = New DataGridViewCellStyle()
        lblTitle = New Label()
        Label1 = New Label()
        dtpReportMonth = New DateTimePicker()
        cmbFilter = New ComboBox()
        txtSearch = New TextBox()
        btnSearch = New Button()
        btnExport = New Button()
        btnPrint = New Button()
        Panel1 = New Panel()
        lblTotalCollection = New Label()
        Label2 = New Label()
        Panel2 = New Panel()
        lblOccupancyRate = New Label()
        Label3 = New Label()
        Panel3 = New Panel()
        lblUnpaidCount = New Label()
        Label5 = New Label()
        dgvReports = New DataGridView()
        btnRefresh = New Button()
        lblMissing = New Label()
        dgvMissingBillings = New DataGridView()
        btnAutoBill = New Button()
        Panel1.SuspendLayout()
        Panel2.SuspendLayout()
        Panel3.SuspendLayout()
        CType(dgvReports, ComponentModel.ISupportInitialize).BeginInit()
        CType(dgvMissingBillings, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' lblTitle
        ' 
        lblTitle.AutoSize = True
        lblTitle.Font = New Font("Segoe UI", 20.25F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblTitle.ForeColor = Color.FromArgb(CByte(31), CByte(41), CByte(55))
        lblTitle.Location = New Point(20, 20)
        lblTitle.Name = "lblTitle"
        lblTitle.Size = New Size(463, 37)
        lblTitle.TabIndex = 0
        lblTitle.Text = "MONTHLY PERFORMANCE REPORT"
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Segoe UI Semibold", 10.0F, FontStyle.Bold)
        Label1.ForeColor = Color.FromArgb(CByte(100), CByte(116), CByte(139))
        Label1.Location = New Point(23, 85)
        Label1.Name = "Label1"
        Label1.Size = New Size(96, 19)
        Label1.TabIndex = 1
        Label1.Text = "Select Month:"
        ' 
        ' dtpReportMonth
        ' 
        dtpReportMonth.CustomFormat = "MMMM yyyy"
        dtpReportMonth.Font = New Font("Segoe UI", 11.0F)
        dtpReportMonth.Format = DateTimePickerFormat.Custom
        dtpReportMonth.Location = New Point(130, 80)
        dtpReportMonth.Name = "dtpReportMonth"
        dtpReportMonth.Size = New Size(190, 27)
        dtpReportMonth.TabIndex = 2
        ' 
        ' cmbFilter
        ' 
        cmbFilter.DropDownStyle = ComboBoxStyle.DropDownList
        cmbFilter.Font = New Font("Segoe UI", 11.0F)
        cmbFilter.FormattingEnabled = True
        cmbFilter.Location = New Point(330, 80)
        cmbFilter.Name = "cmbFilter"
        cmbFilter.Size = New Size(150, 28)
        cmbFilter.TabIndex = 11
        ' 
        ' txtSearch
        ' 
        txtSearch.Font = New Font("Segoe UI", 11.0F)
        txtSearch.Location = New Point(490, 80)
        txtSearch.Name = "txtSearch"
        txtSearch.Size = New Size(150, 27)
        txtSearch.TabIndex = 9
        ' 
        ' btnSearch
        ' 
        btnSearch.BackColor = Color.FromArgb(CByte(31), CByte(97), CByte(141))
        btnSearch.Cursor = Cursors.Hand
        btnSearch.FlatAppearance.BorderSize = 0
        btnSearch.FlatStyle = FlatStyle.Flat
        btnSearch.Font = New Font("Segoe UI", 10.0F, FontStyle.Bold)
        btnSearch.ForeColor = Color.White
        btnSearch.Location = New Point(650, 75)
        btnSearch.Name = "btnSearch"
        btnSearch.Size = New Size(80, 35)
        btnSearch.TabIndex = 10
        btnSearch.Text = "SEARCH"
        btnSearch.UseVisualStyleBackColor = False
        ' 
        ' btnExport
        ' 
        btnExport.BackColor = Color.SeaGreen
        btnExport.Cursor = Cursors.Hand
        btnExport.FlatAppearance.BorderSize = 0
        btnExport.FlatStyle = FlatStyle.Flat
        btnExport.Font = New Font("Segoe UI", 10.0F, FontStyle.Bold)
        btnExport.ForeColor = Color.White
        btnExport.Location = New Point(830, 75)
        btnExport.Name = "btnExport"
        btnExport.Size = New Size(100, 35)
        btnExport.TabIndex = 3
        btnExport.Text = "EXPORT EXCEL"
        btnExport.UseVisualStyleBackColor = False
        ' 
        ' btnPrint
        ' 
        btnPrint.BackColor = Color.IndianRed
        btnPrint.Cursor = Cursors.Hand
        btnPrint.FlatAppearance.BorderSize = 0
        btnPrint.FlatStyle = FlatStyle.Flat
        btnPrint.Font = New Font("Segoe UI", 10.0F, FontStyle.Bold)
        btnPrint.ForeColor = Color.White
        btnPrint.Location = New Point(940, 75)
        btnPrint.Name = "btnPrint"
        btnPrint.Size = New Size(90, 35)
        btnPrint.TabIndex = 4
        btnPrint.Text = "EXPORT PDF"
        btnPrint.UseVisualStyleBackColor = False
        ' 
        ' Panel1
        ' 
        Panel1.BackColor = Color.White
        Panel1.Controls.Add(lblTotalCollection)
        Panel1.Controls.Add(Label2)
        Panel1.Location = New Point(27, 140)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(320, 110)
        Panel1.TabIndex = 5
        ' 
        ' lblTotalCollection
        ' 
        lblTotalCollection.Font = New Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblTotalCollection.ForeColor = Color.SeaGreen
        lblTotalCollection.Location = New Point(0, 50)
        lblTotalCollection.Name = "lblTotalCollection"
        lblTotalCollection.Size = New Size(320, 35)
        lblTotalCollection.TabIndex = 1
        lblTotalCollection.Text = "₱ 0.00"
        lblTotalCollection.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' Label2
        ' 
        Label2.Font = New Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label2.ForeColor = Color.FromArgb(CByte(100), CByte(116), CByte(139))
        Label2.Location = New Point(0, 20)
        Label2.Name = "Label2"
        Label2.Size = New Size(320, 25)
        Label2.TabIndex = 0
        Label2.Text = "Total Collection"
        Label2.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' Panel2
        ' 
        Panel2.BackColor = Color.White
        Panel2.Controls.Add(lblOccupancyRate)
        Panel2.Controls.Add(Label3)
        Panel2.Location = New Point(365, 140)
        Panel2.Name = "Panel2"
        Panel2.Size = New Size(320, 110)
        Panel2.TabIndex = 6
        ' 
        ' lblOccupancyRate
        ' 
        lblOccupancyRate.Font = New Font("Segoe UI", 16.0F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblOccupancyRate.ForeColor = Color.RoyalBlue
        lblOccupancyRate.Location = New Point(0, 50)
        lblOccupancyRate.Name = "lblOccupancyRate"
        lblOccupancyRate.Size = New Size(320, 35)
        lblOccupancyRate.TabIndex = 1
        lblOccupancyRate.Text = "0%"
        lblOccupancyRate.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' Label3
        ' 
        Label3.Font = New Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label3.ForeColor = Color.FromArgb(CByte(100), CByte(116), CByte(139))
        Label3.Location = New Point(0, 20)
        Label3.Name = "Label3"
        Label3.Size = New Size(320, 25)
        Label3.TabIndex = 0
        Label3.Text = "Occupancy Rate"
        Label3.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' Panel3
        ' 
        Panel3.BackColor = Color.White
        Panel3.Controls.Add(lblUnpaidCount)
        Panel3.Controls.Add(Label5)
        Panel3.Location = New Point(700, 140)
        Panel3.Name = "Panel3"
        Panel3.Size = New Size(320, 110)
        Panel3.TabIndex = 6
        ' 
        ' lblUnpaidCount
        ' 
        lblUnpaidCount.Font = New Font("Segoe UI", 16.0F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblUnpaidCount.ForeColor = Color.Crimson
        lblUnpaidCount.Location = New Point(0, 50)
        lblUnpaidCount.Name = "lblUnpaidCount"
        lblUnpaidCount.Size = New Size(320, 35)
        lblUnpaidCount.TabIndex = 3
        lblUnpaidCount.Text = "0"
        lblUnpaidCount.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' Label5
        ' 
        Label5.Font = New Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label5.ForeColor = Color.FromArgb(CByte(100), CByte(116), CByte(139))
        Label5.Location = New Point(0, 20)
        Label5.Name = "Label5"
        Label5.Size = New Size(320, 25)
        Label5.TabIndex = 2
        Label5.Text = "Unpaid Bills"
        Label5.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' dgvReports
        ' 
        dgvReports.AllowUserToAddRows = False
        dgvReports.Anchor = AnchorStyles.Top Or AnchorStyles.Left Or AnchorStyles.Right
        dgvReports.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
        dgvReports.BackgroundColor = Color.White
        dgvReports.BorderStyle = BorderStyle.None
        dgvReports.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal
        DataGridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = Color.FromArgb(CByte(243), CByte(244), CByte(246))
        DataGridViewCellStyle1.Font = New Font("Segoe UI Semibold", 10.0F, FontStyle.Bold)
        DataGridViewCellStyle1.ForeColor = Color.FromArgb(CByte(31), CByte(41), CByte(55))
        DataGridViewCellStyle1.SelectionBackColor = Color.FromArgb(CByte(243), CByte(244), CByte(246))
        DataGridViewCellStyle1.SelectionForeColor = Color.FromArgb(CByte(31), CByte(41), CByte(55))
        DataGridViewCellStyle1.WrapMode = DataGridViewTriState.True
        dgvReports.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        dgvReports.ColumnHeadersHeight = 40
        DataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = Color.White
        DataGridViewCellStyle2.Font = New Font("Segoe UI", 10.0F)
        DataGridViewCellStyle2.ForeColor = Color.FromArgb(CByte(31), CByte(41), CByte(55))
        DataGridViewCellStyle2.SelectionBackColor = Color.FromArgb(CByte(31), CByte(97), CByte(141))
        DataGridViewCellStyle2.SelectionForeColor = Color.White
        DataGridViewCellStyle2.WrapMode = DataGridViewTriState.False
        dgvReports.DefaultCellStyle = DataGridViewCellStyle2
        dgvReports.EnableHeadersVisualStyles = False
        dgvReports.Location = New Point(27, 275)
        dgvReports.Name = "dgvReports"
        dgvReports.ReadOnly = True
        dgvReports.RowHeadersVisible = False
        dgvReports.RowTemplate.Height = 35
        dgvReports.SelectionMode = DataGridViewSelectionMode.FullRowSelect
        dgvReports.Size = New Size(993, 210)
        dgvReports.TabIndex = 7
        ' 
        ' btnRefresh
        ' 
        btnRefresh.BackColor = Color.FromArgb(CByte(31), CByte(41), CByte(55))
        btnRefresh.Cursor = Cursors.Hand
        btnRefresh.FlatAppearance.BorderSize = 0
        btnRefresh.FlatStyle = FlatStyle.Flat
        btnRefresh.Font = New Font("Segoe UI", 10.0F, FontStyle.Bold)
        btnRefresh.ForeColor = Color.White
        btnRefresh.Location = New Point(740, 75)
        btnRefresh.Name = "btnRefresh"
        btnRefresh.Size = New Size(80, 35)
        btnRefresh.TabIndex = 8
        btnRefresh.Text = "REFRESH"
        btnRefresh.UseVisualStyleBackColor = False
        ' 
        ' lblMissing
        ' 
        lblMissing.Anchor = AnchorStyles.Bottom Or AnchorStyles.Left
        lblMissing.AutoSize = True
        lblMissing.Font = New Font("Segoe UI Semibold", 10.0F, FontStyle.Bold)
        lblMissing.ForeColor = Color.FromArgb(CByte(100), CByte(116), CByte(139))
        lblMissing.Location = New Point(23, 495)
        lblMissing.Name = "lblMissing"
        lblMissing.Size = New Size(268, 19)
        lblMissing.TabIndex = 12
        lblMissing.Text = "Missing Billings for the Month (Pending):"
        ' 
        ' dgvMissingBillings
        ' 
        dgvMissingBillings.AllowUserToAddRows = False
        dgvMissingBillings.Anchor = AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right
        dgvMissingBillings.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
        dgvMissingBillings.BackgroundColor = Color.White
        dgvMissingBillings.BorderStyle = BorderStyle.None
        dgvMissingBillings.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal
        dgvMissingBillings.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        dgvMissingBillings.ColumnHeadersHeight = 30
        dgvMissingBillings.DefaultCellStyle = DataGridViewCellStyle2
        dgvMissingBillings.EnableHeadersVisualStyles = False
        dgvMissingBillings.Location = New Point(27, 520)
        dgvMissingBillings.Name = "dgvMissingBillings"
        dgvMissingBillings.ReadOnly = True
        dgvMissingBillings.RowHeadersVisible = False
        dgvMissingBillings.RowTemplate.Height = 30
        dgvMissingBillings.SelectionMode = DataGridViewSelectionMode.FullRowSelect
        dgvMissingBillings.Size = New Size(790, 130)
        dgvMissingBillings.TabIndex = 13
        ' 
        ' btnAutoBill
        ' 
        btnAutoBill.Anchor = AnchorStyles.Bottom Or AnchorStyles.Right
        btnAutoBill.BackColor = Color.DarkOrange
        btnAutoBill.Cursor = Cursors.Hand
        btnAutoBill.FlatAppearance.BorderSize = 0
        btnAutoBill.FlatStyle = FlatStyle.Flat
        btnAutoBill.Font = New Font("Segoe UI", 10.0F, FontStyle.Bold)
        btnAutoBill.ForeColor = Color.White
        btnAutoBill.Location = New Point(830, 520)
        btnAutoBill.Name = "btnAutoBill"
        btnAutoBill.Size = New Size(190, 50)
        btnAutoBill.TabIndex = 14
        btnAutoBill.Text = "⚡ AUTO-BILL MISSING"
        btnAutoBill.UseVisualStyleBackColor = False
        ' 
        ' frmReports
        ' 
        AutoScaleDimensions = New SizeF(7.0F, 17.0F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.FromArgb(CByte(243), CByte(244), CByte(246))
        ClientSize = New Size(1050, 680)
        Controls.Add(btnAutoBill)
        Controls.Add(dgvMissingBillings)
        Controls.Add(lblMissing)
        Controls.Add(cmbFilter)
        Controls.Add(btnSearch)
        Controls.Add(txtSearch)
        Controls.Add(btnRefresh)
        Controls.Add(dgvReports)
        Controls.Add(Panel3)
        Controls.Add(Panel2)
        Controls.Add(Panel1)
        Controls.Add(btnPrint)
        Controls.Add(btnExport)
        Controls.Add(dtpReportMonth)
        Controls.Add(Label1)
        Controls.Add(lblTitle)
        Font = New Font("Segoe UI", 9.75F)
        Name = "frmReports"
        StartPosition = FormStartPosition.CenterScreen
        Text = "Reports"
        Panel1.ResumeLayout(False)
        Panel2.ResumeLayout(False)
        Panel3.ResumeLayout(False)
        CType(dgvReports, ComponentModel.ISupportInitialize).EndInit()
        CType(dgvMissingBillings, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()

    End Sub

    Friend WithEvents lblTitle As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents dtpReportMonth As System.Windows.Forms.DateTimePicker
    Friend WithEvents cmbFilter As System.Windows.Forms.ComboBox
    Friend WithEvents txtSearch As System.Windows.Forms.TextBox
    Friend WithEvents btnSearch As System.Windows.Forms.Button
    Friend WithEvents btnExport As System.Windows.Forms.Button
    Friend WithEvents btnPrint As System.Windows.Forms.Button
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents lblTotalCollection As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents lblOccupancyRate As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents lblUnpaidCount As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents dgvReports As System.Windows.Forms.DataGridView
    Friend WithEvents btnRefresh As System.Windows.Forms.Button
    Friend WithEvents lblMissing As System.Windows.Forms.Label
    Friend WithEvents dgvMissingBillings As System.Windows.Forms.DataGridView
    Friend WithEvents btnAutoBill As System.Windows.Forms.Button
End Class