﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmLogin
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        pnlMain = New Panel()
        pnlHeader = New Panel()
        lblTitle = New Label()
        lblSubtitle = New Label()
        pnlForm = New Panel()
        lblUsername = New Label()
        txtUsername = New TextBox()
        lblPassword = New Label()
        txtPassword = New TextBox()
        btnLogin = New Button()
        lblError = New Label()
        lblCopyright = New Label()
        pnlMain.SuspendLayout()
        pnlHeader.SuspendLayout()
        pnlForm.SuspendLayout()
        SuspendLayout()
        ' 
        ' pnlMain
        ' 
        pnlMain.BackColor = Color.White
        pnlMain.Controls.Add(pnlHeader)
        pnlMain.Controls.Add(pnlForm)
        pnlMain.Controls.Add(lblCopyright)
        pnlMain.Dock = DockStyle.Fill
        pnlMain.Location = New Point(0, 0)
        pnlMain.Name = "pnlMain"
        pnlMain.Size = New Size(420, 520)
        pnlMain.TabIndex = 0
        ' 
        ' pnlHeader
        ' 
        pnlHeader.BackColor = Color.FromArgb(CByte(31), CByte(97), CByte(141))
        pnlHeader.Controls.Add(lblTitle)
        pnlHeader.Controls.Add(lblSubtitle)
        pnlHeader.Dock = DockStyle.Top
        pnlHeader.Location = New Point(0, 0)
        pnlHeader.Name = "pnlHeader"
        pnlHeader.Size = New Size(420, 130)
        pnlHeader.TabIndex = 0
        ' 
        ' lblTitle
        ' 
        lblTitle.Font = New Font("Segoe UI", 22.0F, FontStyle.Bold)
        lblTitle.ForeColor = Color.White
        lblTitle.Location = New Point(20, 28)
        lblTitle.Name = "lblTitle"
        lblTitle.Size = New Size(294, 45)
        lblTitle.TabIndex = 0
        lblTitle.Text = "🏠 Rental Space"
        lblTitle.TextAlign = ContentAlignment.MiddleLeft
        ' 
        ' lblSubtitle
        ' 
        lblSubtitle.Font = New Font("Segoe UI", 10.0F)
        lblSubtitle.ForeColor = Color.FromArgb(CByte(200), CByte(230), CByte(255))
        lblSubtitle.Location = New Point(22, 76)
        lblSubtitle.Name = "lblSubtitle"
        lblSubtitle.Size = New Size(292, 25)
        lblSubtitle.TabIndex = 1
        lblSubtitle.Text = "Property Management System"
        ' 
        ' pnlForm
        ' 
        pnlForm.Controls.Add(lblUsername)
        pnlForm.Controls.Add(txtUsername)
        pnlForm.Controls.Add(lblPassword)
        pnlForm.Controls.Add(txtPassword)
        pnlForm.Controls.Add(btnLogin)
        pnlForm.Controls.Add(lblError)
        pnlForm.Location = New Point(30, 150)
        pnlForm.Name = "pnlForm"
        pnlForm.Size = New Size(360, 320)
        pnlForm.TabIndex = 1
        ' 
        ' lblUsername
        ' 
        lblUsername.Font = New Font("Segoe UI", 10.0F, FontStyle.Bold)
        lblUsername.ForeColor = Color.FromArgb(CByte(44), CByte(62), CByte(80))
        lblUsername.Location = New Point(0, 0)
        lblUsername.Name = "lblUsername"
        lblUsername.Size = New Size(360, 25)
        lblUsername.TabIndex = 0
        lblUsername.Text = "Username"
        ' 
        ' txtUsername
        ' 
        txtUsername.Font = New Font("Segoe UI", 11.0F)
        txtUsername.Location = New Point(0, 28)
        txtUsername.MaxLength = 50
        txtUsername.Name = "txtUsername"
        txtUsername.Size = New Size(360, 27)
        txtUsername.TabIndex = 1
        ' 
        ' lblPassword
        ' 
        lblPassword.Font = New Font("Segoe UI", 10.0F, FontStyle.Bold)
        lblPassword.ForeColor = Color.FromArgb(CByte(44), CByte(62), CByte(80))
        lblPassword.Location = New Point(0, 76)
        lblPassword.Name = "lblPassword"
        lblPassword.Size = New Size(360, 25)
        lblPassword.TabIndex = 2
        lblPassword.Text = "Password"
        ' 
        ' txtPassword
        ' 
        txtPassword.Font = New Font("Segoe UI", 11.0F)
        txtPassword.Location = New Point(0, 104)
        txtPassword.MaxLength = 100
        txtPassword.Name = "txtPassword"
        txtPassword.Size = New Size(360, 27)
        txtPassword.TabIndex = 3
        txtPassword.UseSystemPasswordChar = True
        ' 
        ' btnLogin
        ' 
        btnLogin.BackColor = Color.FromArgb(CByte(31), CByte(97), CByte(141))
        btnLogin.Cursor = Cursors.Hand
        btnLogin.FlatAppearance.BorderSize = 0
        btnLogin.FlatStyle = FlatStyle.Flat
        btnLogin.Font = New Font("Segoe UI", 11.0F, FontStyle.Bold)
        btnLogin.ForeColor = Color.White
        btnLogin.Location = New Point(0, 210)
        btnLogin.Name = "btnLogin"
        btnLogin.Size = New Size(360, 44)
        btnLogin.TabIndex = 6
        btnLogin.Text = "Log In"
        btnLogin.UseVisualStyleBackColor = False
        ' 
        ' lblError
        ' 
        lblError.Font = New Font("Segoe UI", 9.0F)
        lblError.ForeColor = Color.Crimson
        lblError.Location = New Point(0, 170)
        lblError.Name = "lblError"
        lblError.Size = New Size(360, 35)
        lblError.TabIndex = 5
        lblError.Visible = False
        ' 
        ' lblCopyright
        ' 
        lblCopyright.Dock = DockStyle.Bottom
        lblCopyright.Font = New Font("Segoe UI", 8.0F)
        lblCopyright.ForeColor = Color.Gray
        lblCopyright.Location = New Point(0, 496)
        lblCopyright.Name = "lblCopyright"
        lblCopyright.Size = New Size(420, 24)
        lblCopyright.TabIndex = 2
        lblCopyright.Text = "© 2026 Rental Space Management System"
        lblCopyright.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' frmLogin
        ' 
        AutoScaleDimensions = New SizeF(7.0F, 15.0F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(420, 520)
        Controls.Add(pnlMain)
        FormBorderStyle = FormBorderStyle.FixedSingle
        MaximizeBox = False
        MinimizeBox = False
        Name = "frmLogin"
        StartPosition = FormStartPosition.CenterScreen
        Text = "Rental Space - Login"
        pnlMain.ResumeLayout(False)
        pnlHeader.ResumeLayout(False)
        pnlForm.ResumeLayout(False)
        pnlForm.PerformLayout()
        ResumeLayout(False)

    End Sub

    Friend WithEvents pnlMain As System.Windows.Forms.Panel
    Friend WithEvents pnlHeader As System.Windows.Forms.Panel
    Friend WithEvents lblTitle As System.Windows.Forms.Label
    Friend WithEvents lblSubtitle As System.Windows.Forms.Label
    Friend WithEvents pnlForm As System.Windows.Forms.Panel
    Friend WithEvents lblUsername As System.Windows.Forms.Label
    Friend WithEvents txtUsername As System.Windows.Forms.TextBox
    Friend WithEvents lblPassword As System.Windows.Forms.Label
    Friend WithEvents txtPassword As System.Windows.Forms.TextBox
    Friend WithEvents btnLogin As System.Windows.Forms.Button
    Friend WithEvents lblError As System.Windows.Forms.Label
    Friend WithEvents lblCopyright As System.Windows.Forms.Label
End Class