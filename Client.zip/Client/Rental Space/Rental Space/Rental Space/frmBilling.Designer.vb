﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmBilling
    Inherits System.Windows.Forms.Form

    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    Private components As System.ComponentModel.IContainer

    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.grpTenantInfo = New System.Windows.Forms.GroupBox()
        Me.lblContact = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.cmbTenant = New System.Windows.Forms.ComboBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.btnCompute = New System.Windows.Forms.Button()
        Me.grpCalculation = New System.Windows.Forms.GroupBox()
        Me.LabelRemarks = New System.Windows.Forms.Label()
        Me.txtRemarks = New System.Windows.Forms.TextBox()
        Me.lblTotal = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.dtpBillingMonth = New System.Windows.Forms.DateTimePicker()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.LabelBaseRent = New System.Windows.Forms.Label()
        Me.txtBaseRent = New System.Windows.Forms.TextBox()
        Me.LabelAdditionalFees = New System.Windows.Forms.Label()
        Me.txtAdditionalFees = New System.Windows.Forms.TextBox()
        Me.btnSaveBill = New System.Windows.Forms.Button()
        Me.grpTenantInfo.SuspendLayout()
        Me.grpCalculation.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Segoe UI", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CByte(0))
        Me.Label1.ForeColor = System.Drawing.Color.FromArgb(31, 41, 55)
        Me.Label1.Location = New System.Drawing.Point(25, 20)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(325, 37)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "TENANT BILLING ENTRY"
        '
        'grpTenantInfo
        '
        Me.grpTenantInfo.BackColor = System.Drawing.Color.White
        Me.grpTenantInfo.Controls.Add(Me.lblContact)
        Me.grpTenantInfo.Controls.Add(Me.Label5)
        Me.grpTenantInfo.Controls.Add(Me.cmbTenant)
        Me.grpTenantInfo.Controls.Add(Me.Label2)
        Me.grpTenantInfo.Font = New System.Drawing.Font("Segoe UI Semibold", 11.25!, System.Drawing.FontStyle.Bold)
        Me.grpTenantInfo.ForeColor = System.Drawing.Color.FromArgb(31, 41, 55)
        Me.grpTenantInfo.Location = New System.Drawing.Point(30, 80)
        Me.grpTenantInfo.Name = "grpTenantInfo"
        Me.grpTenantInfo.Size = New System.Drawing.Size(380, 200)
        Me.grpTenantInfo.TabIndex = 1
        Me.grpTenantInfo.TabStop = False
        Me.grpTenantInfo.Text = "Tenant Information"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Segoe UI", 9.75!)
        Me.Label2.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139)
        Me.Label2.Location = New System.Drawing.Point(20, 40)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(89, 17)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Select Tenant:"
        '
        'cmbTenant
        '
        Me.cmbTenant.Font = New System.Drawing.Font("Segoe UI", 11.0!)
        Me.cmbTenant.FormattingEnabled = True
        Me.cmbTenant.Location = New System.Drawing.Point(23, 65)
        Me.cmbTenant.Name = "cmbTenant"
        Me.cmbTenant.Size = New System.Drawing.Size(330, 28)
        Me.cmbTenant.TabIndex = 3
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Segoe UI", 9.75!)
        Me.Label5.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139)
        Me.Label5.Location = New System.Drawing.Point(20, 115)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(77, 17)
        Me.Label5.TabIndex = 6
        Me.Label5.Text = "Contact No:"
        '
        'lblContact
        '
        Me.lblContact.AutoSize = True
        Me.lblContact.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular)
        Me.lblContact.Location = New System.Drawing.Point(19, 140)
        Me.lblContact.Name = "lblContact"
        Me.lblContact.Size = New System.Drawing.Size(16, 21)
        Me.lblContact.TabIndex = 7
        Me.lblContact.Text = "-"
        '
        'grpCalculation
        '
        Me.grpCalculation.BackColor = System.Drawing.Color.White
        Me.grpCalculation.Controls.Add(Me.Label6)
        Me.grpCalculation.Controls.Add(Me.dtpBillingMonth)
        Me.grpCalculation.Controls.Add(Me.LabelBaseRent)
        Me.grpCalculation.Controls.Add(Me.txtBaseRent)
        Me.grpCalculation.Controls.Add(Me.LabelAdditionalFees)
        Me.grpCalculation.Controls.Add(Me.txtAdditionalFees)
        Me.grpCalculation.Controls.Add(Me.LabelRemarks)
        Me.grpCalculation.Controls.Add(Me.txtRemarks)
        Me.grpCalculation.Controls.Add(Me.Label12)
        Me.grpCalculation.Controls.Add(Me.lblTotal)
        Me.grpCalculation.Font = New System.Drawing.Font("Segoe UI Semibold", 11.25!, System.Drawing.FontStyle.Bold)
        Me.grpCalculation.ForeColor = System.Drawing.Color.FromArgb(31, 41, 55)
        Me.grpCalculation.Location = New System.Drawing.Point(440, 80)
        Me.grpCalculation.Name = "grpCalculation"
        Me.grpCalculation.Size = New System.Drawing.Size(400, 410)
        Me.grpCalculation.TabIndex = 3
        Me.grpCalculation.TabStop = False
        Me.grpCalculation.Text = "Billing Details"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Segoe UI", 9.75!)
        Me.Label6.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139)
        Me.Label6.Location = New System.Drawing.Point(20, 40)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(86, 17)
        Me.Label6.TabIndex = 0
        Me.Label6.Text = "Billing Period:"
        '
        'dtpBillingMonth
        '
        Me.dtpBillingMonth.Font = New System.Drawing.Font("Segoe UI", 11.0!)
        Me.dtpBillingMonth.Location = New System.Drawing.Point(23, 65)
        Me.dtpBillingMonth.Name = "dtpBillingMonth"
        Me.dtpBillingMonth.Size = New System.Drawing.Size(350, 27)
        Me.dtpBillingMonth.TabIndex = 1
        '
        'LabelBaseRent
        '
        Me.LabelBaseRent.AutoSize = True
        Me.LabelBaseRent.Font = New System.Drawing.Font("Segoe UI", 9.75!)
        Me.LabelBaseRent.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139)
        Me.LabelBaseRent.Location = New System.Drawing.Point(20, 115)
        Me.LabelBaseRent.Name = "LabelBaseRent"
        Me.LabelBaseRent.Size = New System.Drawing.Size(68, 17)
        Me.LabelBaseRent.TabIndex = 2
        Me.LabelBaseRent.Text = "Base Rent:"
        '
        'txtBaseRent
        '
        Me.txtBaseRent.Font = New System.Drawing.Font("Segoe UI", 11.0!)
        Me.txtBaseRent.Location = New System.Drawing.Point(23, 140)
        Me.txtBaseRent.Name = "txtBaseRent"
        Me.txtBaseRent.ReadOnly = True
        Me.txtBaseRent.BackColor = System.Drawing.Color.FromArgb(240, 240, 240)
        Me.txtBaseRent.Size = New System.Drawing.Size(350, 27)
        Me.txtBaseRent.TabIndex = 3
        '
        'LabelAdditionalFees
        '
        Me.LabelAdditionalFees.AutoSize = True
        Me.LabelAdditionalFees.Font = New System.Drawing.Font("Segoe UI", 9.75!)
        Me.LabelAdditionalFees.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139)
        Me.LabelAdditionalFees.Location = New System.Drawing.Point(20, 185)
        Me.LabelAdditionalFees.Name = "LabelAdditionalFees"
        Me.LabelAdditionalFees.Size = New System.Drawing.Size(98, 17)
        Me.LabelAdditionalFees.TabIndex = 4
        Me.LabelAdditionalFees.Text = "Additional Fees:"
        '
        'txtAdditionalFees
        '
        Me.txtAdditionalFees.Font = New System.Drawing.Font("Segoe UI", 11.0!)
        Me.txtAdditionalFees.Location = New System.Drawing.Point(23, 210)
        Me.txtAdditionalFees.Name = "txtAdditionalFees"
        Me.txtAdditionalFees.Size = New System.Drawing.Size(350, 27)
        Me.txtAdditionalFees.TabIndex = 5
        '
        'LabelRemarks
        '
        Me.LabelRemarks.AutoSize = True
        Me.LabelRemarks.Font = New System.Drawing.Font("Segoe UI", 9.75!)
        Me.LabelRemarks.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139)
        Me.LabelRemarks.Location = New System.Drawing.Point(20, 255)
        Me.LabelRemarks.Name = "LabelRemarks"
        Me.LabelRemarks.Size = New System.Drawing.Size(61, 17)
        Me.LabelRemarks.TabIndex = 6
        Me.LabelRemarks.Text = "Remarks:"
        '
        'txtRemarks
        '
        Me.txtRemarks.Font = New System.Drawing.Font("Segoe UI", 11.0!)
        Me.txtRemarks.Location = New System.Drawing.Point(23, 280)
        Me.txtRemarks.Multiline = True
        Me.txtRemarks.Name = "txtRemarks"
        Me.txtRemarks.Size = New System.Drawing.Size(350, 45)
        Me.txtRemarks.TabIndex = 7
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Segoe UI Semibold", 11.0!, System.Drawing.FontStyle.Bold)
        Me.Label12.Location = New System.Drawing.Point(20, 355)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(161, 20)
        Me.Label12.TabIndex = 9
        Me.Label12.Text = "TOTAL AMOUNT DUE:"
        '
        'lblTotal
        '
        Me.lblTotal.AutoSize = True
        Me.lblTotal.Font = New System.Drawing.Font("Segoe UI", 20.25!, System.Drawing.FontStyle.Bold)
        Me.lblTotal.ForeColor = System.Drawing.Color.Crimson
        Me.lblTotal.Location = New System.Drawing.Point(190, 342)
        Me.lblTotal.Name = "lblTotal"
        Me.lblTotal.Size = New System.Drawing.Size(98, 37)
        Me.lblTotal.TabIndex = 10
        Me.lblTotal.Text = "₱ 0.00"
        '
        'btnCompute
        '
        Me.btnCompute.BackColor = System.Drawing.Color.FromArgb(31, 97, 141)
        Me.btnCompute.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnCompute.FlatAppearance.BorderSize = 0
        Me.btnCompute.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnCompute.Font = New System.Drawing.Font("Segoe UI", 11.25!, System.Drawing.FontStyle.Bold)
        Me.btnCompute.ForeColor = System.Drawing.Color.White
        Me.btnCompute.Location = New System.Drawing.Point(440, 510)
        Me.btnCompute.Name = "btnCompute"
        Me.btnCompute.Size = New System.Drawing.Size(190, 45)
        Me.btnCompute.TabIndex = 2
        Me.btnCompute.Text = "COMPUTE BILL"
        Me.btnCompute.UseVisualStyleBackColor = False
        '
        'btnSaveBill
        '
        Me.btnSaveBill.BackColor = System.Drawing.Color.SeaGreen
        Me.btnSaveBill.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnSaveBill.FlatAppearance.BorderSize = 0
        Me.btnSaveBill.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnSaveBill.Font = New System.Drawing.Font("Segoe UI", 11.25!, System.Drawing.FontStyle.Bold)
        Me.btnSaveBill.ForeColor = System.Drawing.Color.White
        Me.btnSaveBill.Location = New System.Drawing.Point(650, 510)
        Me.btnSaveBill.Name = "btnSaveBill"
        Me.btnSaveBill.Size = New System.Drawing.Size(190, 45)
        Me.btnSaveBill.TabIndex = 4
        Me.btnSaveBill.Text = "SAVE INVOICE"
        Me.btnSaveBill.UseVisualStyleBackColor = False
        '
        'frmBilling
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 17.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(243, 244, 246)
        Me.ClientSize = New System.Drawing.Size(880, 600)
        Me.Controls.Add(Me.btnSaveBill)
        Me.Controls.Add(Me.btnCompute)
        Me.Controls.Add(Me.grpCalculation)
        Me.Controls.Add(Me.grpTenantInfo)
        Me.Controls.Add(Me.Label1)
        Me.Font = New System.Drawing.Font("Segoe UI", 9.75!)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.Name = "frmBilling"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Billing Management"
        Me.grpTenantInfo.ResumeLayout(False)
        Me.grpTenantInfo.PerformLayout()
        Me.grpCalculation.ResumeLayout(False)
        Me.grpCalculation.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents grpTenantInfo As GroupBox
    Friend WithEvents lblContact As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents cmbTenant As ComboBox
    Friend WithEvents Label2 As Label
    Friend WithEvents btnCompute As Button
    Friend WithEvents grpCalculation As GroupBox
    Friend WithEvents lblTotal As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents dtpBillingMonth As DateTimePicker
    Friend WithEvents Label6 As Label
    Friend WithEvents LabelBaseRent As Label
    Friend WithEvents txtBaseRent As TextBox
    Friend WithEvents LabelAdditionalFees As Label
    Friend WithEvents txtAdditionalFees As TextBox
    Friend WithEvents LabelRemarks As Label
    Friend WithEvents txtRemarks As TextBox
    Friend WithEvents btnSaveBill As Button
End Class