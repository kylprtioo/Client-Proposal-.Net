﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmBilling
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.grpTenantInfo = New System.Windows.Forms.GroupBox()
        Me.lblContact = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.lblBaseRent = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.cmbTenant = New System.Windows.Forms.ComboBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.btnCompute = New System.Windows.Forms.Button()
        Me.grpCalculation = New System.Windows.Forms.GroupBox()
        Me.lblTotal = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.txtMeralcoRate = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.txtCurrentReading = New System.Windows.Forms.TextBox()
        Me.lblPrevReading = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.dtpBillingMonth = New System.Windows.Forms.DateTimePicker()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.btnSaveBill = New System.Windows.Forms.Button()
        Me.grpTenantInfo.SuspendLayout()
        Me.grpCalculation.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Segoe UI", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CByte(0))
        Me.Label1.ForeColor = System.Drawing.Color.FromArgb(31, 41, 55)
        Me.Label1.Location = New System.Drawing.Point(25, 20)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(325, 37)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "TENANT BILLING ENTRY"
        '
        'grpTenantInfo
        '
        Me.grpTenantInfo.BackColor = System.Drawing.Color.White
        Me.grpTenantInfo.Controls.Add(Me.lblContact)
        Me.grpTenantInfo.Controls.Add(Me.Label5)
        Me.grpTenantInfo.Controls.Add(Me.lblBaseRent)
        Me.grpTenantInfo.Controls.Add(Me.Label3)
        Me.grpTenantInfo.Controls.Add(Me.cmbTenant)
        Me.grpTenantInfo.Controls.Add(Me.Label2)
        Me.grpTenantInfo.Font = New System.Drawing.Font("Segoe UI Semibold", 11.25!, System.Drawing.FontStyle.Bold)
        Me.grpTenantInfo.ForeColor = System.Drawing.Color.FromArgb(31, 41, 55)
        Me.grpTenantInfo.Location = New System.Drawing.Point(30, 80)
        Me.grpTenantInfo.Name = "grpTenantInfo"
        Me.grpTenantInfo.Size = New System.Drawing.Size(380, 280)
        Me.grpTenantInfo.TabIndex = 1
        Me.grpTenantInfo.TabStop = False
        Me.grpTenantInfo.Text = "Tenant Information"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Segoe UI", 9.75!)
        Me.Label2.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139)
        Me.Label2.Location = New System.Drawing.Point(20, 40)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(89, 17)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Select Tenant:"
        '
        'cmbTenant
        '
        Me.cmbTenant.Font = New System.Drawing.Font("Segoe UI", 11.0!)
        Me.cmbTenant.FormattingEnabled = True
        Me.cmbTenant.Location = New System.Drawing.Point(23, 65)
        Me.cmbTenant.Name = "cmbTenant"
        Me.cmbTenant.Size = New System.Drawing.Size(330, 28)
        Me.cmbTenant.TabIndex = 3
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Segoe UI", 9.75!)
        Me.Label3.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139)
        Me.Label3.Location = New System.Drawing.Point(20, 115)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(68, 17)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Base Rent:"
        '
        'lblBaseRent
        '
        Me.lblBaseRent.AutoSize = True
        Me.lblBaseRent.Font = New System.Drawing.Font("Segoe UI", 15.75!, System.Drawing.FontStyle.Bold)
        Me.lblBaseRent.ForeColor = System.Drawing.Color.SeaGreen
        Me.lblBaseRent.Location = New System.Drawing.Point(18, 140)
        Me.lblBaseRent.Name = "lblBaseRent"
        Me.lblBaseRent.Size = New System.Drawing.Size(76, 30)
        Me.lblBaseRent.TabIndex = 5
        Me.lblBaseRent.Text = "₱ 0.00"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Segoe UI", 9.75!)
        Me.Label5.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139)
        Me.Label5.Location = New System.Drawing.Point(20, 195)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(77, 17)
        Me.Label5.TabIndex = 6
        Me.Label5.Text = "Contact No:"
        '
        'lblContact
        '
        Me.lblContact.AutoSize = True
        Me.lblContact.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular)
        Me.lblContact.Location = New System.Drawing.Point(19, 220)
        Me.lblContact.Name = "lblContact"
        Me.lblContact.Size = New System.Drawing.Size(16, 21)
        Me.lblContact.TabIndex = 7
        Me.lblContact.Text = "-"
        '
        'grpCalculation
        '
        Me.grpCalculation.BackColor = System.Drawing.Color.White
        Me.grpCalculation.Controls.Add(Me.lblTotal)
        Me.grpCalculation.Controls.Add(Me.Label12)
        Me.grpCalculation.Controls.Add(Me.txtMeralcoRate)
        Me.grpCalculation.Controls.Add(Me.Label11)
        Me.grpCalculation.Controls.Add(Me.txtCurrentReading)
        Me.grpCalculation.Controls.Add(Me.lblPrevReading)
        Me.grpCalculation.Controls.Add(Me.Label9)
        Me.grpCalculation.Controls.Add(Me.Label8)
        Me.grpCalculation.Controls.Add(Me.Label7)
        Me.grpCalculation.Controls.Add(Me.dtpBillingMonth)
        Me.grpCalculation.Controls.Add(Me.Label6)
        Me.grpCalculation.Font = New System.Drawing.Font("Segoe UI Semibold", 11.25!, System.Drawing.FontStyle.Bold)
        Me.grpCalculation.ForeColor = System.Drawing.Color.FromArgb(31, 41, 55)
        Me.grpCalculation.Location = New System.Drawing.Point(440, 80)
        Me.grpCalculation.Name = "grpCalculation"
        Me.grpCalculation.Size = New System.Drawing.Size(400, 380)
        Me.grpCalculation.TabIndex = 3
        Me.grpCalculation.TabStop = False
        Me.grpCalculation.Text = "Computation & Summary"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Segoe UI", 9.75!)
        Me.Label6.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139)
        Me.Label6.Location = New System.Drawing.Point(20, 40)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(86, 17)
        Me.Label6.TabIndex = 0
        Me.Label6.Text = "Billing Period:"
        '
        'dtpBillingMonth
        '
        Me.dtpBillingMonth.Font = New System.Drawing.Font("Segoe UI", 11.0!)
        Me.dtpBillingMonth.Location = New System.Drawing.Point(23, 65)
        Me.dtpBillingMonth.Name = "dtpBillingMonth"
        Me.dtpBillingMonth.Size = New System.Drawing.Size(350, 27)
        Me.dtpBillingMonth.TabIndex = 1
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Segoe UI Semibold", 10.0!, System.Drawing.FontStyle.Bold)
        Me.Label7.ForeColor = System.Drawing.Color.FromArgb(31, 41, 55)
        Me.Label7.Location = New System.Drawing.Point(20, 115)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(167, 19)
        Me.Label7.TabIndex = 2
        Me.Label7.Text = "Electricity Reading (kWh)"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Segoe UI", 9.75!)
        Me.Label8.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139)
        Me.Label8.Location = New System.Drawing.Point(20, 150)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(60, 17)
        Me.Label8.TabIndex = 3
        Me.Label8.Text = "Previous:"
        '
        'lblPrevReading
        '
        Me.lblPrevReading.AutoSize = True
        Me.lblPrevReading.Font = New System.Drawing.Font("Segoe UI", 11.0!, System.Drawing.FontStyle.Bold)
        Me.lblPrevReading.Location = New System.Drawing.Point(120, 148)
        Me.lblPrevReading.Name = "lblPrevReading"
        Me.lblPrevReading.Size = New System.Drawing.Size(18, 20)
        Me.lblPrevReading.TabIndex = 5
        Me.lblPrevReading.Text = "0"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Segoe UI", 9.75!)
        Me.Label9.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139)
        Me.Label9.Location = New System.Drawing.Point(20, 185)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(55, 17)
        Me.Label9.TabIndex = 4
        Me.Label9.Text = "Current:"
        '
        'txtCurrentReading
        '
        Me.txtCurrentReading.Font = New System.Drawing.Font("Segoe UI", 11.0!)
        Me.txtCurrentReading.Location = New System.Drawing.Point(123, 180)
        Me.txtCurrentReading.Name = "txtCurrentReading"
        Me.txtCurrentReading.Size = New System.Drawing.Size(250, 27)
        Me.txtCurrentReading.TabIndex = 6
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Segoe UI", 9.75!)
        Me.Label11.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139)
        Me.Label11.Location = New System.Drawing.Point(20, 230)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(144, 17)
        Me.Label11.TabIndex = 7
        Me.Label11.Text = "Meralco Rate (per kWh):"
        '
        'txtMeralcoRate
        '
        Me.txtMeralcoRate.Font = New System.Drawing.Font("Segoe UI", 11.0!)
        Me.txtMeralcoRate.Location = New System.Drawing.Point(23, 255)
        Me.txtMeralcoRate.Name = "txtMeralcoRate"
        Me.txtMeralcoRate.Size = New System.Drawing.Size(350, 27)
        Me.txtMeralcoRate.TabIndex = 8
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Segoe UI Semibold", 11.0!, System.Drawing.FontStyle.Bold)
        Me.Label12.Location = New System.Drawing.Point(20, 325)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(161, 20)
        Me.Label12.TabIndex = 9
        Me.Label12.Text = "TOTAL AMOUNT DUE:"
        '
        'lblTotal
        '
        Me.lblTotal.AutoSize = True
        Me.lblTotal.Font = New System.Drawing.Font("Segoe UI", 20.25!, System.Drawing.FontStyle.Bold)
        Me.lblTotal.ForeColor = System.Drawing.Color.Crimson
        Me.lblTotal.Location = New System.Drawing.Point(190, 312)
        Me.lblTotal.Name = "lblTotal"
        Me.lblTotal.Size = New System.Drawing.Size(98, 37)
        Me.lblTotal.TabIndex = 10
        Me.lblTotal.Text = "₱ 0.00"
        '
        'btnCompute
        '
        Me.btnCompute.BackColor = System.Drawing.Color.FromArgb(31, 97, 141)
        Me.btnCompute.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnCompute.FlatAppearance.BorderSize = 0
        Me.btnCompute.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnCompute.Font = New System.Drawing.Font("Segoe UI", 11.25!, System.Drawing.FontStyle.Bold)
        Me.btnCompute.ForeColor = System.Drawing.Color.White
        Me.btnCompute.Location = New System.Drawing.Point(440, 480)
        Me.btnCompute.Name = "btnCompute"
        Me.btnCompute.Size = New System.Drawing.Size(190, 45)
        Me.btnCompute.TabIndex = 2
        Me.btnCompute.Text = "COMPUTE BILL"
        Me.btnCompute.UseVisualStyleBackColor = False
        '
        'btnSaveBill
        '
        Me.btnSaveBill.BackColor = System.Drawing.Color.SeaGreen
        Me.btnSaveBill.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnSaveBill.FlatAppearance.BorderSize = 0
        Me.btnSaveBill.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnSaveBill.Font = New System.Drawing.Font("Segoe UI", 11.25!, System.Drawing.FontStyle.Bold)
        Me.btnSaveBill.ForeColor = System.Drawing.Color.White
        Me.btnSaveBill.Location = New System.Drawing.Point(650, 480)
        Me.btnSaveBill.Name = "btnSaveBill"
        Me.btnSaveBill.Size = New System.Drawing.Size(190, 45)
        Me.btnSaveBill.TabIndex = 4
        Me.btnSaveBill.Text = "SAVE INVOICE"
        Me.btnSaveBill.UseVisualStyleBackColor = False
        '
        'frmBilling
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 17.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(243, 244, 246)
        Me.ClientSize = New System.Drawing.Size(880, 560)
        Me.Controls.Add(Me.btnSaveBill)
        Me.Controls.Add(Me.btnCompute)
        Me.Controls.Add(Me.grpCalculation)
        Me.Controls.Add(Me.grpTenantInfo)
        Me.Controls.Add(Me.Label1)
        Me.Font = New System.Drawing.Font("Segoe UI", 9.75!)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.Name = "frmBilling"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Billing Management"
        Me.grpTenantInfo.ResumeLayout(False)
        Me.grpTenantInfo.PerformLayout()
        Me.grpCalculation.ResumeLayout(False)
        Me.grpCalculation.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents grpTenantInfo As GroupBox
    Friend WithEvents lblContact As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents lblBaseRent As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents cmbTenant As ComboBox
    Friend WithEvents Label2 As Label
    Friend WithEvents btnCompute As Button
    Friend WithEvents grpCalculation As GroupBox
    Friend WithEvents lblTotal As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents txtMeralcoRate As TextBox
    Friend WithEvents Label11 As Label
    Friend WithEvents txtCurrentReading As TextBox
    Friend WithEvents lblPrevReading As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents dtpBillingMonth As DateTimePicker
    Friend WithEvents Label6 As Label
    Friend WithEvents btnSaveBill As Button
End Class