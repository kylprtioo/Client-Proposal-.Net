﻿Imports System.Data.OleDb
Imports System.IO

Public Module dbConnection

    Public conn As New OleDbConnection
    Public connString As String = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Client\rental.accdb"
    Public currentUserRole As String = ""
    Public currentUsername As String = ""

    Public ReadOnly Property ConnectionString As String
        Get
            Return connString
        End Get
    End Property

    Public Sub dbConnect()
        Try
            If conn.State = ConnectionState.Closed Then
                conn.ConnectionString = connString
                conn.Open()
            End If
        Catch ex As Exception
            MsgBox("Database Error: " & ex.Message, MsgBoxStyle.Critical)
        End Try
    End Sub

    Public Sub dbDisconnect()
        If conn.State = ConnectionState.Open Then
            conn.Close()
        End If
    End Sub

    Public Function ExecuteNonQuery(sql As String, ParamArray params() As OleDbParameter) As Integer
        Try
            Using localConn As New OleDbConnection(connString)
                localConn.Open()
                Using cmd As New OleDbCommand(sql, localConn)
                    If params IsNot Nothing Then
                        cmd.Parameters.AddRange(params)
                    End If
                    Return cmd.ExecuteNonQuery()
                End Using
            End Using
        Catch ex As Exception
            MsgBox($"Database error:{Environment.NewLine}{ex.Message}", MsgBoxStyle.Critical)
            Return -1
        End Try
    End Function

    Public Function ExecuteScalar(sql As String, ParamArray params() As OleDbParameter) As Object
        Try
            Using localConn As New OleDbConnection(connString)
                localConn.Open()
                Using cmd As New OleDbCommand(sql, localConn)
                    If params IsNot Nothing Then
                        cmd.Parameters.AddRange(params)
                    End If
                    Return cmd.ExecuteScalar()
                End Using
            End Using
        Catch ex As Exception
            Return Nothing
        End Try
    End Function

    Public Function FillDataTable(sql As String, ParamArray params() As OleDbParameter) As DataTable
        Dim dt As New DataTable()
        Try
            Using localConn As New OleDbConnection(connString)
                localConn.Open()
                Using cmd As New OleDbCommand(sql, localConn)
                    If params IsNot Nothing Then
                        cmd.Parameters.AddRange(params)
                    End If
                    Using adapter As New OleDbDataAdapter(cmd)
                        adapter.Fill(dt)
                    End Using
                End Using
            End Using
        Catch ex As Exception
            MsgBox($"Query error:{Environment.NewLine}{ex.Message}", MsgBoxStyle.Critical)
        End Try
        Return dt
    End Function

    Public Sub InitializeDatabase()
        If Not File.Exists("C:\Client\rental.accdb") Then
            MsgBox("Database file not found at C:\Client\rental.accdb." & vbCrLf & "Please ensure the database is set up correctly.", MsgBoxStyle.Exclamation)
        End If
    End Sub

End Module