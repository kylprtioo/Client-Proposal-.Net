﻿Imports System.Data.OleDb

Public Class frmBilling
    Dim selectedTenantID As Integer = 0
    Dim baseRent As Decimal = 0
    Dim prevMeralco As Double = 0

    Private Sub frmBilling_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        LoadTenantsToCombo()
    End Sub

    Private Sub frmBilling_FormClosed(sender As Object, e As FormClosedEventArgs) Handles MyBase.FormClosed
        ClearBillingForm()
    End Sub

    Private Sub LoadTenantsToCombo()
        cmbTenant.Items.Clear()
        Using myConn As New OleDbConnection(connString)
            Try
                myConn.Open()
                Dim cmd As New OleDbCommand("SELECT FullName FROM tblTenants WHERE Status = 'Active'", myConn)
                Dim reader = cmd.ExecuteReader()
                While reader.Read()
                    cmbTenant.Items.Add(reader("FullName").ToString())
                End While
            Catch ex As Exception
                MsgBox("Error loading tenants: " & ex.Message)
            End Try
        End Using
    End Sub


    Private Sub cmbTenant_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbTenant.SelectedIndexChanged
        Using myConn As New OleDbConnection(connString)
            Try
                myConn.Open()
                Dim sql As String = "SELECT TenantID, BaseRent, MeralcoReading, ContactNo FROM tblTenants WHERE FullName = @name"
                Dim cmd As New OleDbCommand(sql, myConn)
                cmd.Parameters.AddWithValue("@name", cmbTenant.Text)

                Dim reader = cmd.ExecuteReader()
                If reader.Read() Then
                    selectedTenantID = CInt(reader("TenantID"))
                    baseRent = CDec(reader("BaseRent"))
                    prevMeralco = CDbl(IIf(IsDBNull(reader("MeralcoReading")), 0, reader("MeralcoReading")))

                    lblBaseRent.Text = baseRent.ToString("N2")
                    lblPrevReading.Text = prevMeralco.ToString()
                    lblContact.Text = reader("ContactNo").ToString()
                End If
            Catch ex As Exception
                MsgBox("Error fetching tenant data: " & ex.Message)
            End Try
        End Using
    End Sub

    Private Sub btnCompute_Click(sender As Object, e As EventArgs) Handles btnCompute.Click
        Try
            If txtCurrentReading.Text = "" Then
                MsgBox("Pakilagay ang Current Meralco Reading.")
                Exit Sub
            End If

            Dim currReading As Double = CDbl(txtCurrentReading.Text)
            Dim rate As Decimal = 15.0

            If currReading < prevMeralco Then
                MsgBox("Mali: Ang current reading ay mas mababa sa previous!", MsgBoxStyle.Critical)
                Exit Sub
            End If

            Dim consumption = currReading - prevMeralco
            Dim meralcoTotal = consumption * rate
            Dim grandTotal = baseRent + meralcoTotal

            lblTotal.Text = grandTotal.ToString("N2")
        Catch ex As Exception
            MsgBox("Input valid numbers for reading.")
        End Try
    End Sub


    Private Sub ClearBillingForm()
        cmbTenant.SelectedIndex = -1
        lblBaseRent.Text = "0.00"
        lblPrevReading.Text = "0"
        lblContact.Text = "."
        lblTotal.Text = "0.00"
        txtCurrentReading.Clear()
        selectedTenantID = 0
        baseRent = 0
        prevMeralco = 0
    End Sub


    Private Sub btnSaveBill_Click(sender As Object, e As EventArgs) Handles btnSaveBill.Click
        If selectedTenantID = 0 Or lblTotal.Text = "0.00" Then
            MsgBox("Paki-compute muna ang bill bago i-save.", MsgBoxStyle.Exclamation)
            Exit Sub
        End If

        Using myConn As New OleDbConnection(connString)
            Try
                myConn.Open()
                Dim trans = myConn.BeginTransaction()

                Dim sqlBill As String = "INSERT INTO tblBillings ([ContractID], [BillingMonth], [MeralcoReading], [TotalAmount], [IsPaid]) " &
                                        "VALUES (@tid, @bmonth, @mread, @total, 'No')"

                Dim cmdBill As New OleDbCommand(sqlBill, myConn, trans)
                cmdBill.Parameters.AddWithValue("@tid", selectedTenantID)
                cmdBill.Parameters.AddWithValue("@bmonth", dtpBillingMonth.Value.ToShortDateString())
                cmdBill.Parameters.AddWithValue("@mread", CDbl(txtCurrentReading.Text))
                cmdBill.Parameters.AddWithValue("@total", CDec(lblTotal.Text))
                cmdBill.ExecuteNonQuery()

                Dim sqlUpdateTenant As String = "UPDATE tblTenants SET [MeralcoReading] = @newRead WHERE [TenantID] = @tid"
                Dim cmdUpdate As New OleDbCommand(sqlUpdateTenant, myConn, trans)
                cmdUpdate.Parameters.AddWithValue("@newRead", CDbl(txtCurrentReading.Text))
                cmdUpdate.Parameters.AddWithValue("@tid", selectedTenantID)
                cmdUpdate.ExecuteNonQuery()

                trans.Commit()
                MsgBox("Bill successfully generated and saved!", MsgBoxStyle.Information)

                ClearBillingForm()
                LoadTenantsToCombo()

            Catch ex As Exception
                MsgBox("Save Error: " & ex.Message)
            End Try
        End Using
    End Sub
End Class