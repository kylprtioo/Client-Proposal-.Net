﻿Imports System.Data.OleDb

Public Class frmBilling
    Public selectedTenantID As Integer = 0
    Public targetRoom As String = ""

    Private Sub frmBilling_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim currDate As DateTime = DateTime.Today
        Dim lastDay As Integer = DateTime.DaysInMonth(currDate.Year, currDate.Month)
        dtpBillingMonth.Value = New DateTime(currDate.Year, currDate.Month, lastDay)
        dtpBillingMonth.Enabled = False

        LoadTenantsToCombo()

        If targetRoom <> "" Then
            Using myConn As New OleDbConnection(ConnectionString)
                Try
                    myConn.Open()
                    Dim sql As String = "SELECT t.FullName FROM tblTenants t INNER JOIN tblRooms r ON t.RoomID = r.RoomID WHERE r.RoomNumber = @rnum AND t.Status = 'Active'"
                    Dim cmd As New OleDbCommand(sql, myConn)
                    cmd.Parameters.AddWithValue("@rnum", targetRoom)
                    Dim tName = cmd.ExecuteScalar()

                    If tName IsNot Nothing Then
                        cmbTenant.Text = tName.ToString()
                    End If
                Catch ex As Exception
                End Try
            End Using
        End If
    End Sub

    Private Sub frmBilling_FormClosed(sender As Object, e As FormClosedEventArgs) Handles MyBase.FormClosed
        ClearBillingForm()
    End Sub

    Private Sub LoadTenantsToCombo()
        cmbTenant.Items.Clear()
        Using myConn As New OleDbConnection(ConnectionString)
            Try
                myConn.Open()
                Dim cmd As New OleDbCommand("SELECT FullName FROM tblTenants WHERE Status = 'Active'", myConn)
                Dim reader = cmd.ExecuteReader()
                While reader.Read()
                    cmbTenant.Items.Add(reader("FullName").ToString())
                End While
            Catch ex As Exception
            End Try
        End Using
    End Sub

    Private Sub cmbTenant_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbTenant.SelectedIndexChanged
        Using myConn As New OleDbConnection(ConnectionString)
            Try
                myConn.Open()
                Dim sql As String = "SELECT TenantID, BaseRent, ContactNo FROM tblTenants WHERE FullName = @name"
                Dim cmd As New OleDbCommand(sql, myConn)
                cmd.Parameters.AddWithValue("@name", cmbTenant.Text)

                Dim reader = cmd.ExecuteReader()
                If reader.Read() Then
                    selectedTenantID = CInt(reader("TenantID"))
                    txtBaseRent.Text = CDec(reader("BaseRent")).ToString("0.00")
                    txtAdditionalFees.Text = "0.00"
                    lblContact.Text = reader("ContactNo").ToString()
                    lblTotal.Text = "0.00"
                End If
            Catch ex As Exception
            End Try
        End Using
    End Sub

    Private Sub btnCompute_Click(sender As Object, e As EventArgs) Handles btnCompute.Click
        Try
            Dim rent As Decimal = If(txtBaseRent.Text = "", 0, CDec(txtBaseRent.Text))
            Dim fees As Decimal = If(txtAdditionalFees.Text = "", 0, CDec(txtAdditionalFees.Text))

            Dim grandTotal = rent + fees
            lblTotal.Text = grandTotal.ToString("N2")
        Catch ex As Exception
            MsgBox("Please enter valid numbers for Base Rent and Additional Fees.")
        End Try
    End Sub

    Private Sub btnSaveBill_Click(sender As Object, e As EventArgs) Handles btnSaveBill.Click
        If selectedTenantID = 0 Or lblTotal.Text = "0.00" Then
            MsgBox("Paki-compute muna ang bill bago i-save.", MsgBoxStyle.Exclamation)
            Exit Sub
        End If

        Using myConn As New OleDbConnection(ConnectionString)
            Try
                myConn.Open()
                Dim trans = myConn.BeginTransaction()

                Dim sqlBill As String = "INSERT INTO tblBillings ([TenantID], [BillingMonth], [MeralcoReading], [TotalAmount], [IsPaid]) " &
                                        "VALUES (@tid, @bmonth, 0, @total, 'No')"

                Dim cmdBill As New OleDbCommand(sqlBill, myConn, trans)
                cmdBill.Parameters.AddWithValue("@tid", selectedTenantID)
                cmdBill.Parameters.AddWithValue("@bmonth", dtpBillingMonth.Value.ToShortDateString())
                cmdBill.Parameters.AddWithValue("@total", CDec(lblTotal.Text))
                cmdBill.ExecuteNonQuery()

                Dim sqlUpdateTenant As String = "UPDATE tblTenants SET [BaseRent] = @rent WHERE [TenantID] = @tid"
                Dim cmdUpdate As New OleDbCommand(sqlUpdateTenant, myConn, trans)
                cmdUpdate.Parameters.AddWithValue("@rent", CDec(txtBaseRent.Text))
                cmdUpdate.Parameters.AddWithValue("@tid", selectedTenantID)
                cmdUpdate.ExecuteNonQuery()

                trans.Commit()
                MsgBox("Bill successfully generated and saved!", MsgBoxStyle.Information)

                ClearBillingForm()
            Catch ex As Exception
                MsgBox("Save Error: " & ex.Message)
            End Try
        End Using
    End Sub

    Private Sub ClearBillingForm()
        cmbTenant.SelectedIndex = -1
        lblContact.Text = "-"
        txtBaseRent.Clear()
        txtAdditionalFees.Clear()
        lblTotal.Text = "0.00"
        selectedTenantID = 0

        Dim currDate As DateTime = Today
        Dim lastDay As Integer = DateTime.DaysInMonth(currDate.Year, currDate.Month)
        dtpBillingMonth.Value = New DateTime(currDate.Year, currDate.Month, lastDay)
    End Sub
End Class