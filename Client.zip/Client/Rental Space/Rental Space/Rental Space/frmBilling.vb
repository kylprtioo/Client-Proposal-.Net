﻿Imports System.Data.OleDb

Public Class frmBilling
    Public selectedTenantID As Integer = 0
    Public targetRoom As String = ""

    Private Sub frmBilling_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim currDate As DateTime = DateTime.Today
        Dim lastDay As Integer = DateTime.DaysInMonth(currDate.Year, currDate.Month)
        dtpBillingMonth.Value = New DateTime(currDate.Year, currDate.Month, lastDay)
        dtpBillingMonth.Enabled = False

        txtBaseRent.ReadOnly = True
        txtBaseRent.BackColor = Color.WhiteSmoke

        LoadTenantsToCombo()

        If targetRoom <> "" Then
            Using myConn As New OleDbConnection(ConnectionString)
                Try
                    myConn.Open()
                    Dim sql As String = "SELECT t.FullName FROM tblTenants t INNER JOIN tblRooms r ON t.RoomID = r.RoomID WHERE r.RoomNumber = @rnum AND t.Status = 'Active'"
                    Dim cmd As New OleDbCommand(sql, myConn)
                    cmd.Parameters.AddWithValue("@rnum", targetRoom)
                    Dim tName = cmd.ExecuteScalar()

                    If tName IsNot Nothing Then
                        cmbTenant.Text = tName.ToString()
                    End If
                Catch ex As Exception
                End Try
            End Using
        End If
    End Sub

    Private Sub frmBilling_FormClosed(sender As Object, e As FormClosedEventArgs) Handles MyBase.FormClosed
        ClearBillingForm()
    End Sub

    Private Sub LoadTenantsToCombo()
        cmbTenant.Items.Clear()
        Using myConn As New OleDbConnection(ConnectionString)
            Try
                myConn.Open()
                Dim cmd As New OleDbCommand("SELECT FullName FROM tblTenants WHERE Status = 'Active'", myConn)
                Dim reader = cmd.ExecuteReader()
                While reader.Read()
                    cmbTenant.Items.Add(reader("FullName").ToString())
                End While
            Catch ex As Exception
            End Try
        End Using
    End Sub

    Private Sub cmbTenant_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbTenant.SelectedIndexChanged
        Using myConn As New OleDbConnection(ConnectionString)
            Try
                myConn.Open()
                Dim sql As String = "SELECT TenantID, BaseRent, ContactNo FROM tblTenants WHERE FullName = @name"
                Dim cmd As New OleDbCommand(sql, myConn)
                cmd.Parameters.AddWithValue("@name", cmbTenant.Text)

                Dim baseRent As Decimal = 0
                Dim reader = cmd.ExecuteReader()
                If reader.Read() Then
                    selectedTenantID = CInt(reader("TenantID"))
                    baseRent = CDec(reader("BaseRent"))
                    lblContact.Text = reader("ContactNo").ToString()
                End If
                reader.Close()

                If selectedTenantID > 0 Then
                    Dim firstDay As New DateTime(dtpBillingMonth.Value.Year, dtpBillingMonth.Value.Month, 1)
                    Dim lastDay As New DateTime(dtpBillingMonth.Value.Year, dtpBillingMonth.Value.Month, DateTime.DaysInMonth(dtpBillingMonth.Value.Year, dtpBillingMonth.Value.Month))

                    Dim hasCurrentBill As Boolean = False
                    Dim sqlCheck As String = "SELECT COUNT(*) FROM tblBillings WHERE TenantID = @tid AND BillingMonth BETWEEN @start AND @end"
                    Dim cmdCheck As New OleDbCommand(sqlCheck, myConn)
                    cmdCheck.Parameters.AddWithValue("@tid", selectedTenantID)
                    cmdCheck.Parameters.AddWithValue("@start", firstDay)
                    cmdCheck.Parameters.AddWithValue("@end", lastDay)
                    If Convert.ToInt32(cmdCheck.ExecuteScalar()) > 0 Then hasCurrentBill = True

                    Dim totalUnpaid As Decimal = 0
                    Dim sqlSum As String = "SELECT SUM([Balance]) FROM tblBillings WHERE TenantID = @tid AND ([IsPaid] = 'No' OR [IsPaid] = 'Partial')"
                    Dim cmdSum As New OleDbCommand(sqlSum, myConn)
                    cmdSum.Parameters.AddWithValue("@tid", selectedTenantID)
                    Dim sumObj = cmdSum.ExecuteScalar()
                    If sumObj IsNot Nothing AndAlso Not IsDBNull(sumObj) Then
                        totalUnpaid = Convert.ToDecimal(sumObj)
                    End If

                    If hasCurrentBill Then
                        txtBaseRent.Text = totalUnpaid.ToString("0.00")
                        LabelBaseRent.Text = If(totalUnpaid > 0, "Remaining Balance:", "Cleared (0 Bal):")
                    Else
                        Dim startingAmt As Decimal = baseRent + totalUnpaid
                        txtBaseRent.Text = startingAmt.ToString("0.00")
                        LabelBaseRent.Text = If(totalUnpaid > 0, "Rent + Past Due:", "Base Rent:")
                    End If

                    txtAdditionalFees.Text = "0.00"
                    txtRemarks.Clear()
                    lblTotal.Text = "0.00"
                End If
            Catch ex As Exception
            End Try
        End Using
    End Sub

    Private Sub btnCompute_Click(sender As Object, e As EventArgs) Handles btnCompute.Click
        Try
            Dim rent As Decimal = If(txtBaseRent.Text = "", 0, CDec(txtBaseRent.Text))
            Dim fees As Decimal = If(txtAdditionalFees.Text = "", 0, CDec(txtAdditionalFees.Text))

            If fees > 0 AndAlso String.IsNullOrWhiteSpace(txtRemarks.Text) Then
                MsgBox("Paki-lagay sa Remarks ang dahilan ng Additional Fee (ex. Nasirang gamit).", MsgBoxStyle.Exclamation)
                txtRemarks.Focus()
                Exit Sub
            End If

            Dim grandTotal = rent + fees
            lblTotal.Text = grandTotal.ToString("N2")
        Catch ex As Exception
            MsgBox("Please enter valid numbers for Base Rent and Additional Fees.", MsgBoxStyle.Exclamation)
        End Try
    End Sub

    Private Sub btnSaveBill_Click(sender As Object, e As EventArgs) Handles btnSaveBill.Click
        If selectedTenantID = 0 Or lblTotal.Text = "0.00" Then
            MsgBox("Paki-compute muna ang bill bago i-save.", MsgBoxStyle.Exclamation)
            Exit Sub
        End If

        Dim fees As Decimal = If(txtAdditionalFees.Text = "", 0, CDec(txtAdditionalFees.Text))
        If fees > 0 AndAlso String.IsNullOrWhiteSpace(txtRemarks.Text) Then
            MsgBox("Kailangan ng Remarks para sa Additional Fee bago i-save ang bill.", MsgBoxStyle.Exclamation)
            txtRemarks.Focus()
            Exit Sub
        End If

        Using myConn As New OleDbConnection(ConnectionString)
            Try
                myConn.Open()
                Dim trans = myConn.BeginTransaction()

                Dim firstDayOfMonth As New DateTime(dtpBillingMonth.Value.Year, dtpBillingMonth.Value.Month, 1)
                Dim lastDayOfMonth As New DateTime(dtpBillingMonth.Value.Year, dtpBillingMonth.Value.Month, DateTime.DaysInMonth(dtpBillingMonth.Value.Year, dtpBillingMonth.Value.Month))

                Dim chkSql As String = "SELECT BillID, TotalAmount, Balance, Remarks FROM tblBillings WHERE TenantID = @tid AND BillingMonth BETWEEN @start AND @end"
                Dim chkCmd As New OleDbCommand(chkSql, myConn, trans)
                chkCmd.Parameters.AddWithValue("@tid", selectedTenantID)
                chkCmd.Parameters.AddWithValue("@start", firstDayOfMonth)
                chkCmd.Parameters.AddWithValue("@end", lastDayOfMonth)

                Dim reader = chkCmd.ExecuteReader()
                Dim existingBillID As Integer = 0
                Dim currentTotal As Decimal = 0
                Dim currentBal As Decimal = 0
                Dim currentRem As String = ""

                If reader.Read() Then
                    existingBillID = CInt(reader("BillID"))
                    currentTotal = CDec(reader("TotalAmount"))
                    currentBal = CDec(reader("Balance"))
                    currentRem = If(IsDBNull(reader("Remarks")), "", reader("Remarks").ToString())
                End If
                reader.Close()

                If existingBillID > 0 Then
                    If fees = 0 Then
                        trans.Rollback()
                        MsgBox("Walang naidagdag na fees. Walang pagbabago sa bill.", MsgBoxStyle.Information)
                        Exit Sub
                    End If

                    Dim newTotal As Decimal = currentTotal + fees
                    Dim newBal As Decimal = currentBal + fees

                    Dim newRem As String = currentRem
                    If String.IsNullOrWhiteSpace(newRem) Then
                        newRem = txtRemarks.Text.Trim()
                    Else
                        newRem &= " | " & txtRemarks.Text.Trim()
                    End If

                    Dim newStatus As String = "No"
                    If newBal <= 0 Then
                        newStatus = "Yes"
                    ElseIf newBal < newTotal Then
                        newStatus = "Partial"
                    End If

                    Dim sqlUpdateBill As String = "UPDATE tblBillings SET TotalAmount = @total, Balance = @bal, Remarks = @rem, IsPaid = @stat WHERE BillID = @bid"
                    Dim cmdUpdateBill As New OleDbCommand(sqlUpdateBill, myConn, trans)
                    cmdUpdateBill.Parameters.AddWithValue("@total", newTotal)
                    cmdUpdateBill.Parameters.AddWithValue("@bal", newBal)
                    cmdUpdateBill.Parameters.AddWithValue("@rem", newRem)
                    cmdUpdateBill.Parameters.AddWithValue("@stat", newStatus)
                    cmdUpdateBill.Parameters.AddWithValue("@bid", existingBillID)
                    cmdUpdateBill.ExecuteNonQuery()

                    MsgBox($"Naidagdag ang ₱{fees.ToString("N2")} na additional fee sa existing bill.", MsgBoxStyle.Information, "Bill Updated")
                Else
                    Dim sqlInsertBill As String = "INSERT INTO tblBillings ([TenantID], [BillingMonth], [MeralcoReading], [TotalAmount], [Balance], [IsPaid], [Remarks]) " &
                                                  "VALUES (@tid, @bmonth, 0, @total, @bal, 'No', @rem)"
                    Dim cmdInsertBill As New OleDbCommand(sqlInsertBill, myConn, trans)
                    cmdInsertBill.Parameters.AddWithValue("@tid", selectedTenantID)
                    cmdInsertBill.Parameters.AddWithValue("@bmonth", dtpBillingMonth.Value.ToShortDateString())
                    cmdInsertBill.Parameters.AddWithValue("@total", CDec(lblTotal.Text))
                    cmdInsertBill.Parameters.AddWithValue("@bal", CDec(lblTotal.Text))
                    cmdInsertBill.Parameters.AddWithValue("@rem", txtRemarks.Text.Trim())
                    cmdInsertBill.ExecuteNonQuery()

                    MsgBox("Bagong bill ay nai-save na!", MsgBoxStyle.Information, "Bill Saved")
                End If

                trans.Commit()
                ClearBillingForm()

            Catch ex As Exception
                MsgBox("Save Error: " & ex.Message, MsgBoxStyle.Critical)
            End Try
        End Using
    End Sub

    Private Sub ClearBillingForm()
        cmbTenant.SelectedIndex = -1
        lblContact.Text = "-"
        txtBaseRent.Clear()
        txtAdditionalFees.Clear()
        txtRemarks.Clear()
        lblTotal.Text = "0.00"
        selectedTenantID = 0
        LabelBaseRent.Text = "Base Rent:"

        Dim currDate As DateTime = Today
        Dim lastDay As Integer = DateTime.DaysInMonth(currDate.Year, currDate.Month)
        dtpBillingMonth.Value = New DateTime(currDate.Year, currDate.Month, lastDay)
    End Sub
End Class