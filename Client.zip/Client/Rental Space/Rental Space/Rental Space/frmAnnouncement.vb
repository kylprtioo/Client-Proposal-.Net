﻿Imports System.Data.OleDb
Imports System.Net.Mail
Imports System.Net
Imports System.Drawing

Public Class frmAnnouncement
    Private selectedAnnouncementID As Integer = 0

    Private Sub frmAnnouncement_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ResetForm()
        LoadAnnouncements()
    End Sub

    Private Sub frmAnnouncement_FormClosing(sender As Object, e As FormClosingEventArgs) Handles MyBase.FormClosing
        e.Cancel = True
        Me.Hide()
    End Sub

    Private Sub ResetForm()
        txtTitle.Clear()
        txtMessage.Clear()
        chkSendEmail.Checked = False
        selectedAnnouncementID = 0

        btnPost.Text = "POST ANNOUNCEMENT"
        btnPost.BackColor = Color.FromArgb(31, 97, 141)

        lblTitle.Text = "CREATE ANNOUNCEMENT"
    End Sub

    Private Sub btnPost_Click(sender As Object, e As EventArgs) Handles btnPost.Click
        If txtTitle.Text.Trim() = "" Or txtMessage.Text.Trim() = "" Then
            MsgBox("Please enter both the title and the message.", MsgBoxStyle.Exclamation)
            Exit Sub
        End If

        Using myConn As New OleDbConnection(ConnectionString)
            Try
                myConn.Open()
                Dim sql As String = ""
                Dim cmd As New OleDbCommand()

                If selectedAnnouncementID = 0 Then

                    sql = "INSERT INTO tblAnnouncements (Title, Message, DatePosted, PostedBy) VALUES (@title, @msg, @dpost, @author)"
                    cmd = New OleDbCommand(sql, myConn)
                    cmd.Parameters.AddWithValue("@title", txtTitle.Text.Trim())
                    cmd.Parameters.AddWithValue("@msg", txtMessage.Text.Trim())
                    cmd.Parameters.Add("@dpost", OleDbType.Date).Value = DateTime.Now
                    cmd.Parameters.AddWithValue("@author", currentUsername)
                Else

                    Dim ans = MsgBox("Are you sure you want to update this announcement?", MsgBoxStyle.YesNo + MsgBoxStyle.Question, "Update Confirmation")
                    If ans = MsgBoxResult.No Then Exit Sub

                    sql = "UPDATE tblAnnouncements SET Title = @title, Message = @msg WHERE AnnouncementID = @id"
                    cmd = New OleDbCommand(sql, myConn)
                    cmd.Parameters.AddWithValue("@title", txtTitle.Text.Trim())
                    cmd.Parameters.AddWithValue("@msg", txtMessage.Text.Trim())
                    cmd.Parameters.AddWithValue("@id", selectedAnnouncementID)
                End If

                cmd.ExecuteNonQuery()

                If chkSendEmail.Checked Then
                    Me.Cursor = Cursors.WaitCursor
                    Dim emailSubject As String = txtTitle.Text.Trim()

                    If selectedAnnouncementID > 0 AndAlso Not emailSubject.ToUpper().StartsWith("CORRECTION:") Then
                        emailSubject = "CORRECTION: " & emailSubject
                    End If

                    SendEmailToTenants(emailSubject, txtMessage.Text.Trim())
                    Me.Cursor = Cursors.Default
                End If

                If selectedAnnouncementID = 0 Then
                    MsgBox("Announcement posted successfully!", MsgBoxStyle.Information)
                Else
                    MsgBox("Announcement updated successfully!", MsgBoxStyle.Information)
                End If

                ResetForm()
                LoadAnnouncements()

            Catch ex As Exception
                Me.Cursor = Cursors.Default
                MsgBox("Error processing announcement: " & ex.Message, MsgBoxStyle.Critical)
            End Try
        End Using
    End Sub

    Private Sub LoadAnnouncements()
        Using myConn As New OleDbConnection(ConnectionString)
            Try
                myConn.Open()

                Dim sql As String = "SELECT AnnouncementID, Title, Message, PostedBy, DatePosted FROM tblAnnouncements ORDER BY AnnouncementID DESC"
                Dim cmd As New OleDbCommand(sql, myConn)
                Dim adapter As New OleDbDataAdapter(cmd)
                Dim dt As New DataTable()
                adapter.Fill(dt)
                dgvAnnouncements.DataSource = dt

                If dgvAnnouncements.Columns.Count > 0 Then
                    dgvAnnouncements.Columns("AnnouncementID").Visible = False
                    dgvAnnouncements.Columns("DatePosted").DefaultCellStyle.Format = "MM/dd/yyyy hh:mm tt"

                    dgvAnnouncements.Columns("DatePosted").AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells
                    dgvAnnouncements.Columns("PostedBy").AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells
                    dgvAnnouncements.Columns("Title").AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells
                    dgvAnnouncements.Columns("Message").AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill
                End If
            Catch ex As Exception
                MsgBox("Query error: " & ex.Message)
            End Try
        End Using
    End Sub

    Private Sub SendEmailToTenants(subject As String, bodyMessage As String)
        Using myConn As New OleDbConnection(ConnectionString)
            Try
                myConn.Open()
                Dim sql As String = "SELECT FullName, EmailAddress FROM tblTenants WHERE Status='Active' AND EmailAddress IS NOT NULL"
                Dim cmd As New OleDbCommand(sql, myConn)
                Dim adapter As New OleDbDataAdapter(cmd)
                Dim dtEmails As New DataTable()
                adapter.Fill(dtEmails)

                If dtEmails.Rows.Count = 0 Then
                    MsgBox("Announcement saved, but no active tenants with email addresses found.", MsgBoxStyle.Information)
                    Exit Sub
                End If

                Dim adminEmail As String = "carlodowork@gmail.com"
                Dim appPassword As String = "xlko nqnb yhkl tbnv"

                Dim smtp As New SmtpClient("smtp.gmail.com")
                smtp.Port = 587
                smtp.EnableSsl = True
                smtp.Credentials = New NetworkCredential(adminEmail, appPassword)

                Dim sentCount As Integer = 0

                For Each row As DataRow In dtEmails.Rows
                    Dim tenantEmail As String = row("EmailAddress").ToString().Trim()
                    Dim tenantName As String = row("FullName").ToString()

                    If tenantEmail.Contains("@") AndAlso tenantEmail.Contains(".") Then
                        Dim mail As New MailMessage()
                        mail.From = New MailAddress(adminEmail, "Cristina's Place Management")
                        mail.To.Add(tenantEmail)
                        mail.Subject = subject

                        mail.Body = $"Hello {tenantName}," & vbCrLf & vbCrLf &
                                    bodyMessage & vbCrLf & vbCrLf &
                                    "Best regards," & vbCrLf &
                                    "Cristina's Place Management"

                        smtp.Send(mail)
                        sentCount += 1
                    End If
                Next

                MsgBox($"Successfully sent emails to {sentCount} tenant(s)!", MsgBoxStyle.Information)

            Catch ex As Exception
                MsgBox("Failed to send emails. Error: " & ex.Message, MsgBoxStyle.Critical)
            End Try
        End Using
    End Sub

    Private Sub dgvAnnouncements_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgvAnnouncements.CellClick
        If e.RowIndex >= 0 Then
            Dim row As DataGridViewRow = dgvAnnouncements.Rows(e.RowIndex)

            selectedAnnouncementID = CInt(row.Cells("AnnouncementID").Value)
            txtTitle.Text = row.Cells("Title").Value.ToString()
            txtMessage.Text = row.Cells("Message").Value.ToString()
            chkSendEmail.Checked = False

            lblTitle.Text = "EDIT ANNOUNCEMENT"
            btnPost.Text = "UPDATE ANNOUNCEMENT"
            btnPost.BackColor = Color.SeaGreen
        End If
    End Sub


    Private Sub dgvAnnouncements_CellDoubleClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgvAnnouncements.CellDoubleClick
        If e.RowIndex >= 0 Then
            Dim row As DataGridViewRow = dgvAnnouncements.Rows(e.RowIndex)

            Dim title As String = row.Cells("Title").Value.ToString()
            Dim message As String = row.Cells("Message").Value.ToString()
            Dim postedBy As String = row.Cells("PostedBy").Value.ToString()

            Dim datePosted As String = ""
            If Not IsDBNull(row.Cells("DatePosted").Value) Then
                datePosted = Convert.ToDateTime(row.Cells("DatePosted").Value).ToString("MMMM dd, yyyy hh:mm tt")
            End If

            Dim viewForm As New Form()
            viewForm.Text = "Announcement Details"
            viewForm.Size = New Size(500, 450)
            viewForm.StartPosition = FormStartPosition.CenterParent
            viewForm.FormBorderStyle = FormBorderStyle.FixedDialog
            viewForm.MaximizeBox = False
            viewForm.MinimizeBox = False
            viewForm.BackColor = Color.FromArgb(245, 247, 250)

            Dim lblTitle As New Label()
            lblTitle.Text = title
            lblTitle.Font = New Font("Segoe UI", 16, FontStyle.Bold)
            lblTitle.ForeColor = Color.FromArgb(44, 62, 80)
            lblTitle.Location = New Point(20, 20)
            lblTitle.AutoSize = True
            lblTitle.MaximumSize = New Size(440, 0)
            viewForm.Controls.Add(lblTitle)
            viewForm.PerformLayout()

            Dim lblInfo As New Label()
            lblInfo.Text = $"Posted by {postedBy} on {datePosted}"
            lblInfo.Font = New Font("Segoe UI", 9.5F, FontStyle.Italic)
            lblInfo.ForeColor = Color.Gray
            lblInfo.Location = New Point(20, lblTitle.Bottom + 5)
            lblInfo.AutoSize = True
            viewForm.Controls.Add(lblInfo)
            viewForm.PerformLayout()

            Dim txtMsg As New TextBox()
            txtMsg.Text = message
            txtMsg.Multiline = True
            txtMsg.ReadOnly = True
            txtMsg.ScrollBars = ScrollBars.Vertical
            txtMsg.Font = New Font("Segoe UI", 11)
            txtMsg.Location = New Point(20, lblInfo.Bottom + 15)
            txtMsg.Size = New Size(440, 240)
            txtMsg.BackColor = Color.White
            txtMsg.BorderStyle = BorderStyle.FixedSingle
            viewForm.Controls.Add(txtMsg)

            Dim btnDelete As New Button()
            btnDelete.Text = "Delete"
            btnDelete.Size = New Size(100, 40)
            btnDelete.Location = New Point(20, txtMsg.Bottom + 15)
            btnDelete.BackColor = Color.IndianRed
            btnDelete.ForeColor = Color.White
            btnDelete.Font = New Font("Segoe UI", 10, FontStyle.Bold)
            btnDelete.FlatStyle = FlatStyle.Flat
            btnDelete.Cursor = Cursors.Hand

            Dim selectedID As Integer = CInt(row.Cells("AnnouncementID").Value)
            AddHandler btnDelete.Click, Sub()
                                            Dim ans = MsgBox("Are you sure you want to permanently delete this announcement?", MsgBoxStyle.YesNo + MsgBoxStyle.Exclamation, "Delete Announcement")
                                            If ans = MsgBoxResult.Yes Then
                                                DeleteAnnouncement(selectedID)
                                                viewForm.Close()
                                            End If
                                        End Sub
            viewForm.Controls.Add(btnDelete)

            Dim btnClose As New Button()
            btnClose.Text = "Close"
            btnClose.Size = New Size(100, 40)
            btnClose.Location = New Point(360, txtMsg.Bottom + 15)
            btnClose.BackColor = Color.Gray
            btnClose.ForeColor = Color.White
            btnClose.Font = New Font("Segoe UI", 10, FontStyle.Bold)
            btnClose.FlatStyle = FlatStyle.Flat
            btnClose.Cursor = Cursors.Hand
            AddHandler btnClose.Click, Sub() viewForm.Close()
            viewForm.Controls.Add(btnClose)

            viewForm.Height = btnClose.Bottom + 60
            viewForm.ShowDialog()
        End If
    End Sub

    Private Sub DeleteAnnouncement(id As Integer)
        Using myConn As New OleDbConnection(ConnectionString)
            Try
                myConn.Open()
                Dim sql As String = "DELETE FROM tblAnnouncements WHERE AnnouncementID = @id"
                Dim cmd As New OleDbCommand(sql, myConn)
                cmd.Parameters.AddWithValue("@id", id)
                cmd.ExecuteNonQuery()

                MsgBox("Announcement deleted.", MsgBoxStyle.Information)
                ResetForm()
                LoadAnnouncements()
            Catch ex As Exception
                MsgBox("Error deleting announcement: " & ex.Message, MsgBoxStyle.Critical)
            End Try
        End Using
    End Sub

End Class