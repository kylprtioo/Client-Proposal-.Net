﻿Imports System.Data.OleDb
Imports System.Net.Mail

Public Class frmAnnouncement

    Private Sub frmAnnouncement_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        LoadAnnouncements()
    End Sub

    Private Sub frmAnnouncement_FormClosing(sender As Object, e As FormClosingEventArgs) Handles MyBase.FormClosing
        e.Cancel = True
        Me.Hide()
    End Sub

    Private Sub btnPost_Click(sender As Object, e As EventArgs) Handles btnPost.Click
        If txtTitle.Text.Trim() = "" Or txtMessage.Text.Trim() = "" Then
            MsgBox("Please enter both the title and the message.", MsgBoxStyle.Exclamation)
            Exit Sub
        End If

        Using myConn As New OleDbConnection(ConnectionString)
            Try
                myConn.Open()
                Dim sql As String = "INSERT INTO tblAnnouncements (Title, Message, DatePosted, PostedBy) VALUES (@title, @msg, @dpost, @author)"
                Dim cmd As New OleDbCommand(sql, myConn)

                cmd.Parameters.AddWithValue("@title", txtTitle.Text.Trim())
                cmd.Parameters.AddWithValue("@msg", txtMessage.Text.Trim())
                cmd.Parameters.Add("@dpost", OleDbType.Date).Value = DateTime.Now
                cmd.Parameters.AddWithValue("@author", currentUsername)

                cmd.ExecuteNonQuery()

                If chkSendEmail.Checked Then
                    Me.Cursor = Cursors.WaitCursor
                    SendEmailToTenants(txtTitle.Text.Trim(), txtMessage.Text.Trim())
                    Me.Cursor = Cursors.Default
                End If

                MsgBox("Announcement posted successfully!", MsgBoxStyle.Information)
                txtTitle.Clear()
                txtMessage.Clear()
                chkSendEmail.Checked = False
                LoadAnnouncements()

            Catch ex As Exception
                Me.Cursor = Cursors.Default
                MsgBox("Error posting announcement: " & ex.Message)
            End Try
        End Using
    End Sub

    Private Sub LoadAnnouncements()
        Using myConn As New OleDbConnection(ConnectionString)
            Try
                myConn.Open()
                Dim sql As String = "SELECT Title, Message, PostedBy, DatePosted FROM tblAnnouncements ORDER BY AnnouncementID DESC"
                Dim cmd As New OleDbCommand(sql, myConn)
                Dim adapter As New OleDbDataAdapter(cmd)
                Dim dt As New DataTable()
                adapter.Fill(dt)
                dgvAnnouncements.DataSource = dt

                If dgvAnnouncements.Columns.Count > 0 Then
                    dgvAnnouncements.Columns("DatePosted").DefaultCellStyle.Format = "MM/dd/yyyy hh:mm tt"

                    dgvAnnouncements.Columns("DatePosted").AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells
                    dgvAnnouncements.Columns("PostedBy").AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells
                    dgvAnnouncements.Columns("Title").AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells
                    dgvAnnouncements.Columns("Message").AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill
                End If
            Catch ex As Exception
                MsgBox("Query error: " & ex.Message)
            End Try
        End Using
    End Sub

    Private Sub SendEmailToTenants(subject As String, bodyMessage As String)
        Using myConn As New OleDbConnection(ConnectionString)
            Try
                myConn.Open()
                Dim sql As String = "SELECT FullName, EmailAddress FROM tblTenants WHERE Status='Active' AND EmailAddress IS NOT NULL"
                Dim cmd As New OleDbCommand(sql, myConn)
                Dim adapter As New OleDbDataAdapter(cmd)
                Dim dtEmails As New DataTable()
                adapter.Fill(dtEmails)

                If dtEmails.Rows.Count = 0 Then
                    MsgBox("Announcement saved, but no active tenants with email addresses found.")
                    Exit Sub
                End If

                Dim smtp As New SmtpClient("smtp.gmail.com")
                smtp.Port = 587
                smtp.EnableSsl = True

                Dim adminEmail As String = "iyong_email@gmail.com"
                Dim appPassword As String = "xxxx xxxx xxxx xxxx"
                smtp.Credentials = New System.Net.NetworkCredential(adminEmail, appPassword)

                Dim sentCount As Integer = 0

                For Each row As DataRow In dtEmails.Rows
                    Dim tenantEmail As String = row("EmailAddress").ToString().Trim()
                    Dim tenantName As String = row("FullName").ToString()

                    If tenantEmail.Contains("@") AndAlso tenantEmail.Contains(".") Then
                        Dim mail As New MailMessage()
                        mail.From = New MailAddress(adminEmail, "Cristina's Place Admin")
                        mail.To.Add(tenantEmail)
                        mail.Subject = subject

                        mail.Body = $"Hello {tenantName}," & vbCrLf & vbCrLf &
                                    bodyMessage & vbCrLf & vbCrLf &
                                    "Best regards," & vbCrLf &
                                    "Cristina's Place Management"

                        smtp.Send(mail)
                        sentCount += 1
                    End If
                Next

                MsgBox($"Successfully sent emails to {sentCount} tenant(s)!", MsgBoxStyle.Information)

            Catch ex As Exception
                MsgBox("Failed to send emails. Error: " & ex.Message, MsgBoxStyle.Critical)
            End Try
        End Using
    End Sub

    Private Sub dgvAnnouncements_CellDoubleClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgvAnnouncements.CellDoubleClick
        If e.RowIndex >= 0 Then
            Dim row As DataGridViewRow = dgvAnnouncements.Rows(e.RowIndex)

            Dim title As String = row.Cells("Title").Value.ToString()
            Dim message As String = row.Cells("Message").Value.ToString()
            Dim postedBy As String = row.Cells("PostedBy").Value.ToString()

            Dim datePosted As String = ""
            If Not IsDBNull(row.Cells("DatePosted").Value) Then
                datePosted = Convert.ToDateTime(row.Cells("DatePosted").Value).ToString("MMMM dd, yyyy hh:mm tt")
            End If

            Dim viewForm As New Form()
            viewForm.Text = "Announcement Details"
            viewForm.Size = New Size(500, 450)
            viewForm.StartPosition = FormStartPosition.CenterParent
            viewForm.FormBorderStyle = FormBorderStyle.FixedDialog
            viewForm.MaximizeBox = False
            viewForm.MinimizeBox = False
            viewForm.BackColor = Color.FromArgb(245, 247, 250)

            Dim lblTitle As New Label()
            lblTitle.Text = title
            lblTitle.Font = New Font("Segoe UI", 16, FontStyle.Bold)
            lblTitle.ForeColor = Color.FromArgb(44, 62, 80)
            lblTitle.Location = New Point(20, 20)
            lblTitle.AutoSize = True
            lblTitle.MaximumSize = New Size(440, 0)

            Dim lblInfo As New Label()
            lblInfo.Text = $"Posted by {postedBy} on {datePosted}"
            lblInfo.Font = New Font("Segoe UI", 9.5F, FontStyle.Italic)
            lblInfo.ForeColor = Color.Gray
            lblInfo.Location = New Point(20, lblTitle.Bottom + 5)
            lblInfo.AutoSize = True

            Dim txtMsg As New TextBox()
            txtMsg.Text = message
            txtMsg.Multiline = True
            txtMsg.ReadOnly = True
            txtMsg.ScrollBars = ScrollBars.Vertical
            txtMsg.Font = New Font("Segoe UI", 11)
            txtMsg.Location = New Point(20, lblInfo.Bottom + 15)
            txtMsg.Size = New Size(440, 240)
            txtMsg.BackColor = Color.White
            txtMsg.BorderStyle = BorderStyle.FixedSingle

            Dim btnClose As New Button()
            btnClose.Text = "Close"
            btnClose.Size = New Size(120, 40)
            btnClose.Location = New Point(180, txtMsg.Bottom + 15)
            btnClose.BackColor = Color.FromArgb(192, 57, 43)
            btnClose.ForeColor = Color.White
            btnClose.Font = New Font("Segoe UI", 10, FontStyle.Bold)
            btnClose.FlatStyle = FlatStyle.Flat
            btnClose.Cursor = Cursors.Hand
            AddHandler btnClose.Click, Sub() viewForm.Close()

            viewForm.Controls.Add(lblTitle)
            viewForm.Controls.Add(lblInfo)
            viewForm.Controls.Add(txtMsg)
            viewForm.Controls.Add(btnClose)

            viewForm.ShowDialog()
        End If
    End Sub

End Class