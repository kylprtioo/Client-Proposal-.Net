﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmRoomDetails
    Inherits System.Windows.Forms.Form

    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    Private components As System.ComponentModel.IContainer

    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.pnlDetails = New System.Windows.Forms.Panel()
        Me.lblSelectFloor = New System.Windows.Forms.Label()
        Me.cmbSelectFloor = New System.Windows.Forms.ComboBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.cmbCapacity = New System.Windows.Forms.ComboBox()
        Me.btnUpdatePrice = New System.Windows.Forms.Button()
        Me.txtEditRent = New System.Windows.Forms.TextBox()
        Me.cmbSelectRoom = New System.Windows.Forms.ComboBox()
        Me.lblSelectRoom = New System.Windows.Forms.Label()
        Me.lblSpecTitle = New System.Windows.Forms.Label()
        Me.lblDescTitle = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.lblOccupants = New System.Windows.Forms.Label()
        Me.lblRent = New System.Windows.Forms.Label()
        Me.lblFloor = New System.Windows.Forms.Label()
        Me.lblRoomNum = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lblDescContent = New System.Windows.Forms.Label()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlDetails.SuspendLayout()
        Me.SuspendLayout()
        '
        'PictureBox1
        '
        Me.PictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox1.Location = New System.Drawing.Point(25, 25)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(385, 300)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'PictureBox2
        '
        Me.PictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox2.Location = New System.Drawing.Point(425, 25)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(385, 300)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox2.TabIndex = 1
        Me.PictureBox2.TabStop = False
        '
        'pnlDetails
        '
        Me.pnlDetails.BackColor = System.Drawing.Color.White
        Me.pnlDetails.Controls.Add(Me.lblSelectFloor)
        Me.pnlDetails.Controls.Add(Me.cmbSelectFloor)
        Me.pnlDetails.Controls.Add(Me.Label3)
        Me.pnlDetails.Controls.Add(Me.cmbCapacity)
        Me.pnlDetails.Controls.Add(Me.btnUpdatePrice)
        Me.pnlDetails.Controls.Add(Me.txtEditRent)
        Me.pnlDetails.Controls.Add(Me.cmbSelectRoom)
        Me.pnlDetails.Controls.Add(Me.lblSelectRoom)
        Me.pnlDetails.Controls.Add(Me.lblSpecTitle)
        Me.pnlDetails.Controls.Add(Me.lblDescContent)
        Me.pnlDetails.Controls.Add(Me.lblDescTitle)
        Me.pnlDetails.Controls.Add(Me.Label4)
        Me.pnlDetails.Controls.Add(Me.Label2)
        Me.pnlDetails.Controls.Add(Me.lblOccupants)
        Me.pnlDetails.Controls.Add(Me.lblRent)
        Me.pnlDetails.Controls.Add(Me.lblFloor)
        Me.pnlDetails.Controls.Add(Me.lblRoomNum)
        Me.pnlDetails.Controls.Add(Me.Label1)
        Me.pnlDetails.Location = New System.Drawing.Point(25, 350)
        Me.pnlDetails.Name = "pnlDetails"
        Me.pnlDetails.Size = New System.Drawing.Size(785, 360)
        Me.pnlDetails.TabIndex = 2
        '
        'lblSelectFloor
        '
        Me.lblSelectFloor.AutoSize = True
        Me.lblSelectFloor.Font = New System.Drawing.Font("Segoe UI", 11.25!)
        Me.lblSelectFloor.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139)
        Me.lblSelectFloor.Location = New System.Drawing.Point(30, 63)
        Me.lblSelectFloor.Name = "lblSelectFloor"
        Me.lblSelectFloor.Size = New System.Drawing.Size(90, 20)
        Me.lblSelectFloor.TabIndex = 15
        Me.lblSelectFloor.Text = "Select Floor:"
        '
        'cmbSelectFloor
        '
        Me.cmbSelectFloor.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbSelectFloor.Font = New System.Drawing.Font("Segoe UI", 11.25!)
        Me.cmbSelectFloor.FormattingEnabled = True
        Me.cmbSelectFloor.Location = New System.Drawing.Point(150, 60)
        Me.cmbSelectFloor.Name = "cmbSelectFloor"
        Me.cmbSelectFloor.Size = New System.Drawing.Size(206, 28)
        Me.cmbSelectFloor.TabIndex = 16
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Segoe UI", 11.25!)
        Me.Label3.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139)
        Me.Label3.Location = New System.Drawing.Point(30, 103)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(69, 20)
        Me.Label3.TabIndex = 17
        Me.Label3.Text = "Capacity:"
        '
        'cmbCapacity
        '
        Me.cmbCapacity.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbCapacity.Font = New System.Drawing.Font("Segoe UI", 11.25!)
        Me.cmbCapacity.FormattingEnabled = True
        Me.cmbCapacity.Location = New System.Drawing.Point(150, 100)
        Me.cmbCapacity.Name = "cmbCapacity"
        Me.cmbCapacity.Size = New System.Drawing.Size(206, 28)
        Me.cmbCapacity.TabIndex = 18
        '
        'cmbSelectRoom
        '
        Me.cmbSelectRoom.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbSelectRoom.Font = New System.Drawing.Font("Segoe UI", 11.25!)
        Me.cmbSelectRoom.FormattingEnabled = True
        Me.cmbSelectRoom.Location = New System.Drawing.Point(150, 140)
        Me.cmbSelectRoom.Name = "cmbSelectRoom"
        Me.cmbSelectRoom.Size = New System.Drawing.Size(206, 28)
        Me.cmbSelectRoom.TabIndex = 12
        '
        'lblSelectRoom
        '
        Me.lblSelectRoom.AutoSize = True
        Me.lblSelectRoom.Font = New System.Drawing.Font("Segoe UI", 11.25!)
        Me.lblSelectRoom.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139)
        Me.lblSelectRoom.Location = New System.Drawing.Point(30, 143)
        Me.lblSelectRoom.Name = "lblSelectRoom"
        Me.lblSelectRoom.Size = New System.Drawing.Size(96, 20)
        Me.lblSelectRoom.TabIndex = 11
        Me.lblSelectRoom.Text = "Select Room:"
        '
        'lblRoomNum
        '
        Me.lblRoomNum.AutoSize = True
        Me.lblRoomNum.Font = New System.Drawing.Font("Segoe UI", 11.25!)
        Me.lblRoomNum.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139)
        Me.lblRoomNum.Location = New System.Drawing.Point(30, 185)
        Me.lblRoomNum.Name = "lblRoomNum"
        Me.lblRoomNum.Size = New System.Drawing.Size(110, 20)
        Me.lblRoomNum.TabIndex = 0
        Me.lblRoomNum.Text = "Room Number:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold)
        Me.Label1.ForeColor = System.Drawing.Color.FromArgb(31, 41, 55)
        Me.Label1.Location = New System.Drawing.Point(146, 184)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(86, 21)
        Me.Label1.TabIndex = 5
        Me.Label1.Text = "--"
        '
        'lblFloor
        '
        Me.lblFloor.AutoSize = True
        Me.lblFloor.Font = New System.Drawing.Font("Segoe UI", 11.25!)
        Me.lblFloor.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139)
        Me.lblFloor.Location = New System.Drawing.Point(30, 215)
        Me.lblFloor.Name = "lblFloor"
        Me.lblFloor.Size = New System.Drawing.Size(84, 20)
        Me.lblFloor.TabIndex = 1
        Me.lblFloor.Text = "Floor Level:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold)
        Me.Label2.ForeColor = System.Drawing.Color.FromArgb(31, 41, 55)
        Me.Label2.Location = New System.Drawing.Point(146, 214)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(75, 21)
        Me.Label2.TabIndex = 6
        Me.Label2.Text = "--"
        '
        'lblRent
        '
        Me.lblRent.AutoSize = True
        Me.lblRent.Font = New System.Drawing.Font("Segoe UI", 11.25!)
        Me.lblRent.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139)
        Me.lblRent.Location = New System.Drawing.Point(30, 245)
        Me.lblRent.Name = "lblRent"
        Me.lblRent.Size = New System.Drawing.Size(77, 20)
        Me.lblRent.TabIndex = 2
        Me.lblRent.Text = "Base Rent:"
        '
        'txtEditRent
        '
        Me.txtEditRent.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold)
        Me.txtEditRent.ForeColor = System.Drawing.Color.SeaGreen
        Me.txtEditRent.Location = New System.Drawing.Point(150, 242)
        Me.txtEditRent.Name = "txtEditRent"
        Me.txtEditRent.Size = New System.Drawing.Size(100, 29)
        Me.txtEditRent.TabIndex = 13
        Me.txtEditRent.Text = "0.00"
        '
        'btnUpdatePrice
        '
        Me.btnUpdatePrice.BackColor = System.Drawing.Color.FromArgb(46, 204, 113)
        Me.btnUpdatePrice.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnUpdatePrice.FlatAppearance.BorderSize = 0
        Me.btnUpdatePrice.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnUpdatePrice.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold)
        Me.btnUpdatePrice.ForeColor = System.Drawing.Color.White
        Me.btnUpdatePrice.Location = New System.Drawing.Point(256, 241)
        Me.btnUpdatePrice.Name = "btnUpdatePrice"
        Me.btnUpdatePrice.Size = New System.Drawing.Size(100, 31)
        Me.btnUpdatePrice.TabIndex = 14
        Me.btnUpdatePrice.Text = "Update Price"
        Me.btnUpdatePrice.UseVisualStyleBackColor = False
        '
        'lblOccupants
        '
        Me.lblOccupants.AutoSize = True
        Me.lblOccupants.Font = New System.Drawing.Font("Segoe UI", 11.25!)
        Me.lblOccupants.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139)
        Me.lblOccupants.Location = New System.Drawing.Point(30, 275)
        Me.lblOccupants.Name = "lblOccupants"
        Me.lblOccupants.Size = New System.Drawing.Size(69, 20)
        Me.lblOccupants.TabIndex = 3
        Me.lblOccupants.Text = "Capacity:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold)
        Me.Label4.ForeColor = System.Drawing.Color.FromArgb(31, 41, 55)
        Me.Label4.Location = New System.Drawing.Point(146, 274)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(82, 21)
        Me.Label4.TabIndex = 8
        Me.Label4.Text = "--"
        '
        'lblSpecTitle
        '
        Me.lblSpecTitle.AutoSize = True
        Me.lblSpecTitle.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold)
        Me.lblSpecTitle.ForeColor = System.Drawing.Color.FromArgb(44, 62, 80)
        Me.lblSpecTitle.Location = New System.Drawing.Point(30, 20)
        Me.lblSpecTitle.Name = "lblSpecTitle"
        Me.lblSpecTitle.Size = New System.Drawing.Size(215, 25)
        Me.lblSpecTitle.TabIndex = 9
        Me.lblSpecTitle.Text = "📋 Room Specifications"
        '
        'lblDescTitle
        '
        Me.lblDescTitle.AutoSize = True
        Me.lblDescTitle.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold)
        Me.lblDescTitle.ForeColor = System.Drawing.Color.FromArgb(44, 62, 80)
        Me.lblDescTitle.Location = New System.Drawing.Point(400, 20)
        Me.lblDescTitle.Name = "lblDescTitle"
        Me.lblDescTitle.Size = New System.Drawing.Size(199, 25)
        Me.lblDescTitle.TabIndex = 10
        Me.lblDescTitle.Text = "📝 Room Description"
        '
        'lblDescContent
        '
        Me.lblDescContent.Font = New System.Drawing.Font("Segoe UI", 11.0!)
        Me.lblDescContent.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139)
        Me.lblDescContent.Location = New System.Drawing.Point(400, 60)
        Me.lblDescContent.Name = "lblDescContent"
        Me.lblDescContent.Size = New System.Drawing.Size(350, 260)
        Me.lblDescContent.TabIndex = 19
        Me.lblDescContent.Text = ""
        '
        'frmRoomDetails
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 17.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(243, 244, 246)
        Me.ClientSize = New System.Drawing.Size(835, 740)
        Me.Controls.Add(Me.pnlDetails)
        Me.Controls.Add(Me.PictureBox2)
        Me.Controls.Add(Me.PictureBox1)
        Me.Font = New System.Drawing.Font("Segoe UI", 9.75!)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.Name = "frmRoomDetails"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Cristina's Place - Room Details"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlDetails.ResumeLayout(False)
        Me.pnlDetails.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
    Friend WithEvents pnlDetails As System.Windows.Forms.Panel
    Friend WithEvents lblSpecTitle As System.Windows.Forms.Label
    Friend WithEvents lblDescTitle As System.Windows.Forms.Label
    Friend WithEvents lblOccupants As System.Windows.Forms.Label
    Friend WithEvents lblRent As System.Windows.Forms.Label
    Friend WithEvents lblFloor As System.Windows.Forms.Label
    Friend WithEvents lblRoomNum As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents cmbSelectRoom As System.Windows.Forms.ComboBox
    Friend WithEvents lblSelectRoom As System.Windows.Forms.Label
    Friend WithEvents txtEditRent As System.Windows.Forms.TextBox
    Friend WithEvents btnUpdatePrice As System.Windows.Forms.Button
    Friend WithEvents lblSelectFloor As System.Windows.Forms.Label
    Friend WithEvents cmbSelectFloor As System.Windows.Forms.ComboBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents cmbCapacity As System.Windows.Forms.ComboBox
    Friend WithEvents lblDescContent As System.Windows.Forms.Label

End Class