﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmRoomDetails
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmRoomDetails))
        PictureBox1 = New PictureBox()
        PictureBox2 = New PictureBox()
        pnlDetails = New Panel()
        lblSpecTitle = New Label()
        lblDescTitle = New Label()
        lblDescContent = New Label()
        Label4 = New Label()
        Label3 = New Label()
        Label2 = New Label()
        Label1 = New Label()
        lblOccupants = New Label()
        lblRent = New Label()
        lblFloor = New Label()
        lblRoomNum = New Label()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox2, ComponentModel.ISupportInitialize).BeginInit()
        pnlDetails.SuspendLayout()
        SuspendLayout()
        ' 
        ' PictureBox1
        ' 
        PictureBox1.BackgroundImageLayout = ImageLayout.Stretch
        PictureBox1.Image = My.Resources.Resources.romm11
        PictureBox1.Location = New Point(25, 25)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(385, 300)
        PictureBox1.SizeMode = PictureBoxSizeMode.Zoom
        PictureBox1.TabIndex = 0
        PictureBox1.TabStop = False
        ' 
        ' PictureBox2
        ' 
        PictureBox2.BackgroundImageLayout = ImageLayout.Stretch
        PictureBox2.Image = My.Resources.Resources.room1
        PictureBox2.Location = New Point(425, 25)
        PictureBox2.Name = "PictureBox2"
        PictureBox2.Size = New Size(385, 300)
        PictureBox2.SizeMode = PictureBoxSizeMode.Zoom
        PictureBox2.TabIndex = 1
        PictureBox2.TabStop = False
        ' 
        ' pnlDetails
        ' 
        pnlDetails.BackColor = Color.White
        pnlDetails.Controls.Add(lblSpecTitle)
        pnlDetails.Controls.Add(lblDescTitle)
        pnlDetails.Controls.Add(lblDescContent)
        pnlDetails.Controls.Add(Label4)
        pnlDetails.Controls.Add(Label3)
        pnlDetails.Controls.Add(Label2)
        pnlDetails.Controls.Add(Label1)
        pnlDetails.Controls.Add(lblOccupants)
        pnlDetails.Controls.Add(lblRent)
        pnlDetails.Controls.Add(lblFloor)
        pnlDetails.Controls.Add(lblRoomNum)
        pnlDetails.Location = New Point(25, 350)
        pnlDetails.Name = "pnlDetails"
        pnlDetails.Size = New Size(785, 360)
        pnlDetails.TabIndex = 2
        ' 
        ' lblSpecTitle
        ' 
        lblSpecTitle.AutoSize = True
        lblSpecTitle.Font = New Font("Segoe UI", 14.25F, FontStyle.Bold)
        lblSpecTitle.ForeColor = Color.FromArgb(CByte(44), CByte(62), CByte(80))
        lblSpecTitle.Location = New Point(30, 30)
        lblSpecTitle.Name = "lblSpecTitle"
        lblSpecTitle.Size = New Size(215, 25)
        lblSpecTitle.TabIndex = 9
        lblSpecTitle.Text = "📋 Room Specifications"
        ' 
        ' lblDescTitle
        ' 
        lblDescTitle.AutoSize = True
        lblDescTitle.Font = New Font("Segoe UI", 14.25F, FontStyle.Bold)
        lblDescTitle.ForeColor = Color.FromArgb(CByte(44), CByte(62), CByte(80))
        lblDescTitle.Location = New Point(400, 30)
        lblDescTitle.Name = "lblDescTitle"
        lblDescTitle.Size = New Size(199, 25)
        lblDescTitle.TabIndex = 10
        lblDescTitle.Text = "📝 Room Description"
        ' 
        ' lblDescContent
        ' 
        lblDescContent.Font = New Font("Segoe UI", 11F)
        lblDescContent.ForeColor = Color.FromArgb(CByte(100), CByte(116), CByte(139))
        lblDescContent.Location = New Point(400, 80)
        lblDescContent.Name = "lblDescContent"
        lblDescContent.Size = New Size(350, 230)
        lblDescContent.TabIndex = 11
        lblDescContent.Text = resources.GetString("lblDescContent.Text")
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Font = New Font("Segoe UI", 12F, FontStyle.Bold)
        Label4.ForeColor = Color.FromArgb(CByte(31), CByte(41), CByte(55))
        Label4.Location = New Point(150, 239)
        Label4.Name = "Label4"
        Label4.Size = New Size(82, 21)
        Label4.TabIndex = 8
        Label4.Text = "4 Persons"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Font = New Font("Segoe UI", 14.25F, FontStyle.Bold)
        Label3.ForeColor = Color.SeaGreen
        Label3.Location = New Point(150, 186)
        Label3.Name = "Label3"
        Label3.Size = New Size(105, 25)
        Label3.TabIndex = 7
        Label3.Text = "₱ 5,500.00"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("Segoe UI", 12F, FontStyle.Bold)
        Label2.ForeColor = Color.FromArgb(CByte(31), CByte(41), CByte(55))
        Label2.Location = New Point(150, 139)
        Label2.Name = "Label2"
        Label2.Size = New Size(75, 21)
        Label2.TabIndex = 6
        Label2.Text = "1st Floor"
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Segoe UI", 12F, FontStyle.Bold)
        Label1.ForeColor = Color.FromArgb(CByte(31), CByte(41), CByte(55))
        Label1.Location = New Point(150, 89)
        Label1.Name = "Label1"
        Label1.Size = New Size(86, 21)
        Label1.TabIndex = 5
        Label1.Text = "Room 101"
        ' 
        ' lblOccupants
        ' 
        lblOccupants.AutoSize = True
        lblOccupants.Font = New Font("Segoe UI", 11.25F)
        lblOccupants.ForeColor = Color.FromArgb(CByte(100), CByte(116), CByte(139))
        lblOccupants.Location = New Point(30, 240)
        lblOccupants.Name = "lblOccupants"
        lblOccupants.Size = New Size(69, 20)
        lblOccupants.TabIndex = 3
        lblOccupants.Text = "Capacity:"
        ' 
        ' lblRent
        ' 
        lblRent.AutoSize = True
        lblRent.Font = New Font("Segoe UI", 11.25F)
        lblRent.ForeColor = Color.FromArgb(CByte(100), CByte(116), CByte(139))
        lblRent.Location = New Point(30, 190)
        lblRent.Name = "lblRent"
        lblRent.Size = New Size(77, 20)
        lblRent.TabIndex = 2
        lblRent.Text = "Base Rent:"
        ' 
        ' lblFloor
        ' 
        lblFloor.AutoSize = True
        lblFloor.Font = New Font("Segoe UI", 11.25F)
        lblFloor.ForeColor = Color.FromArgb(CByte(100), CByte(116), CByte(139))
        lblFloor.Location = New Point(30, 140)
        lblFloor.Name = "lblFloor"
        lblFloor.Size = New Size(84, 20)
        lblFloor.TabIndex = 1
        lblFloor.Text = "Floor Level:"
        ' 
        ' lblRoomNum
        ' 
        lblRoomNum.AutoSize = True
        lblRoomNum.Font = New Font("Segoe UI", 11.25F)
        lblRoomNum.ForeColor = Color.FromArgb(CByte(100), CByte(116), CByte(139))
        lblRoomNum.Location = New Point(30, 90)
        lblRoomNum.Name = "lblRoomNum"
        lblRoomNum.Size = New Size(110, 20)
        lblRoomNum.TabIndex = 0
        lblRoomNum.Text = "Room Number:"
        ' 
        ' frmRoomDetails
        ' 
        AutoScaleDimensions = New SizeF(7F, 17F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.FromArgb(CByte(243), CByte(244), CByte(246))
        ClientSize = New Size(835, 740)
        Controls.Add(pnlDetails)
        Controls.Add(PictureBox2)
        Controls.Add(PictureBox1)
        Font = New Font("Segoe UI", 9.75F)
        FormBorderStyle = FormBorderStyle.FixedSingle
        MaximizeBox = False
        Name = "frmRoomDetails"
        StartPosition = FormStartPosition.CenterScreen
        Text = "Cristina's Place - Room Details"
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox2, ComponentModel.ISupportInitialize).EndInit()
        pnlDetails.ResumeLayout(False)
        pnlDetails.PerformLayout()
        ResumeLayout(False)

    End Sub

    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents pnlDetails As Panel
    Friend WithEvents lblSpecTitle As Label
    Friend WithEvents lblDescTitle As Label
    Friend WithEvents lblDescContent As Label
    Friend WithEvents lblOccupants As Label
    Friend WithEvents lblRent As Label
    Friend WithEvents lblFloor As Label
    Friend WithEvents lblRoomNum As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
End Class