﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmDashboard
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.pnlSidebar = New System.Windows.Forms.Panel()
        Me.btnLogout = New System.Windows.Forms.Button()
        Me.btnRoom = New System.Windows.Forms.Button()
        Me.btnAnnouncement = New System.Windows.Forms.Button()
        Me.btnReports = New System.Windows.Forms.Button()
        Me.btnBilling = New System.Windows.Forms.Button()
        Me.btnTenantMgmt = New System.Windows.Forms.Button()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.lblWelcome = New System.Windows.Forms.Label()
        Me.lblAppName = New System.Windows.Forms.Label()
        Me.pnlHeader = New System.Windows.Forms.Panel()
        Me.lblDate = New System.Windows.Forms.Label()
        Me.lblPageTitle = New System.Windows.Forms.Label()
        Me.cmbFloorFilter = New System.Windows.Forms.ComboBox()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.lblCleaningCount = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.lblAvailableCount = New System.Windows.Forms.Label()
        Me.availbale = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.lblOccupiedCount = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.pnlMain = New System.Windows.Forms.Panel()
        Me.flpRooms = New System.Windows.Forms.FlowLayoutPanel()
        Me.pnlSidebar.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.pnlHeader.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.pnlMain.SuspendLayout()
        Me.SuspendLayout()
        '
        'pnlSidebar
        '
        Me.pnlSidebar.BackColor = System.Drawing.Color.FromArgb(31, 97, 141)
        Me.pnlSidebar.Controls.Add(Me.btnLogout)
        Me.pnlSidebar.Controls.Add(Me.btnRoom)
        Me.pnlSidebar.Controls.Add(Me.btnAnnouncement)
        Me.pnlSidebar.Controls.Add(Me.btnReports)
        Me.pnlSidebar.Controls.Add(Me.btnBilling)
        Me.pnlSidebar.Controls.Add(Me.btnTenantMgmt)
        Me.pnlSidebar.Controls.Add(Me.Panel2)
        Me.pnlSidebar.Dock = System.Windows.Forms.DockStyle.Left
        Me.pnlSidebar.Location = New System.Drawing.Point(0, 0)
        Me.pnlSidebar.Name = "pnlSidebar"
        Me.pnlSidebar.Size = New System.Drawing.Size(250, 749)
        Me.pnlSidebar.TabIndex = 0
        '
        'btnLogout
        '
        Me.btnLogout.BackColor = System.Drawing.Color.FromArgb(192, 57, 43)
        Me.btnLogout.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnLogout.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.btnLogout.FlatAppearance.BorderSize = 0
        Me.btnLogout.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnLogout.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold)
        Me.btnLogout.ForeColor = System.Drawing.Color.White
        Me.btnLogout.Location = New System.Drawing.Point(0, 699)
        Me.btnLogout.Name = "btnLogout"
        Me.btnLogout.Padding = New System.Windows.Forms.Padding(20, 0, 0, 0)
        Me.btnLogout.Size = New System.Drawing.Size(250, 50)
        Me.btnLogout.TabIndex = 6
        Me.btnLogout.Text = "⬅  Log Out"
        Me.btnLogout.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnLogout.UseVisualStyleBackColor = False
        '
        'btnRoom
        '
        Me.btnRoom.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnRoom.Dock = System.Windows.Forms.DockStyle.Top
        Me.btnRoom.FlatAppearance.BorderSize = 0
        Me.btnRoom.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(52, 152, 219)
        Me.btnRoom.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnRoom.Font = New System.Drawing.Font("Segoe UI", 10.5!)
        Me.btnRoom.ForeColor = System.Drawing.Color.White
        Me.btnRoom.Location = New System.Drawing.Point(0, 300)
        Me.btnRoom.Name = "btnRoom"
        Me.btnRoom.Padding = New System.Windows.Forms.Padding(30, 0, 0, 0)
        Me.btnRoom.Size = New System.Drawing.Size(250, 50)
        Me.btnRoom.TabIndex = 7
        Me.btnRoom.Text = "🏠  Room Details"
        Me.btnRoom.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnRoom.UseVisualStyleBackColor = True
        '
        'btnAnnouncement
        '
        Me.btnAnnouncement.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnAnnouncement.Dock = System.Windows.Forms.DockStyle.Top
        Me.btnAnnouncement.FlatAppearance.BorderSize = 0
        Me.btnAnnouncement.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(52, 152, 219)
        Me.btnAnnouncement.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnAnnouncement.Font = New System.Drawing.Font("Segoe UI", 10.5!)
        Me.btnAnnouncement.ForeColor = System.Drawing.Color.White
        Me.btnAnnouncement.Location = New System.Drawing.Point(0, 250)
        Me.btnAnnouncement.Name = "btnAnnouncement"
        Me.btnAnnouncement.Padding = New System.Windows.Forms.Padding(30, 0, 0, 0)
        Me.btnAnnouncement.Size = New System.Drawing.Size(250, 50)
        Me.btnAnnouncement.TabIndex = 4
        Me.btnAnnouncement.Text = "📢  Announcements"
        Me.btnAnnouncement.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnAnnouncement.UseVisualStyleBackColor = True
        '
        'btnReports
        '
        Me.btnReports.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnReports.Dock = System.Windows.Forms.DockStyle.Top
        Me.btnReports.FlatAppearance.BorderSize = 0
        Me.btnReports.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(52, 152, 219)
        Me.btnReports.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnReports.Font = New System.Drawing.Font("Segoe UI", 10.5!)
        Me.btnReports.ForeColor = System.Drawing.Color.White
        Me.btnReports.Location = New System.Drawing.Point(0, 200)
        Me.btnReports.Name = "btnReports"
        Me.btnReports.Padding = New System.Windows.Forms.Padding(30, 0, 0, 0)
        Me.btnReports.Size = New System.Drawing.Size(250, 50)
        Me.btnReports.TabIndex = 3
        Me.btnReports.Text = "📊  Reports"
        Me.btnReports.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnReports.UseVisualStyleBackColor = True
        '
        'btnBilling
        '
        Me.btnBilling.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnBilling.Dock = System.Windows.Forms.DockStyle.Top
        Me.btnBilling.FlatAppearance.BorderSize = 0
        Me.btnBilling.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(52, 152, 219)
        Me.btnBilling.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnBilling.Font = New System.Drawing.Font("Segoe UI", 10.5!)
        Me.btnBilling.ForeColor = System.Drawing.Color.White
        Me.btnBilling.Location = New System.Drawing.Point(0, 150)
        Me.btnBilling.Name = "btnBilling"
        Me.btnBilling.Padding = New System.Windows.Forms.Padding(30, 0, 0, 0)
        Me.btnBilling.Size = New System.Drawing.Size(250, 50)
        Me.btnBilling.TabIndex = 2
        Me.btnBilling.Text = "💳  Billing"
        Me.btnBilling.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnBilling.UseVisualStyleBackColor = True
        '
        'btnTenantMgmt
        '
        Me.btnTenantMgmt.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnTenantMgmt.Dock = System.Windows.Forms.DockStyle.Top
        Me.btnTenantMgmt.FlatAppearance.BorderSize = 0
        Me.btnTenantMgmt.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(52, 152, 219)
        Me.btnTenantMgmt.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnTenantMgmt.Font = New System.Drawing.Font("Segoe UI", 10.5!)
        Me.btnTenantMgmt.ForeColor = System.Drawing.Color.White
        Me.btnTenantMgmt.Location = New System.Drawing.Point(0, 100)
        Me.btnTenantMgmt.Name = "btnTenantMgmt"
        Me.btnTenantMgmt.Padding = New System.Windows.Forms.Padding(30, 0, 0, 0)
        Me.btnTenantMgmt.Size = New System.Drawing.Size(250, 50)
        Me.btnTenantMgmt.TabIndex = 1
        Me.btnTenantMgmt.Text = "👥  Tenant Management"
        Me.btnTenantMgmt.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnTenantMgmt.UseVisualStyleBackColor = True
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.lblWelcome)
        Me.Panel2.Controls.Add(Me.lblAppName)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel2.Location = New System.Drawing.Point(0, 0)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(250, 100)
        Me.Panel2.TabIndex = 0
        '
        'lblWelcome
        '
        Me.lblWelcome.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.lblWelcome.ForeColor = System.Drawing.Color.FromArgb(180, 215, 240)
        Me.lblWelcome.Location = New System.Drawing.Point(0, 60)
        Me.lblWelcome.Name = "lblWelcome"
        Me.lblWelcome.Size = New System.Drawing.Size(250, 25)
        Me.lblWelcome.TabIndex = 0
        Me.lblWelcome.Text = "Welcome, Admin!"
        Me.lblWelcome.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblAppName
        '
        Me.lblAppName.Font = New System.Drawing.Font("Segoe UI", 14.0!, System.Drawing.FontStyle.Bold)
        Me.lblAppName.ForeColor = System.Drawing.Color.White
        Me.lblAppName.Location = New System.Drawing.Point(0, 20)
        Me.lblAppName.Name = "lblAppName"
        Me.lblAppName.Size = New System.Drawing.Size(250, 40)
        Me.lblAppName.TabIndex = 1
        Me.lblAppName.Text = "🏠 Rental Space"
        Me.lblAppName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'pnlHeader
        '
        Me.pnlHeader.BackColor = System.Drawing.Color.White
        Me.pnlHeader.Controls.Add(Me.lblDate)
        Me.pnlHeader.Controls.Add(Me.lblPageTitle)
        Me.pnlHeader.Controls.Add(Me.cmbFloorFilter)
        Me.pnlHeader.Controls.Add(Me.Panel4)
        Me.pnlHeader.Controls.Add(Me.Panel3)
        Me.pnlHeader.Controls.Add(Me.Panel1)
        Me.pnlHeader.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlHeader.Location = New System.Drawing.Point(250, 0)
        Me.pnlHeader.Name = "pnlHeader"
        Me.pnlHeader.Padding = New System.Windows.Forms.Padding(20)
        Me.pnlHeader.Size = New System.Drawing.Size(1034, 150)
        Me.pnlHeader.TabIndex = 1
        '
        'lblDate
        '
        Me.lblDate.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblDate.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.lblDate.ForeColor = System.Drawing.Color.Gray
        Me.lblDate.Location = New System.Drawing.Point(750, 25)
        Me.lblDate.Name = "lblDate"
        Me.lblDate.Size = New System.Drawing.Size(260, 20)
        Me.lblDate.TabIndex = 4
        Me.lblDate.Text = DateTime.Now.ToString("dddd, MMMM dd, yyyy")
        Me.lblDate.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblPageTitle
        '
        Me.lblPageTitle.AutoSize = True
        Me.lblPageTitle.Font = New System.Drawing.Font("Segoe UI", 16.0!, System.Drawing.FontStyle.Bold)
        Me.lblPageTitle.ForeColor = System.Drawing.Color.FromArgb(44, 62, 80)
        Me.lblPageTitle.Location = New System.Drawing.Point(20, 15)
        Me.lblPageTitle.Name = "lblPageTitle"
        Me.lblPageTitle.Size = New System.Drawing.Size(232, 30)
        Me.lblPageTitle.TabIndex = 3
        Me.lblPageTitle.Text = "Dashboard Overview"
        '
        'cmbFloorFilter
        '
        Me.cmbFloorFilter.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbFloorFilter.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.cmbFloorFilter.FormattingEnabled = True
        Me.cmbFloorFilter.Location = New System.Drawing.Point(25, 95)
        Me.cmbFloorFilter.Name = "cmbFloorFilter"
        Me.cmbFloorFilter.Size = New System.Drawing.Size(180, 25)
        Me.cmbFloorFilter.TabIndex = 2
        '
        'Panel4
        '
        Me.Panel4.BackColor = System.Drawing.Color.FromArgb(243, 156, 18)
        Me.Panel4.Controls.Add(Me.lblCleaningCount)
        Me.Panel4.Controls.Add(Me.Label5)
        Me.Panel4.Location = New System.Drawing.Point(575, 45)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(160, 85)
        Me.Panel4.TabIndex = 1
        '
        'lblCleaningCount
        '
        Me.lblCleaningCount.Font = New System.Drawing.Font("Segoe UI", 22.0!, System.Drawing.FontStyle.Bold)
        Me.lblCleaningCount.ForeColor = System.Drawing.Color.White
        Me.lblCleaningCount.Location = New System.Drawing.Point(0, 35)
        Me.lblCleaningCount.Name = "lblCleaningCount"
        Me.lblCleaningCount.Size = New System.Drawing.Size(160, 40)
        Me.lblCleaningCount.TabIndex = 5
        Me.lblCleaningCount.Text = "0"
        Me.lblCleaningCount.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label5
        '
        Me.Label5.Font = New System.Drawing.Font("Segoe UI", 9.5!)
        Me.Label5.ForeColor = System.Drawing.Color.White
        Me.Label5.Location = New System.Drawing.Point(0, 10)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(160, 20)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Needs Cleaning"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.FromArgb(46, 204, 113)
        Me.Panel3.Controls.Add(Me.lblAvailableCount)
        Me.Panel3.Controls.Add(Me.availbale)
        Me.Panel3.Location = New System.Drawing.Point(400, 45)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(160, 85)
        Me.Panel3.TabIndex = 1
        '
        'lblAvailableCount
        '
        Me.lblAvailableCount.Font = New System.Drawing.Font("Segoe UI", 22.0!, System.Drawing.FontStyle.Bold)
        Me.lblAvailableCount.ForeColor = System.Drawing.Color.White
        Me.lblAvailableCount.Location = New System.Drawing.Point(0, 35)
        Me.lblAvailableCount.Name = "lblAvailableCount"
        Me.lblAvailableCount.Size = New System.Drawing.Size(160, 40)
        Me.lblAvailableCount.TabIndex = 3
        Me.lblAvailableCount.Text = "46"
        Me.lblAvailableCount.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'availbale
        '
        Me.availbale.Font = New System.Drawing.Font("Segoe UI", 9.5!)
        Me.availbale.ForeColor = System.Drawing.Color.White
        Me.availbale.Location = New System.Drawing.Point(0, 10)
        Me.availbale.Name = "availbale"
        Me.availbale.Size = New System.Drawing.Size(160, 20)
        Me.availbale.TabIndex = 2
        Me.availbale.Text = "Available Rooms"
        Me.availbale.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(231, 76, 60)
        Me.Panel1.Controls.Add(Me.lblOccupiedCount)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Location = New System.Drawing.Point(225, 45)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(160, 85)
        Me.Panel1.TabIndex = 0
        '
        'lblOccupiedCount
        '
        Me.lblOccupiedCount.Font = New System.Drawing.Font("Segoe UI", 22.0!, System.Drawing.FontStyle.Bold)
        Me.lblOccupiedCount.ForeColor = System.Drawing.Color.White
        Me.lblOccupiedCount.Location = New System.Drawing.Point(0, 35)
        Me.lblOccupiedCount.Name = "lblOccupiedCount"
        Me.lblOccupiedCount.Size = New System.Drawing.Size(160, 40)
        Me.lblOccupiedCount.TabIndex = 1
        Me.lblOccupiedCount.Text = "0"
        Me.lblOccupiedCount.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Segoe UI", 9.5!)
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(0, 10)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(160, 20)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Occupied Rooms"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'pnlMain
        '
        Me.pnlMain.BackColor = System.Drawing.Color.FromArgb(245, 247, 250)
        Me.pnlMain.Controls.Add(Me.flpRooms)
        Me.pnlMain.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlMain.Location = New System.Drawing.Point(250, 150)
        Me.pnlMain.Name = "pnlMain"
        Me.pnlMain.Padding = New System.Windows.Forms.Padding(20)
        Me.pnlMain.Size = New System.Drawing.Size(1034, 599)
        Me.pnlMain.TabIndex = 2
        '
        'flpRooms
        '
        Me.flpRooms.AutoScroll = True
        Me.flpRooms.BackColor = System.Drawing.Color.Transparent
        Me.flpRooms.Dock = System.Windows.Forms.DockStyle.Fill
        Me.flpRooms.Location = New System.Drawing.Point(20, 20)
        Me.flpRooms.Name = "flpRooms"
        Me.flpRooms.Size = New System.Drawing.Size(994, 559)
        Me.flpRooms.TabIndex = 0
        '
        'frmDashboard
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 17.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(245, 247, 250)
        Me.ClientSize = New System.Drawing.Size(1284, 749)
        Me.Controls.Add(Me.pnlMain)
        Me.Controls.Add(Me.pnlHeader)
        Me.Controls.Add(Me.pnlSidebar)
        Me.Font = New System.Drawing.Font("Segoe UI", 9.75!)
        Me.Name = "frmDashboard"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Rental Space - Dashboard"
        Me.pnlSidebar.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        Me.pnlHeader.ResumeLayout(False)
        Me.pnlHeader.PerformLayout()
        Me.Panel4.ResumeLayout(False)
        Me.Panel3.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.pnlMain.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents pnlSidebar As Panel
    Friend WithEvents Panel2 As Panel
    Friend WithEvents lblAppName As Label
    Friend WithEvents lblWelcome As Label
    Friend WithEvents btnAnnouncement As Button
    Friend WithEvents btnReports As Button
    Friend WithEvents btnBilling As Button
    Friend WithEvents btnTenantMgmt As Button
    Friend WithEvents pnlHeader As Panel
    Friend WithEvents lblPageTitle As Label
    Friend WithEvents lblDate As Label
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Panel4 As Panel
    Friend WithEvents lblCleaningCount As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Panel3 As Panel
    Friend WithEvents lblAvailableCount As Label
    Friend WithEvents availbale As Label
    Friend WithEvents lblOccupiedCount As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents pnlMain As Panel
    Friend WithEvents flpRooms As FlowLayoutPanel
    Friend WithEvents btnLogout As Button
    Friend WithEvents btnRoom As Button
    Friend WithEvents cmbFloorFilter As ComboBox
End Class