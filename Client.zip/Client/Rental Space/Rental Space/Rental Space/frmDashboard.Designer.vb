﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmDashboard
    Inherits System.Windows.Forms.Form

    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    Private components As System.ComponentModel.IContainer

    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        pnlSidebar = New Panel()
        btnLogout = New Button()
        btnRoom = New Button()
        btnAnnouncement = New Button()
        btnReports = New Button()
        btnBilling = New Button()
        btnManageUsers = New Button()
        btnTenantMgmt = New Button()
        Panel2 = New Panel()
        lblWelcome = New Label()
        lblAppName = New Label()
        pnlHeader = New Panel()
        lblDate = New Label()
        lblPageTitle = New Label()
        cmbFloorFilter = New ComboBox()
        Panel4 = New Panel()
        lblCleaningCount = New Label()
        Label5 = New Label()
        Panel3 = New Panel()
        lblAvailableCount = New Label()
        availbale = New Label()
        Panel1 = New Panel()
        lblOccupiedCount = New Label()
        Label1 = New Label()
        pnlMain = New Panel()
        flpRooms = New FlowLayoutPanel()
        pnlSidebar.SuspendLayout()
        Panel2.SuspendLayout()
        pnlHeader.SuspendLayout()
        Panel4.SuspendLayout()
        Panel3.SuspendLayout()
        Panel1.SuspendLayout()
        pnlMain.SuspendLayout()
        SuspendLayout()
        ' 
        ' pnlSidebar
        ' 
        pnlSidebar.BackColor = Color.FromArgb(CByte(31), CByte(97), CByte(141))
        pnlSidebar.Controls.Add(btnLogout)
        pnlSidebar.Controls.Add(btnRoom)
        pnlSidebar.Controls.Add(btnAnnouncement)
        pnlSidebar.Controls.Add(btnReports)
        pnlSidebar.Controls.Add(btnBilling)
        pnlSidebar.Controls.Add(btnManageUsers)
        pnlSidebar.Controls.Add(btnTenantMgmt)
        pnlSidebar.Controls.Add(Panel2)
        pnlSidebar.Dock = DockStyle.Left
        pnlSidebar.Location = New Point(0, 0)
        pnlSidebar.Name = "pnlSidebar"
        pnlSidebar.Size = New Size(250, 749)
        pnlSidebar.TabIndex = 0
        ' 
        ' btnLogout
        ' 
        btnLogout.BackColor = Color.FromArgb(CByte(192), CByte(57), CByte(43))
        btnLogout.Cursor = Cursors.Hand
        btnLogout.Dock = DockStyle.Bottom
        btnLogout.FlatAppearance.BorderSize = 0
        btnLogout.FlatStyle = FlatStyle.Flat
        btnLogout.Font = New Font("Segoe UI", 10.0F, FontStyle.Bold)
        btnLogout.ForeColor = Color.White
        btnLogout.Location = New Point(0, 699)
        btnLogout.Name = "btnLogout"
        btnLogout.Padding = New Padding(20, 0, 0, 0)
        btnLogout.Size = New Size(250, 50)
        btnLogout.TabIndex = 6
        btnLogout.Text = "⬅  Log Out"
        btnLogout.TextAlign = ContentAlignment.MiddleLeft
        btnLogout.UseVisualStyleBackColor = False
        ' 
        ' btnRoom
        ' 
        btnRoom.Cursor = Cursors.Hand
        btnRoom.Dock = DockStyle.Top
        btnRoom.FlatAppearance.BorderSize = 0
        btnRoom.FlatAppearance.MouseOverBackColor = Color.FromArgb(CByte(52), CByte(152), CByte(219))
        btnRoom.FlatStyle = FlatStyle.Flat
        btnRoom.Font = New Font("Segoe UI", 10.5F)
        btnRoom.ForeColor = Color.White
        btnRoom.Location = New Point(0, 350)
        btnRoom.Name = "btnRoom"
        btnRoom.Padding = New Padding(30, 0, 0, 0)
        btnRoom.Size = New Size(250, 50)
        btnRoom.TabIndex = 7
        btnRoom.Text = "🏠  Room Details"
        btnRoom.TextAlign = ContentAlignment.MiddleLeft
        btnRoom.UseVisualStyleBackColor = True
        ' 
        ' btnAnnouncement
        ' 
        btnAnnouncement.Cursor = Cursors.Hand
        btnAnnouncement.Dock = DockStyle.Top
        btnAnnouncement.FlatAppearance.BorderSize = 0
        btnAnnouncement.FlatAppearance.MouseOverBackColor = Color.FromArgb(CByte(52), CByte(152), CByte(219))
        btnAnnouncement.FlatStyle = FlatStyle.Flat
        btnAnnouncement.Font = New Font("Segoe UI", 10.5F)
        btnAnnouncement.ForeColor = Color.White
        btnAnnouncement.Location = New Point(0, 300)
        btnAnnouncement.Name = "btnAnnouncement"
        btnAnnouncement.Padding = New Padding(30, 0, 0, 0)
        btnAnnouncement.Size = New Size(250, 50)
        btnAnnouncement.TabIndex = 4
        btnAnnouncement.Text = "📢  Announcements"
        btnAnnouncement.TextAlign = ContentAlignment.MiddleLeft
        btnAnnouncement.UseVisualStyleBackColor = True
        ' 
        ' btnReports
        ' 
        btnReports.Cursor = Cursors.Hand
        btnReports.Dock = DockStyle.Top
        btnReports.FlatAppearance.BorderSize = 0
        btnReports.FlatAppearance.MouseOverBackColor = Color.FromArgb(CByte(52), CByte(152), CByte(219))
        btnReports.FlatStyle = FlatStyle.Flat
        btnReports.Font = New Font("Segoe UI", 10.5F)
        btnReports.ForeColor = Color.White
        btnReports.Location = New Point(0, 250)
        btnReports.Name = "btnReports"
        btnReports.Padding = New Padding(30, 0, 0, 0)
        btnReports.Size = New Size(250, 50)
        btnReports.TabIndex = 3
        btnReports.Text = "📊  Reports"
        btnReports.TextAlign = ContentAlignment.MiddleLeft
        btnReports.UseVisualStyleBackColor = True
        ' 
        ' btnBilling
        ' 
        btnBilling.Cursor = Cursors.Hand
        btnBilling.Dock = DockStyle.Top
        btnBilling.FlatAppearance.BorderSize = 0
        btnBilling.FlatAppearance.MouseOverBackColor = Color.FromArgb(CByte(52), CByte(152), CByte(219))
        btnBilling.FlatStyle = FlatStyle.Flat
        btnBilling.Font = New Font("Segoe UI", 10.5F)
        btnBilling.ForeColor = Color.White
        btnBilling.Location = New Point(0, 200)
        btnBilling.Name = "btnBilling"
        btnBilling.Padding = New Padding(30, 0, 0, 0)
        btnBilling.Size = New Size(250, 50)
        btnBilling.TabIndex = 2
        btnBilling.Text = "💳  Billing"
        btnBilling.TextAlign = ContentAlignment.MiddleLeft
        btnBilling.UseVisualStyleBackColor = True
        ' 
        ' btnManageUsers
        ' 
        btnManageUsers.Cursor = Cursors.Hand
        btnManageUsers.Dock = DockStyle.Top
        btnManageUsers.FlatAppearance.BorderSize = 0
        btnManageUsers.FlatAppearance.MouseOverBackColor = Color.FromArgb(CByte(52), CByte(152), CByte(219))
        btnManageUsers.FlatStyle = FlatStyle.Flat
        btnManageUsers.Font = New Font("Segoe UI", 10.5F)
        btnManageUsers.ForeColor = Color.White
        btnManageUsers.Location = New Point(0, 150)
        btnManageUsers.Name = "btnManageUsers"
        btnManageUsers.Padding = New Padding(30, 0, 0, 0)
        btnManageUsers.Size = New Size(250, 50)
        btnManageUsers.TabIndex = 8
        btnManageUsers.Text = "🛡️  Manage Users"
        btnManageUsers.TextAlign = ContentAlignment.MiddleLeft
        btnManageUsers.UseVisualStyleBackColor = True
        ' 
        ' btnTenantMgmt
        ' 
        btnTenantMgmt.Cursor = Cursors.Hand
        btnTenantMgmt.Dock = DockStyle.Top
        btnTenantMgmt.FlatAppearance.BorderSize = 0
        btnTenantMgmt.FlatAppearance.MouseOverBackColor = Color.FromArgb(CByte(52), CByte(152), CByte(219))
        btnTenantMgmt.FlatStyle = FlatStyle.Flat
        btnTenantMgmt.Font = New Font("Segoe UI", 10.5F)
        btnTenantMgmt.ForeColor = Color.White
        btnTenantMgmt.Location = New Point(0, 100)
        btnTenantMgmt.Name = "btnTenantMgmt"
        btnTenantMgmt.Padding = New Padding(30, 0, 0, 0)
        btnTenantMgmt.Size = New Size(250, 50)
        btnTenantMgmt.TabIndex = 1
        btnTenantMgmt.Text = "👥  Tenant Management"
        btnTenantMgmt.TextAlign = ContentAlignment.MiddleLeft
        btnTenantMgmt.UseVisualStyleBackColor = True
        ' 
        ' Panel2
        ' 
        Panel2.Controls.Add(lblWelcome)
        Panel2.Controls.Add(lblAppName)
        Panel2.Dock = DockStyle.Top
        Panel2.Location = New Point(0, 0)
        Panel2.Name = "Panel2"
        Panel2.Size = New Size(250, 100)
        Panel2.TabIndex = 0
        ' 
        ' lblWelcome
        ' 
        lblWelcome.Font = New Font("Segoe UI", 9.0F)
        lblWelcome.ForeColor = Color.FromArgb(CByte(180), CByte(215), CByte(240))
        lblWelcome.Location = New Point(0, 60)
        lblWelcome.Name = "lblWelcome"
        lblWelcome.Size = New Size(250, 25)
        lblWelcome.TabIndex = 0
        lblWelcome.Text = "Welcome, Admin!"
        lblWelcome.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' lblAppName
        ' 
        lblAppName.Font = New Font("Segoe UI", 14.0F, FontStyle.Bold)
        lblAppName.ForeColor = Color.White
        lblAppName.Location = New Point(0, 20)
        lblAppName.Name = "lblAppName"
        lblAppName.Size = New Size(250, 40)
        lblAppName.TabIndex = 1
        lblAppName.Text = "🏠 Cristina's Place"
        lblAppName.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' pnlHeader
        ' 
        pnlHeader.BackColor = Color.White
        pnlHeader.Controls.Add(lblDate)
        pnlHeader.Controls.Add(lblPageTitle)
        pnlHeader.Controls.Add(cmbFloorFilter)
        pnlHeader.Controls.Add(Panel4)
        pnlHeader.Controls.Add(Panel3)
        pnlHeader.Controls.Add(Panel1)
        pnlHeader.Dock = DockStyle.Top
        pnlHeader.Location = New Point(250, 0)
        pnlHeader.Name = "pnlHeader"
        pnlHeader.Padding = New Padding(20)
        pnlHeader.Size = New Size(1034, 150)
        pnlHeader.TabIndex = 1
        ' 
        ' lblDate
        ' 
        lblDate.Anchor = AnchorStyles.Top Or AnchorStyles.Right
        lblDate.Font = New Font("Segoe UI", 10.0F)
        lblDate.ForeColor = Color.Gray
        lblDate.Location = New Point(750, 25)
        lblDate.Name = "lblDate"
        lblDate.Size = New Size(260, 20)
        lblDate.TabIndex = 4
        lblDate.Text = "Tuesday, May 12, 2026"
        lblDate.TextAlign = ContentAlignment.MiddleRight
        ' 
        ' lblPageTitle
        ' 
        lblPageTitle.AutoSize = True
        lblPageTitle.Font = New Font("Segoe UI", 16.0F, FontStyle.Bold)
        lblPageTitle.ForeColor = Color.FromArgb(CByte(44), CByte(62), CByte(80))
        lblPageTitle.Location = New Point(20, 15)
        lblPageTitle.Name = "lblPageTitle"
        lblPageTitle.Size = New Size(177, 30)
        lblPageTitle.TabIndex = 3
        lblPageTitle.Text = "Room Overview"
        ' 
        ' cmbFloorFilter
        ' 
        cmbFloorFilter.DropDownStyle = ComboBoxStyle.DropDownList
        cmbFloorFilter.Font = New Font("Segoe UI", 10.0F)
        cmbFloorFilter.FormattingEnabled = True
        cmbFloorFilter.Location = New Point(25, 95)
        cmbFloorFilter.Name = "cmbFloorFilter"
        cmbFloorFilter.Size = New Size(180, 25)
        cmbFloorFilter.TabIndex = 2
        ' 
        ' Panel4
        ' 
        Panel4.BackColor = Color.FromArgb(CByte(243), CByte(156), CByte(18))
        Panel4.Controls.Add(lblCleaningCount)
        Panel4.Controls.Add(Label5)
        Panel4.Location = New Point(575, 45)
        Panel4.Name = "Panel4"
        Panel4.Size = New Size(160, 85)
        Panel4.TabIndex = 1
        ' 
        ' lblCleaningCount
        ' 
        lblCleaningCount.Font = New Font("Segoe UI", 22.0F, FontStyle.Bold)
        lblCleaningCount.ForeColor = Color.White
        lblCleaningCount.Location = New Point(0, 35)
        lblCleaningCount.Name = "lblCleaningCount"
        lblCleaningCount.Size = New Size(160, 40)
        lblCleaningCount.TabIndex = 5
        lblCleaningCount.Text = "0"
        lblCleaningCount.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' Label5
        ' 
        Label5.Font = New Font("Segoe UI", 9.5F)
        Label5.ForeColor = Color.White
        Label5.Location = New Point(0, 10)
        Label5.Name = "Label5"
        Label5.Size = New Size(160, 20)
        Label5.TabIndex = 4
        Label5.Text = "Needs Cleaning"
        Label5.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' Panel3
        ' 
        Panel3.BackColor = Color.FromArgb(CByte(46), CByte(204), CByte(113))
        Panel3.Controls.Add(lblAvailableCount)
        Panel3.Controls.Add(availbale)
        Panel3.Location = New Point(400, 45)
        Panel3.Name = "Panel3"
        Panel3.Size = New Size(160, 85)
        Panel3.TabIndex = 1
        ' 
        ' lblAvailableCount
        ' 
        lblAvailableCount.Font = New Font("Segoe UI", 22.0F, FontStyle.Bold)
        lblAvailableCount.ForeColor = Color.White
        lblAvailableCount.Location = New Point(0, 35)
        lblAvailableCount.Name = "lblAvailableCount"
        lblAvailableCount.Size = New Size(160, 40)
        lblAvailableCount.TabIndex = 3
        lblAvailableCount.Text = "0"
        lblAvailableCount.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' availbale
        ' 
        availbale.Font = New Font("Segoe UI", 9.5F)
        availbale.ForeColor = Color.White
        availbale.Location = New Point(0, 10)
        availbale.Name = "availbale"
        availbale.Size = New Size(160, 20)
        availbale.TabIndex = 2
        availbale.Text = "Available Rooms"
        availbale.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' Panel1
        ' 
        Panel1.BackColor = Color.FromArgb(CByte(231), CByte(76), CByte(60))
        Panel1.Controls.Add(lblOccupiedCount)
        Panel1.Controls.Add(Label1)
        Panel1.Location = New Point(225, 45)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(160, 85)
        Panel1.TabIndex = 0
        ' 
        ' lblOccupiedCount
        ' 
        lblOccupiedCount.Font = New Font("Segoe UI", 22.0F, FontStyle.Bold)
        lblOccupiedCount.ForeColor = Color.White
        lblOccupiedCount.Location = New Point(0, 35)
        lblOccupiedCount.Name = "lblOccupiedCount"
        lblOccupiedCount.Size = New Size(160, 40)
        lblOccupiedCount.TabIndex = 1
        lblOccupiedCount.Text = "0"
        lblOccupiedCount.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' Label1
        ' 
        Label1.Font = New Font("Segoe UI", 9.5F)
        Label1.ForeColor = Color.White
        Label1.Location = New Point(0, 10)
        Label1.Name = "Label1"
        Label1.Size = New Size(160, 20)
        Label1.TabIndex = 0
        Label1.Text = "Occupied Rooms"
        Label1.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' pnlMain
        ' 
        pnlMain.BackColor = Color.FromArgb(CByte(245), CByte(247), CByte(250))
        pnlMain.Controls.Add(flpRooms)
        pnlMain.Dock = DockStyle.Fill
        pnlMain.Location = New Point(250, 150)
        pnlMain.Name = "pnlMain"
        pnlMain.Padding = New Padding(20)
        pnlMain.Size = New Size(1034, 599)
        pnlMain.TabIndex = 2
        ' 
        ' flpRooms
        ' 
        flpRooms.AutoScroll = True
        flpRooms.BackColor = Color.Transparent
        flpRooms.Dock = DockStyle.Fill
        flpRooms.Location = New Point(20, 20)
        flpRooms.Name = "flpRooms"
        flpRooms.Size = New Size(994, 559)
        flpRooms.TabIndex = 0
        ' 
        ' frmDashboard
        ' 
        AutoScaleDimensions = New SizeF(7.0F, 17.0F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.FromArgb(CByte(245), CByte(247), CByte(250))
        ClientSize = New Size(1284, 749)
        Controls.Add(pnlMain)
        Controls.Add(pnlHeader)
        Controls.Add(pnlSidebar)
        Font = New Font("Segoe UI", 9.75F)
        Name = "frmDashboard"
        StartPosition = FormStartPosition.CenterScreen
        Text = "Cristina's Place - Dashboard"
        pnlSidebar.ResumeLayout(False)
        Panel2.ResumeLayout(False)
        pnlHeader.ResumeLayout(False)
        pnlHeader.PerformLayout()
        Panel4.ResumeLayout(False)
        Panel3.ResumeLayout(False)
        Panel1.ResumeLayout(False)
        pnlMain.ResumeLayout(False)
        ResumeLayout(False)
    End Sub

    Friend WithEvents pnlSidebar As Panel
    Friend WithEvents Panel2 As Panel
    Friend WithEvents lblAppName As Label
    Friend WithEvents lblWelcome As Label
    Friend WithEvents btnAnnouncement As Button
    Friend WithEvents btnReports As Button
    Friend WithEvents btnBilling As Button
    Friend WithEvents btnManageUsers As Button
    Friend WithEvents btnTenantMgmt As Button
    Friend WithEvents pnlHeader As Panel
    Friend WithEvents lblPageTitle As Label
    Friend WithEvents lblDate As Label
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Panel4 As Panel
    Friend WithEvents lblCleaningCount As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Panel3 As Panel
    Friend WithEvents lblAvailableCount As Label
    Friend WithEvents availbale As Label
    Friend WithEvents lblOccupiedCount As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents pnlMain As Panel
    Friend WithEvents flpRooms As FlowLayoutPanel
    Friend WithEvents btnLogout As Button
    Friend WithEvents btnRoom As Button
    Friend WithEvents cmbFloorFilter As ComboBox
End Class