﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmDashboard
    Inherits System.Windows.Forms.Form

    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    Private components As System.ComponentModel.IContainer

    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.pnlSidebar = New System.Windows.Forms.Panel()
        Me.btnLogout = New System.Windows.Forms.Button()
        Me.btnRoom = New System.Windows.Forms.Button()
        Me.btnAnnouncement = New System.Windows.Forms.Button()
        Me.btnReports = New System.Windows.Forms.Button()
        Me.btnBilling = New System.Windows.Forms.Button()
        Me.btnPayment = New System.Windows.Forms.Button()
        Me.btnManageUsers = New System.Windows.Forms.Button()
        Me.btnTenantMgmt = New System.Windows.Forms.Button()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.lblWelcome = New System.Windows.Forms.Label()
        Me.lblAppName = New System.Windows.Forms.Label()
        Me.pnlHeader = New System.Windows.Forms.Panel()
        Me.pnlColorMaintenance = New System.Windows.Forms.Panel()
        Me.lblLegendMaintenance = New System.Windows.Forms.Label()
        Me.pnlColorPending = New System.Windows.Forms.Panel()
        Me.lblLegendPending = New System.Windows.Forms.Label()
        Me.pnlColorOccupied = New System.Windows.Forms.Panel()
        Me.lblLegendOccupied = New System.Windows.Forms.Label()
        Me.pnlColorAvailable = New System.Windows.Forms.Panel()
        Me.lblLegendAvailable = New System.Windows.Forms.Label()
        Me.lblDate = New System.Windows.Forms.Label()
        Me.lblPageTitle = New System.Windows.Forms.Label()
        Me.cmbFloorFilter = New System.Windows.Forms.ComboBox()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.lblCleaningCount = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.lblAvailableCount = New System.Windows.Forms.Label()
        Me.availbale = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.lblOccupiedCount = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.pnlMain = New System.Windows.Forms.Panel()
        Me.flpRooms = New System.Windows.Forms.FlowLayoutPanel()
        Me.tmrDate = New System.Windows.Forms.Timer(Me.components)
        Me.pnlSidebar.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.pnlHeader.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.pnlMain.SuspendLayout()
        Me.SuspendLayout()

        Me.pnlSidebar.BackColor = System.Drawing.Color.FromArgb(CType(CType(31, Byte), Integer), CType(CType(97, Byte), Integer), CType(CType(141, Byte), Integer))
        Me.pnlSidebar.Controls.Add(Me.btnLogout)
        Me.pnlSidebar.Controls.Add(Me.btnRoom)
        Me.pnlSidebar.Controls.Add(Me.btnAnnouncement)
        Me.pnlSidebar.Controls.Add(Me.btnReports)
        Me.pnlSidebar.Controls.Add(Me.btnBilling)
        Me.pnlSidebar.Controls.Add(Me.btnPayment)
        Me.pnlSidebar.Controls.Add(Me.btnManageUsers)
        Me.pnlSidebar.Controls.Add(Me.btnTenantMgmt)
        Me.pnlSidebar.Controls.Add(Me.Panel2)
        Me.pnlSidebar.Dock = System.Windows.Forms.DockStyle.Left
        Me.pnlSidebar.Location = New System.Drawing.Point(0, 0)
        Me.pnlSidebar.Name = "pnlSidebar"
        Me.pnlSidebar.Size = New System.Drawing.Size(250, 749)
        Me.pnlSidebar.TabIndex = 0

        Me.btnLogout.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(57, Byte), Integer), CType(CType(43, Byte), Integer))
        Me.btnLogout.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnLogout.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.btnLogout.FlatAppearance.BorderSize = 0
        Me.btnLogout.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnLogout.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold)
        Me.btnLogout.ForeColor = System.Drawing.Color.White
        Me.btnLogout.Location = New System.Drawing.Point(0, 699)
        Me.btnLogout.Name = "btnLogout"
        Me.btnLogout.Padding = New System.Windows.Forms.Padding(20, 0, 0, 0)
        Me.btnLogout.Size = New System.Drawing.Size(250, 50)
        Me.btnLogout.TabIndex = 6
        Me.btnLogout.Text = "⬅  Log Out"
        Me.btnLogout.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnLogout.UseVisualStyleBackColor = False

        Me.btnRoom.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnRoom.Dock = System.Windows.Forms.DockStyle.Top
        Me.btnRoom.FlatAppearance.BorderSize = 0
        Me.btnRoom.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(52, Byte), Integer), CType(CType(152, Byte), Integer), CType(CType(219, Byte), Integer))
        Me.btnRoom.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnRoom.Font = New System.Drawing.Font("Segoe UI", 10.5!)
        Me.btnRoom.ForeColor = System.Drawing.Color.White
        Me.btnRoom.Location = New System.Drawing.Point(0, 400)
        Me.btnRoom.Name = "btnRoom"
        Me.btnRoom.Padding = New System.Windows.Forms.Padding(30, 0, 0, 0)
        Me.btnRoom.Size = New System.Drawing.Size(250, 50)
        Me.btnRoom.TabIndex = 7
        Me.btnRoom.Text = "🏠  Room Details"
        Me.btnRoom.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnRoom.UseVisualStyleBackColor = True

        Me.btnAnnouncement.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnAnnouncement.Dock = System.Windows.Forms.DockStyle.Top
        Me.btnAnnouncement.FlatAppearance.BorderSize = 0
        Me.btnAnnouncement.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(52, Byte), Integer), CType(CType(152, Byte), Integer), CType(CType(219, Byte), Integer))
        Me.btnAnnouncement.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnAnnouncement.Font = New System.Drawing.Font("Segoe UI", 10.5!)
        Me.btnAnnouncement.ForeColor = System.Drawing.Color.White
        Me.btnAnnouncement.Location = New System.Drawing.Point(0, 350)
        Me.btnAnnouncement.Name = "btnAnnouncement"
        Me.btnAnnouncement.Padding = New System.Windows.Forms.Padding(30, 0, 0, 0)
        Me.btnAnnouncement.Size = New System.Drawing.Size(250, 50)
        Me.btnAnnouncement.TabIndex = 4
        Me.btnAnnouncement.Text = "📢  Announcements"
        Me.btnAnnouncement.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnAnnouncement.UseVisualStyleBackColor = True

        Me.btnReports.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnReports.Dock = System.Windows.Forms.DockStyle.Top
        Me.btnReports.FlatAppearance.BorderSize = 0
        Me.btnReports.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(52, Byte), Integer), CType(CType(152, Byte), Integer), CType(CType(219, Byte), Integer))
        Me.btnReports.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnReports.Font = New System.Drawing.Font("Segoe UI", 10.5!)
        Me.btnReports.ForeColor = System.Drawing.Color.White
        Me.btnReports.Location = New System.Drawing.Point(0, 300)
        Me.btnReports.Name = "btnReports"
        Me.btnReports.Padding = New System.Windows.Forms.Padding(30, 0, 0, 0)
        Me.btnReports.Size = New System.Drawing.Size(250, 50)
        Me.btnReports.TabIndex = 3
        Me.btnReports.Text = "📊  Reports"
        Me.btnReports.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnReports.UseVisualStyleBackColor = True

        Me.btnBilling.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnBilling.Dock = System.Windows.Forms.DockStyle.Top
        Me.btnBilling.FlatAppearance.BorderSize = 0
        Me.btnBilling.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(52, Byte), Integer), CType(CType(152, Byte), Integer), CType(CType(219, Byte), Integer))
        Me.btnBilling.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnBilling.Font = New System.Drawing.Font("Segoe UI", 10.5!)
        Me.btnBilling.ForeColor = System.Drawing.Color.White
        Me.btnBilling.Location = New System.Drawing.Point(0, 250)
        Me.btnBilling.Name = "btnBilling"
        Me.btnBilling.Padding = New System.Windows.Forms.Padding(30, 0, 0, 0)
        Me.btnBilling.Size = New System.Drawing.Size(250, 50)
        Me.btnBilling.TabIndex = 2
        Me.btnBilling.Text = "💳  Billing"
        Me.btnBilling.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnBilling.UseVisualStyleBackColor = True

        Me.btnPayment.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnPayment.Dock = System.Windows.Forms.DockStyle.Top
        Me.btnPayment.FlatAppearance.BorderSize = 0
        Me.btnPayment.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(52, Byte), Integer), CType(CType(152, Byte), Integer), CType(CType(219, Byte), Integer))
        Me.btnPayment.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnPayment.Font = New System.Drawing.Font("Segoe UI", 10.5!)
        Me.btnPayment.ForeColor = System.Drawing.Color.White
        Me.btnPayment.Location = New System.Drawing.Point(0, 200)
        Me.btnPayment.Name = "btnPayment"
        Me.btnPayment.Padding = New System.Windows.Forms.Padding(30, 0, 0, 0)
        Me.btnPayment.Size = New System.Drawing.Size(250, 50)
        Me.btnPayment.TabIndex = 9
        Me.btnPayment.Text = "💰  Payment"
        Me.btnPayment.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnPayment.UseVisualStyleBackColor = True

        Me.btnManageUsers.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnManageUsers.Dock = System.Windows.Forms.DockStyle.Top
        Me.btnManageUsers.FlatAppearance.BorderSize = 0
        Me.btnManageUsers.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(52, Byte), Integer), CType(CType(152, Byte), Integer), CType(CType(219, Byte), Integer))
        Me.btnManageUsers.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnManageUsers.Font = New System.Drawing.Font("Segoe UI", 10.5!)
        Me.btnManageUsers.ForeColor = System.Drawing.Color.White
        Me.btnManageUsers.Location = New System.Drawing.Point(0, 150)
        Me.btnManageUsers.Name = "btnManageUsers"
        Me.btnManageUsers.Padding = New System.Windows.Forms.Padding(30, 0, 0, 0)
        Me.btnManageUsers.Size = New System.Drawing.Size(250, 50)
        Me.btnManageUsers.TabIndex = 8
        Me.btnManageUsers.Text = "🛡️  Manage Users"
        Me.btnManageUsers.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnManageUsers.UseVisualStyleBackColor = True

        Me.btnTenantMgmt.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnTenantMgmt.Dock = System.Windows.Forms.DockStyle.Top
        Me.btnTenantMgmt.FlatAppearance.BorderSize = 0
        Me.btnTenantMgmt.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(52, Byte), Integer), CType(CType(152, Byte), Integer), CType(CType(219, Byte), Integer))
        Me.btnTenantMgmt.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnTenantMgmt.Font = New System.Drawing.Font("Segoe UI", 10.5!)
        Me.btnTenantMgmt.ForeColor = System.Drawing.Color.White
        Me.btnTenantMgmt.Location = New System.Drawing.Point(0, 100)
        Me.btnTenantMgmt.Name = "btnTenantMgmt"
        Me.btnTenantMgmt.Padding = New System.Windows.Forms.Padding(30, 0, 0, 0)
        Me.btnTenantMgmt.Size = New System.Drawing.Size(250, 50)
        Me.btnTenantMgmt.TabIndex = 1
        Me.btnTenantMgmt.Text = "👥  Tenant Management"
        Me.btnTenantMgmt.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnTenantMgmt.UseVisualStyleBackColor = True

        Me.Panel2.Controls.Add(Me.lblWelcome)
        Me.Panel2.Controls.Add(Me.lblAppName)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel2.Location = New System.Drawing.Point(0, 0)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(250, 100)
        Me.Panel2.TabIndex = 0

        Me.lblWelcome.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.lblWelcome.ForeColor = System.Drawing.Color.FromArgb(CType(CType(180, Byte), Integer), CType(CType(215, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.lblWelcome.Location = New System.Drawing.Point(0, 60)
        Me.lblWelcome.Name = "lblWelcome"
        Me.lblWelcome.Size = New System.Drawing.Size(250, 25)
        Me.lblWelcome.TabIndex = 0
        Me.lblWelcome.Text = "Welcome, Admin!"
        Me.lblWelcome.TextAlign = System.Drawing.ContentAlignment.MiddleCenter

        Me.lblAppName.Font = New System.Drawing.Font("Segoe UI", 14.0!, System.Drawing.FontStyle.Bold)
        Me.lblAppName.ForeColor = System.Drawing.Color.White
        Me.lblAppName.Location = New System.Drawing.Point(0, 20)
        Me.lblAppName.Name = "lblAppName"
        Me.lblAppName.Size = New System.Drawing.Size(250, 40)
        Me.lblAppName.TabIndex = 1
        Me.lblAppName.Text = "🏠 Cristina's Place"
        Me.lblAppName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter

        Me.pnlHeader.BackColor = System.Drawing.Color.White
        Me.pnlHeader.Controls.Add(Me.pnlColorAvailable)
        Me.pnlHeader.Controls.Add(Me.lblLegendAvailable)
        Me.pnlHeader.Controls.Add(Me.pnlColorOccupied)
        Me.pnlHeader.Controls.Add(Me.lblLegendOccupied)
        Me.pnlHeader.Controls.Add(Me.pnlColorPending)
        Me.pnlHeader.Controls.Add(Me.lblLegendPending)
        Me.pnlHeader.Controls.Add(Me.pnlColorMaintenance)
        Me.pnlHeader.Controls.Add(Me.lblLegendMaintenance)
        Me.pnlHeader.Controls.Add(Me.lblDate)
        Me.pnlHeader.Controls.Add(Me.lblPageTitle)
        Me.pnlHeader.Controls.Add(Me.cmbFloorFilter)
        Me.pnlHeader.Controls.Add(Me.Panel4)
        Me.pnlHeader.Controls.Add(Me.Panel3)
        Me.pnlHeader.Controls.Add(Me.Panel1)
        Me.pnlHeader.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlHeader.Location = New System.Drawing.Point(250, 0)
        Me.pnlHeader.Name = "pnlHeader"
        Me.pnlHeader.Padding = New System.Windows.Forms.Padding(20)
        Me.pnlHeader.Size = New System.Drawing.Size(1034, 150)
        Me.pnlHeader.TabIndex = 1

        Me.lblDate.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblDate.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold)
        Me.lblDate.ForeColor = System.Drawing.Color.Gray
        Me.lblDate.Location = New System.Drawing.Point(550, 15)
        Me.lblDate.Name = "lblDate"
        Me.lblDate.Size = New System.Drawing.Size(460, 20)
        Me.lblDate.TabIndex = 4
        Me.lblDate.Text = "Loading Date..."
        Me.lblDate.TextAlign = System.Drawing.ContentAlignment.MiddleRight

        Me.pnlColorAvailable.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.pnlColorAvailable.BackColor = System.Drawing.Color.SeaGreen
        Me.pnlColorAvailable.Location = New System.Drawing.Point(850, 45)
        Me.pnlColorAvailable.Name = "pnlColorAvailable"
        Me.pnlColorAvailable.Size = New System.Drawing.Size(15, 15)
        Me.pnlColorAvailable.TabIndex = 8

        Me.lblLegendAvailable.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblLegendAvailable.AutoSize = True
        Me.lblLegendAvailable.BackColor = System.Drawing.Color.Transparent
        Me.lblLegendAvailable.Font = New System.Drawing.Font("Segoe UI", 9.5!)
        Me.lblLegendAvailable.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblLegendAvailable.Location = New System.Drawing.Point(870, 43)
        Me.lblLegendAvailable.Name = "lblLegendAvailable"
        Me.lblLegendAvailable.Size = New System.Drawing.Size(60, 17)
        Me.lblLegendAvailable.TabIndex = 5
        Me.lblLegendAvailable.Text = "Available"

        Me.pnlColorOccupied.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.pnlColorOccupied.BackColor = System.Drawing.Color.IndianRed
        Me.pnlColorOccupied.Location = New System.Drawing.Point(850, 70)
        Me.pnlColorOccupied.Name = "pnlColorOccupied"
        Me.pnlColorOccupied.Size = New System.Drawing.Size(15, 15)
        Me.pnlColorOccupied.TabIndex = 9

        Me.lblLegendOccupied.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblLegendOccupied.AutoSize = True
        Me.lblLegendOccupied.BackColor = System.Drawing.Color.Transparent
        Me.lblLegendOccupied.Font = New System.Drawing.Font("Segoe UI", 9.5!)
        Me.lblLegendOccupied.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblLegendOccupied.Location = New System.Drawing.Point(870, 68)
        Me.lblLegendOccupied.Name = "lblLegendOccupied"
        Me.lblLegendOccupied.Size = New System.Drawing.Size(63, 17)
        Me.lblLegendOccupied.TabIndex = 6
        Me.lblLegendOccupied.Text = "Occupied"

        Me.pnlColorPending.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.pnlColorPending.BackColor = System.Drawing.Color.DarkOrange
        Me.pnlColorPending.Location = New System.Drawing.Point(850, 95)
        Me.pnlColorPending.Name = "pnlColorPending"
        Me.pnlColorPending.Size = New System.Drawing.Size(15, 15)
        Me.pnlColorPending.TabIndex = 11

        Me.lblLegendPending.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblLegendPending.AutoSize = True
        Me.lblLegendPending.BackColor = System.Drawing.Color.Transparent
        Me.lblLegendPending.Font = New System.Drawing.Font("Segoe UI", 9.5!)
        Me.lblLegendPending.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblLegendPending.Location = New System.Drawing.Point(870, 93)
        Me.lblLegendPending.Name = "lblLegendPending"
        Me.lblLegendPending.Size = New System.Drawing.Size(78, 17)
        Me.lblLegendPending.TabIndex = 12
        Me.lblLegendPending.Text = "Pending Bill"

        Me.pnlColorMaintenance.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.pnlColorMaintenance.BackColor = System.Drawing.Color.Gold
        Me.pnlColorMaintenance.Location = New System.Drawing.Point(850, 120)
        Me.pnlColorMaintenance.Name = "pnlColorMaintenance"
        Me.pnlColorMaintenance.Size = New System.Drawing.Size(15, 15)
        Me.pnlColorMaintenance.TabIndex = 10

        Me.lblLegendMaintenance.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblLegendMaintenance.AutoSize = True
        Me.lblLegendMaintenance.BackColor = System.Drawing.Color.Transparent
        Me.lblLegendMaintenance.Font = New System.Drawing.Font("Segoe UI", 9.5!)
        Me.lblLegendMaintenance.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblLegendMaintenance.Location = New System.Drawing.Point(870, 118)
        Me.lblLegendMaintenance.Name = "lblLegendMaintenance"
        Me.lblLegendMaintenance.Size = New System.Drawing.Size(123, 17)
        Me.lblLegendMaintenance.TabIndex = 7
        Me.lblLegendMaintenance.Text = "Maintenance Room"

        Me.lblPageTitle.AutoSize = True
        Me.lblPageTitle.Font = New System.Drawing.Font("Segoe UI", 16.0!, System.Drawing.FontStyle.Bold)
        Me.lblPageTitle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(44, Byte), Integer), CType(CType(62, Byte), Integer), CType(CType(80, Byte), Integer))
        Me.lblPageTitle.Location = New System.Drawing.Point(20, 15)
        Me.lblPageTitle.Name = "lblPageTitle"
        Me.lblPageTitle.Size = New System.Drawing.Size(177, 30)
        Me.lblPageTitle.TabIndex = 3
        Me.lblPageTitle.Text = "Room Overview"

        Me.cmbFloorFilter.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbFloorFilter.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.cmbFloorFilter.FormattingEnabled = True
        Me.cmbFloorFilter.Location = New System.Drawing.Point(25, 95)
        Me.cmbFloorFilter.Name = "cmbFloorFilter"
        Me.cmbFloorFilter.Size = New System.Drawing.Size(180, 25)
        Me.cmbFloorFilter.TabIndex = 2

        Me.Panel4.BackColor = System.Drawing.Color.Gold
        Me.Panel4.Controls.Add(Me.lblCleaningCount)
        Me.Panel4.Controls.Add(Me.Label5)
        Me.Panel4.Location = New System.Drawing.Point(575, 45)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(160, 85)
        Me.Panel4.TabIndex = 1

        Me.lblCleaningCount.Font = New System.Drawing.Font("Segoe UI", 22.0!, System.Drawing.FontStyle.Bold)
        Me.lblCleaningCount.ForeColor = System.Drawing.Color.Black
        Me.lblCleaningCount.Location = New System.Drawing.Point(0, 35)
        Me.lblCleaningCount.Name = "lblCleaningCount"
        Me.lblCleaningCount.Size = New System.Drawing.Size(160, 40)
        Me.lblCleaningCount.TabIndex = 5
        Me.lblCleaningCount.Text = "0"
        Me.lblCleaningCount.TextAlign = System.Drawing.ContentAlignment.MiddleCenter

        Me.Label5.Font = New System.Drawing.Font("Segoe UI", 9.5!)
        Me.Label5.ForeColor = System.Drawing.Color.Black
        Me.Label5.Location = New System.Drawing.Point(0, 10)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(160, 20)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Maintenance Room"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter

        Me.Panel3.BackColor = System.Drawing.Color.SeaGreen
        Me.Panel3.Controls.Add(Me.lblAvailableCount)
        Me.Panel3.Controls.Add(Me.availbale)
        Me.Panel3.Location = New System.Drawing.Point(400, 45)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(160, 85)
        Me.Panel3.TabIndex = 1

        Me.lblAvailableCount.Font = New System.Drawing.Font("Segoe UI", 22.0!, System.Drawing.FontStyle.Bold)
        Me.lblAvailableCount.ForeColor = System.Drawing.Color.White
        Me.lblAvailableCount.Location = New System.Drawing.Point(0, 35)
        Me.lblAvailableCount.Name = "lblAvailableCount"
        Me.lblAvailableCount.Size = New System.Drawing.Size(160, 40)
        Me.lblAvailableCount.TabIndex = 3
        Me.lblAvailableCount.Text = "0"
        Me.lblAvailableCount.TextAlign = System.Drawing.ContentAlignment.MiddleCenter

        Me.availbale.Font = New System.Drawing.Font("Segoe UI", 9.5!)
        Me.availbale.ForeColor = System.Drawing.Color.White
        Me.availbale.Location = New System.Drawing.Point(0, 10)
        Me.availbale.Name = "availbale"
        Me.availbale.Size = New System.Drawing.Size(160, 20)
        Me.availbale.TabIndex = 2
        Me.availbale.Text = "Available Rooms"
        Me.availbale.TextAlign = System.Drawing.ContentAlignment.MiddleCenter

        Me.Panel1.BackColor = System.Drawing.Color.IndianRed
        Me.Panel1.Controls.Add(Me.lblOccupiedCount)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Location = New System.Drawing.Point(225, 45)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(160, 85)
        Me.Panel1.TabIndex = 0

        Me.lblOccupiedCount.Font = New System.Drawing.Font("Segoe UI", 22.0!, System.Drawing.FontStyle.Bold)
        Me.lblOccupiedCount.ForeColor = System.Drawing.Color.White
        Me.lblOccupiedCount.Location = New System.Drawing.Point(0, 35)
        Me.lblOccupiedCount.Name = "lblOccupiedCount"
        Me.lblOccupiedCount.Size = New System.Drawing.Size(160, 40)
        Me.lblOccupiedCount.TabIndex = 1
        Me.lblOccupiedCount.Text = "0"
        Me.lblOccupiedCount.TextAlign = System.Drawing.ContentAlignment.MiddleCenter

        Me.Label1.Font = New System.Drawing.Font("Segoe UI", 9.5!)
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(0, 10)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(160, 20)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Occupied Rooms"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter

        Me.pnlMain.BackColor = System.Drawing.Color.FromArgb(CType(CType(245, Byte), Integer), CType(CType(247, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.pnlMain.Controls.Add(Me.flpRooms)
        Me.pnlMain.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlMain.Location = New System.Drawing.Point(250, 150)
        Me.pnlMain.Name = "pnlMain"
        Me.pnlMain.Padding = New System.Windows.Forms.Padding(20)
        Me.pnlMain.Size = New System.Drawing.Size(1034, 599)
        Me.pnlMain.TabIndex = 2

        Me.flpRooms.AutoScroll = True
        Me.flpRooms.BackColor = System.Drawing.Color.Transparent
        Me.flpRooms.Dock = System.Windows.Forms.DockStyle.Fill
        Me.flpRooms.Location = New System.Drawing.Point(20, 20)
        Me.flpRooms.Name = "flpRooms"
        Me.flpRooms.Size = New System.Drawing.Size(994, 559)
        Me.flpRooms.TabIndex = 0

        Me.tmrDate.Enabled = True
        Me.tmrDate.Interval = 1000

        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 17.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(245, Byte), Integer), CType(CType(247, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(1284, 749)
        Me.Controls.Add(Me.pnlMain)
        Me.Controls.Add(Me.pnlHeader)
        Me.Controls.Add(Me.pnlSidebar)
        Me.Font = New System.Drawing.Font("Segoe UI", 9.75!)
        Me.Name = "frmDashboard"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Cristina's Place - Dashboard"
        Me.pnlSidebar.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        Me.pnlHeader.ResumeLayout(False)
        Me.pnlHeader.PerformLayout()
        Me.Panel4.ResumeLayout(False)
        Me.Panel3.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.pnlMain.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents pnlSidebar As Panel
    Friend WithEvents Panel2 As Panel
    Friend WithEvents lblAppName As Label
    Friend WithEvents lblWelcome As Label
    Friend WithEvents btnAnnouncement As Button
    Friend WithEvents btnReports As Button
    Friend WithEvents btnBilling As Button
    Friend WithEvents btnPayment As Button
    Friend WithEvents btnManageUsers As Button
    Friend WithEvents btnTenantMgmt As Button
    Friend WithEvents pnlHeader As Panel
    Friend WithEvents lblPageTitle As Label
    Friend WithEvents lblDate As Label
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Panel4 As Panel
    Friend WithEvents lblCleaningCount As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Panel3 As Panel
    Friend WithEvents lblAvailableCount As Label
    Friend WithEvents availbale As Label
    Friend WithEvents lblOccupiedCount As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents pnlMain As Panel
    Friend WithEvents flpRooms As FlowLayoutPanel
    Friend WithEvents btnLogout As Button
    Friend WithEvents btnRoom As Button
    Friend WithEvents cmbFloorFilter As ComboBox
    Friend WithEvents tmrDate As Timer
    Friend WithEvents lblLegendAvailable As Label
    Friend WithEvents lblLegendOccupied As Label
    Friend WithEvents lblLegendMaintenance As Label
    Friend WithEvents pnlColorAvailable As Panel
    Friend WithEvents pnlColorOccupied As Panel
    Friend WithEvents pnlColorMaintenance As Panel
    Friend WithEvents lblLegendPending As Label
    Friend WithEvents pnlColorPending As Panel
End Class