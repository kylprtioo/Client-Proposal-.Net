﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmTenantMgmt
    Inherits System.Windows.Forms.Form

    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    Private components As System.ComponentModel.IContainer

    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.tcDetails = New System.Windows.Forms.TabControl()
        Me.tpPersonal = New System.Windows.Forms.TabPage()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.txtFirst = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtMiddle = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtLast = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtContact = New System.Windows.Forms.TextBox()
        Me.lblEmail = New System.Windows.Forms.Label()
        Me.txtEmail = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.dtpBirthday = New System.Windows.Forms.DateTimePicker()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtOccupants = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.dtpStartDate = New System.Windows.Forms.DateTimePicker()
        Me.tpRoom = New System.Windows.Forms.TabPage()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.cmbFloor = New System.Windows.Forms.ComboBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.cmbRoom = New System.Windows.Forms.ComboBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.txtRent = New System.Windows.Forms.TextBox()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.chkVehicle = New System.Windows.Forms.CheckBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.txtVehicleModel = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.txtYearColor = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.txtPlateNo = New System.Windows.Forms.TextBox()
        Me.chkPet = New System.Windows.Forms.CheckBox()
        Me.btnSave = New System.Windows.Forms.Button()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.txtSearch = New System.Windows.Forms.TextBox()
        Me.btnRefresh = New System.Windows.Forms.Button()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.btnUpdate = New System.Windows.Forms.Button()
        Me.btnCheckout = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnDelete = New System.Windows.Forms.Button()
        Me.dgvTenants = New System.Windows.Forms.DataGridView()
        Me.Panel1.SuspendLayout()
        Me.tcDetails.SuspendLayout()
        Me.tpPersonal.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.tpRoom.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.Panel3.SuspendLayout()
        CType(Me.dgvTenants, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.White
        Me.Panel1.Controls.Add(Me.tcDetails)
        Me.Panel1.Controls.Add(Me.btnSave)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(360, 749)
        Me.Panel1.TabIndex = 0
        '
        'tcDetails
        '
        Me.tcDetails.Controls.Add(Me.tpPersonal)
        Me.tcDetails.Controls.Add(Me.tpRoom)
        Me.tcDetails.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.tcDetails.Location = New System.Drawing.Point(12, 12)
        Me.tcDetails.Name = "tcDetails"
        Me.tcDetails.SelectedIndex = 0
        Me.tcDetails.Size = New System.Drawing.Size(335, 660)
        Me.tcDetails.TabIndex = 6
        '
        'tpPersonal
        '
        Me.tpPersonal.Controls.Add(Me.GroupBox1)
        Me.tpPersonal.Location = New System.Drawing.Point(4, 26)
        Me.tpPersonal.Name = "tpPersonal"
        Me.tpPersonal.Padding = New System.Windows.Forms.Padding(3)
        Me.tpPersonal.Size = New System.Drawing.Size(327, 630)
        Me.tpPersonal.TabIndex = 0
        Me.tpPersonal.Text = "Personal Info"
        Me.tpPersonal.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Label14)
        Me.GroupBox1.Controls.Add(Me.txtFirst)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.txtMiddle)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.txtLast)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.txtContact)
        Me.GroupBox1.Controls.Add(Me.lblEmail)
        Me.GroupBox1.Controls.Add(Me.txtEmail)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.dtpBirthday)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.txtOccupants)
        Me.GroupBox1.Controls.Add(Me.Label13)
        Me.GroupBox1.Controls.Add(Me.dtpStartDate)
        Me.GroupBox1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.GroupBox1.Font = New System.Drawing.Font("Segoe UI Semibold", 11.25!, System.Drawing.FontStyle.Bold)
        Me.GroupBox1.ForeColor = System.Drawing.Color.FromArgb(31, 41, 55)
        Me.GroupBox1.Location = New System.Drawing.Point(3, 3)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(321, 624)
        Me.GroupBox1.TabIndex = 1
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Tenant Details"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Segoe UI", 9.75!)
        Me.Label14.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139)
        Me.Label14.Location = New System.Drawing.Point(20, 40)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(74, 17)
        Me.Label14.TabIndex = 12
        Me.Label14.Text = "First Name:"
        '
        'txtFirst
        '
        Me.txtFirst.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.txtFirst.Location = New System.Drawing.Point(23, 60)
        Me.txtFirst.Name = "txtFirst"
        Me.txtFirst.Size = New System.Drawing.Size(275, 25)
        Me.txtFirst.TabIndex = 11
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Segoe UI", 9.75!)
        Me.Label1.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139)
        Me.Label1.Location = New System.Drawing.Point(20, 100)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(91, 17)
        Me.Label1.TabIndex = 13
        Me.Label1.Text = "Middle Name:"
        '
        'txtMiddle
        '
        Me.txtMiddle.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.txtMiddle.Location = New System.Drawing.Point(23, 120)
        Me.txtMiddle.Name = "txtMiddle"
        Me.txtMiddle.Size = New System.Drawing.Size(275, 25)
        Me.txtMiddle.TabIndex = 14
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Segoe UI", 9.75!)
        Me.Label2.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139)
        Me.Label2.Location = New System.Drawing.Point(20, 160)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(73, 17)
        Me.Label2.TabIndex = 10
        Me.Label2.Text = "Last Name:"
        '
        'txtLast
        '
        Me.txtLast.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.txtLast.Location = New System.Drawing.Point(23, 180)
        Me.txtLast.Name = "txtLast"
        Me.txtLast.Size = New System.Drawing.Size(275, 25)
        Me.txtLast.TabIndex = 1
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Segoe UI", 9.75!)
        Me.Label3.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139)
        Me.Label3.Location = New System.Drawing.Point(20, 220)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(77, 17)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Contact No:"
        '
        'txtContact
        '
        Me.txtContact.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.txtContact.Location = New System.Drawing.Point(23, 240)
        Me.txtContact.Name = "txtContact"
        Me.txtContact.Size = New System.Drawing.Size(275, 25)
        Me.txtContact.TabIndex = 3
        '
        'lblEmail
        '
        Me.lblEmail.AutoSize = True
        Me.lblEmail.Font = New System.Drawing.Font("Segoe UI", 9.75!)
        Me.lblEmail.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139)
        Me.lblEmail.Location = New System.Drawing.Point(20, 280)
        Me.lblEmail.Name = "lblEmail"
        Me.lblEmail.Size = New System.Drawing.Size(94, 17)
        Me.lblEmail.TabIndex = 15
        Me.lblEmail.Text = "Email Address:"
        '
        'txtEmail
        '
        Me.txtEmail.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.txtEmail.Location = New System.Drawing.Point(23, 300)
        Me.txtEmail.Name = "txtEmail"
        Me.txtEmail.Size = New System.Drawing.Size(275, 25)
        Me.txtEmail.TabIndex = 16
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Segoe UI", 9.75!)
        Me.Label4.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139)
        Me.Label4.Location = New System.Drawing.Point(20, 340)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(58, 17)
        Me.Label4.TabIndex = 4
        Me.Label4.Text = "Birthday:"
        '
        'dtpBirthday
        '
        Me.dtpBirthday.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.dtpBirthday.Format = System.Windows.Forms.DateTimePickerFormat.Short
        Me.dtpBirthday.Location = New System.Drawing.Point(23, 360)
        Me.dtpBirthday.Name = "dtpBirthday"
        Me.dtpBirthday.Size = New System.Drawing.Size(275, 25)
        Me.dtpBirthday.TabIndex = 5
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Segoe UI", 9.75!)
        Me.Label5.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139)
        Me.Label5.Location = New System.Drawing.Point(20, 400)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(142, 17)
        Me.Label5.TabIndex = 6
        Me.Label5.Text = "Number of Occupants:"
        '
        'txtOccupants
        '
        Me.txtOccupants.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.txtOccupants.Location = New System.Drawing.Point(23, 420)
        Me.txtOccupants.Name = "txtOccupants"
        Me.txtOccupants.Size = New System.Drawing.Size(275, 25)
        Me.txtOccupants.TabIndex = 7
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Segoe UI", 9.75!)
        Me.Label13.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139)
        Me.Label13.Location = New System.Drawing.Point(20, 460)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(69, 17)
        Me.Label13.TabIndex = 8
        Me.Label13.Text = "Start Date:"
        '
        'dtpStartDate
        '
        Me.dtpStartDate.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.dtpStartDate.Format = System.Windows.Forms.DateTimePickerFormat.Short
        Me.dtpStartDate.Location = New System.Drawing.Point(23, 480)
        Me.dtpStartDate.Name = "dtpStartDate"
        Me.dtpStartDate.Size = New System.Drawing.Size(275, 25)
        Me.dtpStartDate.TabIndex = 9
        '
        'tpRoom
        '
        Me.tpRoom.Controls.Add(Me.GroupBox2)
        Me.tpRoom.Controls.Add(Me.GroupBox3)
        Me.tpRoom.Location = New System.Drawing.Point(4, 26)
        Me.tpRoom.Name = "tpRoom"
        Me.tpRoom.Padding = New System.Windows.Forms.Padding(3)
        Me.tpRoom.Size = New System.Drawing.Size(327, 630)
        Me.tpRoom.TabIndex = 1
        Me.tpRoom.Text = "Room & Extras"
        Me.tpRoom.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.Label6)
        Me.GroupBox2.Controls.Add(Me.cmbFloor)
        Me.GroupBox2.Controls.Add(Me.Label7)
        Me.GroupBox2.Controls.Add(Me.cmbRoom)
        Me.GroupBox2.Controls.Add(Me.Label8)
        Me.GroupBox2.Controls.Add(Me.txtRent)
        Me.GroupBox2.Font = New System.Drawing.Font("Segoe UI Semibold", 11.25!, System.Drawing.FontStyle.Bold)
        Me.GroupBox2.ForeColor = System.Drawing.Color.FromArgb(31, 41, 55)
        Me.GroupBox2.Location = New System.Drawing.Point(13, 15)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(300, 215)
        Me.GroupBox2.TabIndex = 2
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Room Assignment"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Segoe UI", 9.75!)
        Me.Label6.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139)
        Me.Label6.Location = New System.Drawing.Point(17, 35)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(97, 17)
        Me.Label6.TabIndex = 0
        Me.Label6.Text = "Assigned Floor:"
        '
        'cmbFloor
        '
        Me.cmbFloor.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.cmbFloor.FormattingEnabled = True
        Me.cmbFloor.Location = New System.Drawing.Point(20, 55)
        Me.cmbFloor.Name = "cmbFloor"
        Me.cmbFloor.Size = New System.Drawing.Size(260, 25)
        Me.cmbFloor.TabIndex = 2
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Segoe UI", 9.75!)
        Me.Label7.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139)
        Me.Label7.Location = New System.Drawing.Point(17, 95)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(103, 17)
        Me.Label7.TabIndex = 1
        Me.Label7.Text = "Assigned Room:"
        '
        'cmbRoom
        '
        Me.cmbRoom.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.cmbRoom.FormattingEnabled = True
        Me.cmbRoom.Location = New System.Drawing.Point(20, 115)
        Me.cmbRoom.Name = "cmbRoom"
        Me.cmbRoom.Size = New System.Drawing.Size(260, 25)
        Me.cmbRoom.TabIndex = 3
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Segoe UI", 9.75!)
        Me.Label8.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139)
        Me.Label8.Location = New System.Drawing.Point(17, 155)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(68, 17)
        Me.Label8.TabIndex = 4
        Me.Label8.Text = "Base Rent:"
        '
        'txtRent
        '
        Me.txtRent.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.txtRent.Location = New System.Drawing.Point(20, 175)
        Me.txtRent.Name = "txtRent"
        Me.txtRent.Size = New System.Drawing.Size(260, 25)
        Me.txtRent.TabIndex = 8
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.chkVehicle)
        Me.GroupBox3.Controls.Add(Me.Label9)
        Me.GroupBox3.Controls.Add(Me.txtVehicleModel)
        Me.GroupBox3.Controls.Add(Me.Label10)
        Me.GroupBox3.Controls.Add(Me.txtYearColor)
        Me.GroupBox3.Controls.Add(Me.Label11)
        Me.GroupBox3.Controls.Add(Me.txtPlateNo)
        Me.GroupBox3.Controls.Add(Me.chkPet)
        Me.GroupBox3.Font = New System.Drawing.Font("Segoe UI Semibold", 11.25!, System.Drawing.FontStyle.Bold)
        Me.GroupBox3.ForeColor = System.Drawing.Color.FromArgb(31, 41, 55)
        Me.GroupBox3.Location = New System.Drawing.Point(13, 245)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(300, 300)
        Me.GroupBox3.TabIndex = 3
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Vehicles and Pets"
        '
        'chkVehicle
        '
        Me.chkVehicle.AutoSize = True
        Me.chkVehicle.Font = New System.Drawing.Font("Segoe UI", 9.75!)
        Me.chkVehicle.Location = New System.Drawing.Point(20, 35)
        Me.chkVehicle.Name = "chkVehicle"
        Me.chkVehicle.Size = New System.Drawing.Size(161, 21)
        Me.chkVehicle.TabIndex = 0
        Me.chkVehicle.Text = "Do you have a vehicle?"
        Me.chkVehicle.UseVisualStyleBackColor = True
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Segoe UI", 9.75!)
        Me.Label9.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139)
        Me.Label9.Location = New System.Drawing.Point(17, 70)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(92, 17)
        Me.Label9.TabIndex = 1
        Me.Label9.Text = "Vehicle Model:"
        '
        'txtVehicleModel
        '
        Me.txtVehicleModel.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.txtVehicleModel.Location = New System.Drawing.Point(20, 90)
        Me.txtVehicleModel.Name = "txtVehicleModel"
        Me.txtVehicleModel.Size = New System.Drawing.Size(260, 25)
        Me.txtVehicleModel.TabIndex = 2
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Segoe UI", 9.75!)
        Me.Label10.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139)
        Me.Label10.Location = New System.Drawing.Point(17, 130)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(73, 17)
        Me.Label10.TabIndex = 3
        Me.Label10.Text = "Year/Color:"
        '
        'txtYearColor
        '
        Me.txtYearColor.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.txtYearColor.Location = New System.Drawing.Point(20, 150)
        Me.txtYearColor.Name = "txtYearColor"
        Me.txtYearColor.Size = New System.Drawing.Size(260, 25)
        Me.txtYearColor.TabIndex = 5
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Segoe UI", 9.75!)
        Me.Label11.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139)
        Me.Label11.Location = New System.Drawing.Point(17, 190)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(61, 17)
        Me.Label11.TabIndex = 4
        Me.Label11.Text = "Plate No:"
        '
        'txtPlateNo
        '
        Me.txtPlateNo.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.txtPlateNo.Location = New System.Drawing.Point(20, 210)
        Me.txtPlateNo.Name = "txtPlateNo"
        Me.txtPlateNo.Size = New System.Drawing.Size(260, 25)
        Me.txtPlateNo.TabIndex = 6
        '
        'chkPet
        '
        Me.chkPet.AutoSize = True
        Me.chkPet.Font = New System.Drawing.Font("Segoe UI", 9.75!)
        Me.chkPet.Location = New System.Drawing.Point(20, 260)
        Me.chkPet.Name = "chkPet"
        Me.chkPet.Size = New System.Drawing.Size(140, 21)
        Me.chkPet.TabIndex = 7
        Me.chkPet.Text = "Do you have a pet?"
        Me.chkPet.UseVisualStyleBackColor = True
        '
        'btnSave
        '
        Me.btnSave.BackColor = System.Drawing.Color.FromArgb(31, 97, 141)
        Me.btnSave.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnSave.FlatAppearance.BorderSize = 0
        Me.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnSave.Font = New System.Drawing.Font("Segoe UI", 11.25!, System.Drawing.FontStyle.Bold)
        Me.btnSave.ForeColor = System.Drawing.Color.White
        Me.btnSave.Location = New System.Drawing.Point(30, 685)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(300, 45)
        Me.btnSave.TabIndex = 5
        Me.btnSave.Text = "Save Tenant"
        Me.btnSave.UseVisualStyleBackColor = False
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.White
        Me.Panel2.Controls.Add(Me.Label12)
        Me.Panel2.Controls.Add(Me.txtSearch)
        Me.Panel2.Controls.Add(Me.btnRefresh)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel2.Location = New System.Drawing.Point(360, 0)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(711, 70)
        Me.Panel2.TabIndex = 6
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Segoe UI Semibold", 12.0!, System.Drawing.FontStyle.Bold)
        Me.Label12.ForeColor = System.Drawing.Color.FromArgb(31, 41, 55)
        Me.Label12.Location = New System.Drawing.Point(20, 24)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(63, 21)
        Me.Label12.TabIndex = 3
        Me.Label12.Text = "Search:"
        '
        'txtSearch
        '
        Me.txtSearch.Font = New System.Drawing.Font("Segoe UI", 11.0!)
        Me.txtSearch.Location = New System.Drawing.Point(90, 22)
        Me.txtSearch.Name = "txtSearch"
        Me.txtSearch.Size = New System.Drawing.Size(300, 27)
        Me.txtSearch.TabIndex = 4
        '
        'btnRefresh
        '
        Me.btnRefresh.BackColor = System.Drawing.Color.FromArgb(226, 232, 240)
        Me.btnRefresh.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnRefresh.FlatAppearance.BorderSize = 0
        Me.btnRefresh.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnRefresh.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold)
        Me.btnRefresh.ForeColor = System.Drawing.Color.FromArgb(31, 41, 55)
        Me.btnRefresh.Location = New System.Drawing.Point(405, 20)
        Me.btnRefresh.Name = "btnRefresh"
        Me.btnRefresh.Size = New System.Drawing.Size(100, 30)
        Me.btnRefresh.TabIndex = 5
        Me.btnRefresh.Text = "Refresh"
        Me.btnRefresh.UseVisualStyleBackColor = False
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.White
        Me.Panel3.Controls.Add(Me.btnUpdate)
        Me.Panel3.Controls.Add(Me.btnCheckout)
        Me.Panel3.Controls.Add(Me.btnClear)
        Me.Panel3.Controls.Add(Me.btnDelete)
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel3.Location = New System.Drawing.Point(360, 669)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(711, 80)
        Me.Panel3.TabIndex = 7
        '
        'btnUpdate
        '
        Me.btnUpdate.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnUpdate.BackColor = System.Drawing.Color.FromArgb(31, 97, 141)
        Me.btnUpdate.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnUpdate.FlatAppearance.BorderSize = 0
        Me.btnUpdate.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnUpdate.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold)
        Me.btnUpdate.ForeColor = System.Drawing.Color.White
        Me.btnUpdate.Location = New System.Drawing.Point(180, 20)
        Me.btnUpdate.Name = "btnUpdate"
        Me.btnUpdate.Size = New System.Drawing.Size(120, 40)
        Me.btnUpdate.TabIndex = 0
        Me.btnUpdate.Text = "UPDATE"
        Me.btnUpdate.UseVisualStyleBackColor = False
        '
        'btnCheckout
        '
        Me.btnCheckout.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnCheckout.BackColor = System.Drawing.Color.IndianRed
        Me.btnCheckout.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnCheckout.FlatAppearance.BorderSize = 0
        Me.btnCheckout.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnCheckout.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold)
        Me.btnCheckout.ForeColor = System.Drawing.Color.White
        Me.btnCheckout.Location = New System.Drawing.Point(310, 20)
        Me.btnCheckout.Name = "btnCheckout"
        Me.btnCheckout.Size = New System.Drawing.Size(120, 40)
        Me.btnCheckout.TabIndex = 1
        Me.btnCheckout.Text = "CHECK-OUT"
        Me.btnCheckout.UseVisualStyleBackColor = False
        '
        'btnClear
        '
        Me.btnClear.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnClear.BackColor = System.Drawing.Color.FromArgb(226, 232, 240)
        Me.btnClear.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnClear.FlatAppearance.BorderSize = 0
        Me.btnClear.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnClear.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold)
        Me.btnClear.ForeColor = System.Drawing.Color.FromArgb(31, 41, 55)
        Me.btnClear.Location = New System.Drawing.Point(440, 20)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(120, 40)
        Me.btnClear.TabIndex = 2
        Me.btnClear.Text = "CLEAR"
        Me.btnClear.UseVisualStyleBackColor = False
        '
        'btnDelete
        '
        Me.btnDelete.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnDelete.BackColor = System.Drawing.Color.IndianRed
        Me.btnDelete.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnDelete.FlatAppearance.BorderSize = 0
        Me.btnDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnDelete.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold)
        Me.btnDelete.ForeColor = System.Drawing.Color.White
        Me.btnDelete.Location = New System.Drawing.Point(570, 20)
        Me.btnDelete.Name = "btnDelete"
        Me.btnDelete.Size = New System.Drawing.Size(120, 40)
        Me.btnDelete.TabIndex = 3
        Me.btnDelete.Text = "DELETE"
        Me.btnDelete.UseVisualStyleBackColor = False
        '
        'dgvTenants
        '
        Me.dgvTenants.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.dgvTenants.BackgroundColor = System.Drawing.Color.White
        Me.dgvTenants.BorderStyle = System.Windows.Forms.BorderStyle.None
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(243, 244, 246)
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold)
        DataGridViewCellStyle1.ForeColor = System.Drawing.Color.FromArgb(31, 41, 55)
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.FromArgb(243, 244, 246)
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.FromArgb(31, 41, 55)
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgvTenants.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.dgvTenants.ColumnHeadersHeight = 35
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.Color.White
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Segoe UI", 9.75!)
        DataGridViewCellStyle2.ForeColor = System.Drawing.Color.FromArgb(31, 41, 55)
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(31, 97, 141)
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.White
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgvTenants.DefaultCellStyle = DataGridViewCellStyle2
        Me.dgvTenants.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgvTenants.EnableHeadersVisualStyles = False
        Me.dgvTenants.Location = New System.Drawing.Point(360, 70)
        Me.dgvTenants.Name = "dgvTenants"
        Me.dgvTenants.RowHeadersVisible = False
        Me.dgvTenants.RowTemplate.Height = 30
        Me.dgvTenants.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgvTenants.Size = New System.Drawing.Size(711, 599)
        Me.dgvTenants.TabIndex = 8
        '
        'frmTenantMgmt
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 17.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(243, 244, 246)
        Me.ClientSize = New System.Drawing.Size(1071, 749)
        Me.Controls.Add(Me.dgvTenants)
        Me.Controls.Add(Me.Panel3)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.Font = New System.Drawing.Font("Segoe UI", 9.75!)
        Me.Name = "frmTenantMgmt"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Tenant Management"
        Me.Panel1.ResumeLayout(False)
        Me.tcDetails.ResumeLayout(False)
        Me.tpPersonal.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.tpRoom.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.Panel3.ResumeLayout(False)
        CType(Me.dgvTenants, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents txtVehicleModel As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents chkVehicle As CheckBox
    Friend WithEvents txtOccupants As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents dtpBirthday As DateTimePicker
    Friend WithEvents Label4 As Label
    Friend WithEvents txtContact As TextBox
    Friend WithEvents lblEmail As Label ' BAGONG LABEL PARA SA EMAIL
    Friend WithEvents txtEmail As TextBox ' BAGONG TEXTBOX PARA SA EMAIL
    Friend WithEvents Label3 As Label
    Friend WithEvents txtLast As TextBox
    Friend WithEvents txtRent As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents cmbRoom As ComboBox
    Friend WithEvents cmbFloor As ComboBox
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents btnSave As Button
    Friend WithEvents chkPet As CheckBox
    Friend WithEvents txtPlateNo As TextBox
    Friend WithEvents txtYearColor As TextBox
    Friend WithEvents Label11 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents txtSearch As TextBox
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Panel3 As Panel
    Friend WithEvents btnDelete As Button
    Friend WithEvents btnClear As Button
    Friend WithEvents btnCheckout As Button
    Friend WithEvents btnUpdate As Button
    Friend WithEvents dtpStartDate As DateTimePicker
    Friend WithEvents Label13 As Label
    Friend WithEvents btnRefresh As Button
    Friend WithEvents dgvTenants As DataGridView
    Friend WithEvents Label14 As Label
    Friend WithEvents txtFirst As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents txtMiddle As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents tcDetails As TabControl
    Friend WithEvents tpPersonal As TabPage
    Friend WithEvents tpRoom As TabPage
End Class