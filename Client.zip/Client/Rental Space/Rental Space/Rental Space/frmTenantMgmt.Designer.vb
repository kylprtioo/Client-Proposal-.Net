﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmTenantMgmt
    Inherits System.Windows.Forms.Form

    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    Private components As System.ComponentModel.IContainer

    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As DataGridViewCellStyle = New DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As DataGridViewCellStyle = New DataGridViewCellStyle()
        Panel1 = New Panel()
        tcDetails = New TabControl()
        tpPersonal = New TabPage()
        GroupBox1 = New GroupBox()
        Label14 = New Label()
        txtFirst = New TextBox()
        Label1 = New Label()
        txtMiddle = New TextBox()
        Label2 = New Label()
        txtLast = New TextBox()
        Label3 = New Label()
        txtContact = New TextBox()
        lblEmail = New Label()
        txtEmail = New TextBox()
        Label4 = New Label()
        dtpBirthday = New DateTimePicker()
        Label13 = New Label()
        dtpStartDate = New DateTimePicker()
        lblEndDate = New Label()
        dtpEndDate = New DateTimePicker()
        Label5 = New Label()
        txtOccupants = New TextBox()
        lblOtherNames = New Label()
        txtOtherNames = New TextBox()
        tpRoom = New TabPage()
        GroupBox2 = New GroupBox()
        Label6 = New Label()
        cmbFloor = New ComboBox()
        Label7 = New Label()
        cmbRoom = New ComboBox()
        Label8 = New Label()
        txtRent = New TextBox()
        lblMeterNumber = New Label()
        txtMeterNumber = New TextBox()
        btnSave = New Button()
        Panel2 = New Panel()
        lblTitle = New Label()
        lblFilter = New Label()
        cmbFilterStatus = New ComboBox()
        Label12 = New Label()
        txtSearch = New TextBox()
        btnRefresh = New Button()
        Panel3 = New Panel()
        btnUpdate = New Button()
        btnCheckout = New Button()
        btnClear = New Button()
        btnDelete = New Button()
        dgvTenants = New DataGridView()
        Panel1.SuspendLayout()
        tcDetails.SuspendLayout()
        tpPersonal.SuspendLayout()
        GroupBox1.SuspendLayout()
        tpRoom.SuspendLayout()
        GroupBox2.SuspendLayout()
        Panel2.SuspendLayout()
        Panel3.SuspendLayout()
        CType(dgvTenants, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' Panel1
        ' 
        Panel1.BackColor = Color.White
        Panel1.Controls.Add(tcDetails)
        Panel1.Controls.Add(btnSave)
        Panel1.Dock = DockStyle.Left
        Panel1.Location = New Point(0, 0)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(360, 749)
        Panel1.TabIndex = 0
        ' 
        ' tcDetails
        ' 
        tcDetails.Controls.Add(tpPersonal)
        tcDetails.Controls.Add(tpRoom)
        tcDetails.Font = New Font("Segoe UI", 10.0F)
        tcDetails.Location = New Point(12, 12)
        tcDetails.Name = "tcDetails"
        tcDetails.SelectedIndex = 0
        tcDetails.Size = New Size(335, 660)
        tcDetails.TabIndex = 6
        ' 
        ' tpPersonal
        ' 
        tpPersonal.Controls.Add(GroupBox1)
        tpPersonal.Location = New Point(4, 26)
        tpPersonal.Name = "tpPersonal"
        tpPersonal.Padding = New Padding(3)
        tpPersonal.Size = New Size(327, 630)
        tpPersonal.TabIndex = 0
        tpPersonal.Text = "Personal Info"
        tpPersonal.UseVisualStyleBackColor = True
        ' 
        ' GroupBox1
        ' 
        GroupBox1.Controls.Add(Label14)
        GroupBox1.Controls.Add(txtFirst)
        GroupBox1.Controls.Add(Label1)
        GroupBox1.Controls.Add(txtMiddle)
        GroupBox1.Controls.Add(Label2)
        GroupBox1.Controls.Add(txtLast)
        GroupBox1.Controls.Add(Label3)
        GroupBox1.Controls.Add(txtContact)
        GroupBox1.Controls.Add(lblEmail)
        GroupBox1.Controls.Add(txtEmail)
        GroupBox1.Controls.Add(Label4)
        GroupBox1.Controls.Add(dtpBirthday)
        GroupBox1.Controls.Add(Label13)
        GroupBox1.Controls.Add(dtpStartDate)
        GroupBox1.Controls.Add(lblEndDate)
        GroupBox1.Controls.Add(dtpEndDate)
        GroupBox1.Controls.Add(Label5)
        GroupBox1.Controls.Add(txtOccupants)
        GroupBox1.Controls.Add(lblOtherNames)
        GroupBox1.Controls.Add(txtOtherNames)
        GroupBox1.Dock = DockStyle.Fill
        GroupBox1.Font = New Font("Segoe UI Semibold", 11.25F, FontStyle.Bold)
        GroupBox1.ForeColor = Color.FromArgb(CByte(31), CByte(41), CByte(55))
        GroupBox1.Location = New Point(3, 3)
        GroupBox1.Name = "GroupBox1"
        GroupBox1.Size = New Size(321, 624)
        GroupBox1.TabIndex = 1
        GroupBox1.TabStop = False
        GroupBox1.Text = "Tenant Details"
        ' 
        ' Label14
        ' 
        Label14.AutoSize = True
        Label14.Font = New Font("Segoe UI", 9.75F)
        Label14.ForeColor = Color.FromArgb(CByte(100), CByte(116), CByte(139))
        Label14.Location = New Point(20, 20)
        Label14.Name = "Label14"
        Label14.Size = New Size(74, 17)
        Label14.TabIndex = 0
        Label14.Text = "First Name:"
        ' 
        ' txtFirst
        ' 
        txtFirst.Font = New Font("Segoe UI", 10.0F)
        txtFirst.Location = New Point(23, 40)
        txtFirst.Name = "txtFirst"
        txtFirst.Size = New Size(275, 25)
        txtFirst.TabIndex = 1
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Segoe UI", 9.75F)
        Label1.ForeColor = Color.FromArgb(CByte(100), CByte(116), CByte(139))
        Label1.Location = New Point(20, 70)
        Label1.Name = "Label1"
        Label1.Size = New Size(91, 17)
        Label1.TabIndex = 2
        Label1.Text = "Middle Name:"
        ' 
        ' txtMiddle
        ' 
        txtMiddle.Font = New Font("Segoe UI", 10.0F)
        txtMiddle.Location = New Point(23, 90)
        txtMiddle.Name = "txtMiddle"
        txtMiddle.Size = New Size(275, 25)
        txtMiddle.TabIndex = 3
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("Segoe UI", 9.75F)
        Label2.ForeColor = Color.FromArgb(CByte(100), CByte(116), CByte(139))
        Label2.Location = New Point(20, 120)
        Label2.Name = "Label2"
        Label2.Size = New Size(73, 17)
        Label2.TabIndex = 4
        Label2.Text = "Last Name:"
        ' 
        ' txtLast
        ' 
        txtLast.Font = New Font("Segoe UI", 10.0F)
        txtLast.Location = New Point(23, 140)
        txtLast.Name = "txtLast"
        txtLast.Size = New Size(275, 25)
        txtLast.TabIndex = 5
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Font = New Font("Segoe UI", 9.75F)
        Label3.ForeColor = Color.FromArgb(CByte(100), CByte(116), CByte(139))
        Label3.Location = New Point(20, 170)
        Label3.Name = "Label3"
        Label3.Size = New Size(77, 17)
        Label3.TabIndex = 6
        Label3.Text = "Contact No:"
        ' 
        ' txtContact
        ' 
        txtContact.Font = New Font("Segoe UI", 10.0F)
        txtContact.Location = New Point(23, 190)
        txtContact.Name = "txtContact"
        txtContact.Size = New Size(275, 25)
        txtContact.TabIndex = 7
        ' 
        ' lblEmail
        ' 
        lblEmail.AutoSize = True
        lblEmail.Font = New Font("Segoe UI", 9.75F)
        lblEmail.ForeColor = Color.FromArgb(CByte(100), CByte(116), CByte(139))
        lblEmail.Location = New Point(20, 220)
        lblEmail.Name = "lblEmail"
        lblEmail.Size = New Size(94, 17)
        lblEmail.TabIndex = 8
        lblEmail.Text = "Email Address:"
        ' 
        ' txtEmail
        ' 
        txtEmail.Font = New Font("Segoe UI", 10.0F)
        txtEmail.Location = New Point(23, 240)
        txtEmail.Name = "txtEmail"
        txtEmail.Size = New Size(275, 25)
        txtEmail.TabIndex = 9
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Font = New Font("Segoe UI", 9.75F)
        Label4.ForeColor = Color.FromArgb(CByte(100), CByte(116), CByte(139))
        Label4.Location = New Point(20, 270)
        Label4.Name = "Label4"
        Label4.Size = New Size(58, 17)
        Label4.TabIndex = 10
        Label4.Text = "Birthday:"
        ' 
        ' dtpBirthday
        ' 
        dtpBirthday.Font = New Font("Segoe UI", 10.0F)
        dtpBirthday.Format = DateTimePickerFormat.Short
        dtpBirthday.Location = New Point(23, 290)
        dtpBirthday.Name = "dtpBirthday"
        dtpBirthday.Size = New Size(275, 25)
        dtpBirthday.TabIndex = 11
        ' 
        ' Label13
        ' 
        Label13.AutoSize = True
        Label13.Font = New Font("Segoe UI", 9.75F)
        Label13.ForeColor = Color.FromArgb(CByte(100), CByte(116), CByte(139))
        Label13.Location = New Point(20, 320)
        Label13.Name = "Label13"
        Label13.Size = New Size(69, 17)
        Label13.TabIndex = 14
        Label13.Text = "Start Date:"
        ' 
        ' dtpStartDate
        ' 
        dtpStartDate.Font = New Font("Segoe UI", 10.0F)
        dtpStartDate.Format = DateTimePickerFormat.Short
        dtpStartDate.Location = New Point(23, 340)
        dtpStartDate.Name = "dtpStartDate"
        dtpStartDate.Size = New Size(275, 25)
        dtpStartDate.TabIndex = 15
        ' 
        ' lblEndDate
        ' 
        lblEndDate.AutoSize = True
        lblEndDate.Font = New Font("Segoe UI", 9.75F)
        lblEndDate.ForeColor = Color.FromArgb(CByte(100), CByte(116), CByte(139))
        lblEndDate.Location = New Point(20, 370)
        lblEndDate.Name = "lblEndDate"
        lblEndDate.Size = New Size(64, 17)
        lblEndDate.TabIndex = 16
        lblEndDate.Text = "End Date:"
        ' 
        ' dtpEndDate
        ' 
        dtpEndDate.Font = New Font("Segoe UI", 10.0F)
        dtpEndDate.Format = DateTimePickerFormat.Short
        dtpEndDate.Location = New Point(23, 390)
        dtpEndDate.Name = "dtpEndDate"
        dtpEndDate.Size = New Size(275, 25)
        dtpEndDate.TabIndex = 17
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Font = New Font("Segoe UI", 9.75F)
        Label5.ForeColor = Color.FromArgb(CByte(100), CByte(116), CByte(139))
        Label5.Location = New Point(20, 420)
        Label5.Name = "Label5"
        Label5.Size = New Size(140, 17)
        Label5.TabIndex = 18
        Label5.Text = "Number of Occupants:"
        ' 
        ' txtOccupants
        ' 
        txtOccupants.Font = New Font("Segoe UI", 10.0F)
        txtOccupants.Location = New Point(23, 440)
        txtOccupants.Name = "txtOccupants"
        txtOccupants.Size = New Size(275, 25)
        txtOccupants.TabIndex = 19
        ' 
        ' lblOtherNames
        ' 
        lblOtherNames.AutoSize = True
        lblOtherNames.Font = New Font("Segoe UI", 9.75F)
        lblOtherNames.ForeColor = Color.FromArgb(CByte(100), CByte(116), CByte(139))
        lblOtherNames.Location = New Point(20, 470)
        lblOtherNames.Name = "lblOtherNames"
        lblOtherNames.Size = New Size(157, 17)
        lblOtherNames.TabIndex = 20
        lblOtherNames.Text = "Other Occupants' Names:"
        ' 
        ' txtOtherNames
        ' 
        txtOtherNames.Font = New Font("Segoe UI", 10.0F)
        txtOtherNames.Location = New Point(23, 490)
        txtOtherNames.Multiline = True
        txtOtherNames.Name = "txtOtherNames"
        txtOtherNames.ScrollBars = ScrollBars.Vertical
        txtOtherNames.Size = New Size(275, 60)
        txtOtherNames.TabIndex = 21
        ' 
        ' tpRoom
        ' 
        tpRoom.Controls.Add(GroupBox2)
        tpRoom.Location = New Point(4, 26)
        tpRoom.Name = "tpRoom"
        tpRoom.Padding = New Padding(3)
        tpRoom.Size = New Size(327, 630)
        tpRoom.TabIndex = 1
        tpRoom.Text = "Room Setup"
        tpRoom.UseVisualStyleBackColor = True
        ' 
        ' GroupBox2
        ' 
        GroupBox2.Controls.Add(Label6)
        GroupBox2.Controls.Add(cmbFloor)
        GroupBox2.Controls.Add(Label7)
        GroupBox2.Controls.Add(cmbRoom)
        GroupBox2.Controls.Add(Label8)
        GroupBox2.Controls.Add(txtRent)
        GroupBox2.Controls.Add(lblMeterNumber)
        GroupBox2.Controls.Add(txtMeterNumber)
        GroupBox2.Font = New Font("Segoe UI Semibold", 11.25F, FontStyle.Bold)
        GroupBox2.ForeColor = Color.FromArgb(CByte(31), CByte(41), CByte(55))
        GroupBox2.Location = New Point(13, 15)
        GroupBox2.Name = "GroupBox2"
        GroupBox2.Size = New Size(300, 280)
        GroupBox2.TabIndex = 2
        GroupBox2.TabStop = False
        GroupBox2.Text = "Room Assignment"
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.Font = New Font("Segoe UI", 9.75F)
        Label6.ForeColor = Color.FromArgb(CByte(100), CByte(116), CByte(139))
        Label6.Location = New Point(17, 35)
        Label6.Name = "Label6"
        Label6.Size = New Size(98, 17)
        Label6.TabIndex = 0
        Label6.Text = "Assigned Floor:"
        ' 
        ' cmbFloor
        ' 
        cmbFloor.Font = New Font("Segoe UI", 10.0F)
        cmbFloor.FormattingEnabled = True
        cmbFloor.Location = New Point(20, 55)
        cmbFloor.Name = "cmbFloor"
        cmbFloor.Size = New Size(260, 25)
        cmbFloor.TabIndex = 2
        ' 
        ' Label7
        ' 
        Label7.AutoSize = True
        Label7.Font = New Font("Segoe UI", 9.75F)
        Label7.ForeColor = Color.FromArgb(CByte(100), CByte(116), CByte(139))
        Label7.Location = New Point(17, 95)
        Label7.Name = "Label7"
        Label7.Size = New Size(103, 17)
        Label7.TabIndex = 1
        Label7.Text = "Assigned Room:"
        ' 
        ' cmbRoom
        ' 
        cmbRoom.Font = New Font("Segoe UI", 10.0F)
        cmbRoom.FormattingEnabled = True
        cmbRoom.Location = New Point(20, 115)
        cmbRoom.Name = "cmbRoom"
        cmbRoom.Size = New Size(260, 25)
        cmbRoom.TabIndex = 3
        ' 
        ' Label8
        ' 
        Label8.AutoSize = True
        Label8.Font = New Font("Segoe UI", 9.75F)
        Label8.ForeColor = Color.FromArgb(CByte(100), CByte(116), CByte(139))
        Label8.Location = New Point(17, 155)
        Label8.Name = "Label8"
        Label8.Size = New Size(68, 17)
        Label8.TabIndex = 4
        Label8.Text = "Base Rent:"
        ' 
        ' txtRent
        ' 
        txtRent.Font = New Font("Segoe UI", 10.0F)
        txtRent.Location = New Point(20, 175)
        txtRent.Name = "txtRent"
        txtRent.Size = New Size(260, 25)
        txtRent.TabIndex = 8
        ' 
        ' lblMeterNumber
        ' 
        lblMeterNumber.AutoSize = True
        lblMeterNumber.Font = New Font("Segoe UI", 9.75F)
        lblMeterNumber.ForeColor = Color.FromArgb(CByte(100), CByte(116), CByte(139))
        lblMeterNumber.Location = New Point(17, 215)
        lblMeterNumber.Name = "lblMeterNumber"
        lblMeterNumber.Size = New Size(98, 17)
        lblMeterNumber.TabIndex = 12
        lblMeterNumber.Text = "Meter Number:"
        ' 
        ' txtMeterNumber
        ' 
        txtMeterNumber.Font = New Font("Segoe UI", 10.0F)
        txtMeterNumber.Location = New Point(20, 235)
        txtMeterNumber.Name = "txtMeterNumber"
        txtMeterNumber.Size = New Size(260, 25)
        txtMeterNumber.TabIndex = 13
        ' 
        ' btnSave
        ' 
        btnSave.BackColor = Color.FromArgb(CByte(31), CByte(97), CByte(141))
        btnSave.Cursor = Cursors.Hand
        btnSave.FlatAppearance.BorderSize = 0
        btnSave.FlatStyle = FlatStyle.Flat
        btnSave.Font = New Font("Segoe UI", 11.25F, FontStyle.Bold)
        btnSave.ForeColor = Color.White
        btnSave.Location = New Point(30, 685)
        btnSave.Name = "btnSave"
        btnSave.Size = New Size(300, 45)
        btnSave.TabIndex = 5
        btnSave.Text = "Save Tenant"
        btnSave.UseVisualStyleBackColor = False
        ' 
        ' Panel2
        ' 
        Panel2.BackColor = Color.White
        Panel2.Controls.Add(lblTitle)
        Panel2.Controls.Add(lblFilter)
        Panel2.Controls.Add(cmbFilterStatus)
        Panel2.Controls.Add(Label12)
        Panel2.Controls.Add(txtSearch)
        Panel2.Controls.Add(btnRefresh)
        Panel2.Dock = DockStyle.Top
        Panel2.Location = New Point(360, 0)
        Panel2.Name = "Panel2"
        Panel2.Size = New Size(711, 70)
        Panel2.TabIndex = 6
        ' 
        ' lblTitle
        ' 
        lblTitle.AutoSize = True
        lblTitle.Font = New Font("Segoe UI", 12.0F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblTitle.ForeColor = Color.FromArgb(CByte(31), CByte(41), CByte(55))
        lblTitle.Location = New Point(20, 18)
        lblTitle.Name = "lblTitle"
        lblTitle.Size = New Size(194, 21)
        lblTitle.TabIndex = 6
        lblTitle.Text = "TENANT MANAGEMENT"
        ' 
        ' lblFilter
        ' 
        lblFilter.Anchor = AnchorStyles.Top Or AnchorStyles.Right
        lblFilter.AutoSize = True
        lblFilter.Font = New Font("Segoe UI Semibold", 10.0F, FontStyle.Bold)
        lblFilter.Location = New Point(520, 24)
        lblFilter.Name = "lblFilter"
        lblFilter.Size = New Size(47, 19)
        lblFilter.TabIndex = 7
        lblFilter.Text = "Show:"
        ' 
        ' cmbFilterStatus
        ' 
        cmbFilterStatus.Anchor = AnchorStyles.Top Or AnchorStyles.Right
        cmbFilterStatus.DropDownStyle = ComboBoxStyle.DropDownList
        cmbFilterStatus.Font = New Font("Segoe UI", 10.0F)
        cmbFilterStatus.FormattingEnabled = True
        cmbFilterStatus.Items.AddRange(New Object() {"Active Tenants", "Archived Tenants"})
        cmbFilterStatus.Location = New Point(575, 22)
        cmbFilterStatus.Name = "cmbFilterStatus"
        cmbFilterStatus.Size = New Size(120, 25)
        cmbFilterStatus.TabIndex = 8
        ' 
        ' Label12
        ' 
        Label12.Anchor = AnchorStyles.Top Or AnchorStyles.Right
        Label12.AutoSize = True
        Label12.Font = New Font("Segoe UI Semibold", 10.0F, FontStyle.Bold)
        Label12.ForeColor = Color.FromArgb(CByte(31), CByte(41), CByte(55))
        Label12.Location = New Point(280, 24)
        Label12.Name = "Label12"
        Label12.Size = New Size(54, 19)
        Label12.TabIndex = 3
        Label12.Text = "Search:"
        ' 
        ' txtSearch
        ' 
        txtSearch.Anchor = AnchorStyles.Top Or AnchorStyles.Right
        txtSearch.Font = New Font("Segoe UI", 10.0F)
        txtSearch.Location = New Point(340, 22)
        txtSearch.Name = "txtSearch"
        txtSearch.Size = New Size(140, 25)
        txtSearch.TabIndex = 4
        ' 
        ' btnRefresh
        ' 
        btnRefresh.Anchor = AnchorStyles.Top Or AnchorStyles.Right
        btnRefresh.BackColor = Color.FromArgb(CByte(226), CByte(232), CByte(240))
        btnRefresh.Cursor = Cursors.Hand
        btnRefresh.FlatAppearance.BorderSize = 0
        btnRefresh.FlatStyle = FlatStyle.Flat
        btnRefresh.Font = New Font("Segoe UI Semibold", 9.75F, FontStyle.Bold)
        btnRefresh.ForeColor = Color.FromArgb(CByte(31), CByte(41), CByte(55))
        btnRefresh.Location = New Point(485, 20)
        btnRefresh.Name = "btnRefresh"
        btnRefresh.Size = New Size(30, 30)
        btnRefresh.TabIndex = 5
        btnRefresh.Text = "↻"
        btnRefresh.UseVisualStyleBackColor = False
        ' 
        ' Panel3
        ' 
        Panel3.BackColor = Color.White
        Panel3.Controls.Add(btnUpdate)
        Panel3.Controls.Add(btnCheckout)
        Panel3.Controls.Add(btnClear)
        Panel3.Controls.Add(btnDelete)
        Panel3.Dock = DockStyle.Bottom
        Panel3.Location = New Point(360, 669)
        Panel3.Name = "Panel3"
        Panel3.Size = New Size(711, 80)
        Panel3.TabIndex = 7
        ' 
        ' btnUpdate
        ' 
        btnUpdate.Anchor = AnchorStyles.Bottom Or AnchorStyles.Right
        btnUpdate.BackColor = Color.FromArgb(CByte(31), CByte(97), CByte(141))
        btnUpdate.Cursor = Cursors.Hand
        btnUpdate.FlatAppearance.BorderSize = 0
        btnUpdate.FlatStyle = FlatStyle.Flat
        btnUpdate.Font = New Font("Segoe UI", 10.0F, FontStyle.Bold)
        btnUpdate.ForeColor = Color.White
        btnUpdate.Location = New Point(180, 20)
        btnUpdate.Name = "btnUpdate"
        btnUpdate.Size = New Size(120, 40)
        btnUpdate.TabIndex = 0
        btnUpdate.Text = "UPDATE"
        btnUpdate.UseVisualStyleBackColor = False
        ' 
        ' btnCheckout
        ' 
        btnCheckout.Anchor = AnchorStyles.Bottom Or AnchorStyles.Right
        btnCheckout.BackColor = Color.IndianRed
        btnCheckout.Cursor = Cursors.Hand
        btnCheckout.FlatAppearance.BorderSize = 0
        btnCheckout.FlatStyle = FlatStyle.Flat
        btnCheckout.Font = New Font("Segoe UI", 10.0F, FontStyle.Bold)
        btnCheckout.ForeColor = Color.White
        btnCheckout.Location = New Point(310, 20)
        btnCheckout.Name = "btnCheckout"
        btnCheckout.Size = New Size(120, 40)
        btnCheckout.TabIndex = 1
        btnCheckout.Text = "CHECK-OUT"
        btnCheckout.UseVisualStyleBackColor = False
        ' 
        ' btnClear
        ' 
        btnClear.Anchor = AnchorStyles.Bottom Or AnchorStyles.Right
        btnClear.BackColor = Color.FromArgb(CByte(226), CByte(232), CByte(240))
        btnClear.Cursor = Cursors.Hand
        btnClear.FlatAppearance.BorderSize = 0
        btnClear.FlatStyle = FlatStyle.Flat
        btnClear.Font = New Font("Segoe UI", 10.0F, FontStyle.Bold)
        btnClear.ForeColor = Color.FromArgb(CByte(31), CByte(41), CByte(55))
        btnClear.Location = New Point(440, 20)
        btnClear.Name = "btnClear"
        btnClear.Size = New Size(120, 40)
        btnClear.TabIndex = 2
        btnClear.Text = "CLEAR"
        btnClear.UseVisualStyleBackColor = False
        ' 
        ' btnDelete
        ' 
        btnDelete.Anchor = AnchorStyles.Bottom Or AnchorStyles.Right
        btnDelete.BackColor = Color.IndianRed
        btnDelete.Cursor = Cursors.Hand
        btnDelete.FlatAppearance.BorderSize = 0
        btnDelete.FlatStyle = FlatStyle.Flat
        btnDelete.Font = New Font("Segoe UI", 10.0F, FontStyle.Bold)
        btnDelete.ForeColor = Color.White
        btnDelete.Location = New Point(570, 20)
        btnDelete.Name = "btnDelete"
        btnDelete.Size = New Size(120, 40)
        btnDelete.TabIndex = 3
        btnDelete.Text = "ARCHIVE"
        btnDelete.UseVisualStyleBackColor = False
        ' 
        ' dgvTenants
        ' 
        dgvTenants.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
        dgvTenants.BackgroundColor = Color.White
        dgvTenants.BorderStyle = BorderStyle.None
        DataGridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = Color.FromArgb(CByte(243), CByte(244), CByte(246))
        DataGridViewCellStyle1.Font = New Font("Segoe UI", 9.75F)
        DataGridViewCellStyle1.ForeColor = Color.FromArgb(CByte(31), CByte(41), CByte(55))
        DataGridViewCellStyle1.SelectionBackColor = Color.FromArgb(CByte(243), CByte(244), CByte(246))
        DataGridViewCellStyle1.SelectionForeColor = Color.FromArgb(CByte(31), CByte(41), CByte(55))
        DataGridViewCellStyle1.WrapMode = DataGridViewTriState.True
        dgvTenants.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        dgvTenants.ColumnHeadersHeight = 35
        DataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = Color.White
        DataGridViewCellStyle2.Font = New Font("Segoe UI", 9.75F)
        DataGridViewCellStyle2.ForeColor = Color.FromArgb(CByte(31), CByte(41), CByte(55))
        DataGridViewCellStyle2.SelectionBackColor = Color.FromArgb(CByte(31), CByte(97), CByte(141))
        DataGridViewCellStyle2.SelectionForeColor = Color.White
        DataGridViewCellStyle2.WrapMode = DataGridViewTriState.False
        dgvTenants.DefaultCellStyle = DataGridViewCellStyle2
        dgvTenants.Dock = DockStyle.Fill
        dgvTenants.EnableHeadersVisualStyles = False
        dgvTenants.Location = New Point(360, 70)
        dgvTenants.Name = "dgvTenants"
        dgvTenants.RowHeadersVisible = False
        dgvTenants.RowTemplate.Height = 30
        dgvTenants.SelectionMode = DataGridViewSelectionMode.FullRowSelect
        dgvTenants.Size = New Size(711, 599)
        dgvTenants.TabIndex = 8
        ' 
        ' frmTenantMgmt
        ' 
        AutoScaleDimensions = New SizeF(7.0F, 17.0F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.FromArgb(CByte(243), CByte(244), CByte(246))
        ClientSize = New Size(1071, 749)
        Controls.Add(dgvTenants)
        Controls.Add(Panel3)
        Controls.Add(Panel2)
        Controls.Add(Panel1)
        Font = New Font("Segoe UI", 9.75F)
        Name = "frmTenantMgmt"
        StartPosition = FormStartPosition.CenterScreen
        Text = "Tenant Management"
        Panel1.ResumeLayout(False)
        tcDetails.ResumeLayout(False)
        tpPersonal.ResumeLayout(False)
        GroupBox1.ResumeLayout(False)
        GroupBox1.PerformLayout()
        tpRoom.ResumeLayout(False)
        GroupBox2.ResumeLayout(False)
        GroupBox2.PerformLayout()
        Panel2.ResumeLayout(False)
        Panel2.PerformLayout()
        Panel3.ResumeLayout(False)
        CType(dgvTenants, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)

    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents txtOccupants As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents dtpBirthday As DateTimePicker
    Friend WithEvents Label4 As Label
    Friend WithEvents txtContact As TextBox
    Friend WithEvents lblEmail As Label
    Friend WithEvents txtEmail As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents txtLast As TextBox
    Friend WithEvents txtRent As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents cmbRoom As ComboBox
    Friend WithEvents cmbFloor As ComboBox
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents btnSave As Button
    Friend WithEvents Label12 As Label
    Friend WithEvents txtSearch As TextBox
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Panel3 As Panel
    Friend WithEvents btnDelete As Button
    Friend WithEvents btnClear As Button
    Friend WithEvents btnCheckout As Button
    Friend WithEvents btnUpdate As Button
    Friend WithEvents dtpStartDate As DateTimePicker
    Friend WithEvents Label13 As Label
    Friend WithEvents btnRefresh As Button
    Friend WithEvents dgvTenants As DataGridView
    Friend WithEvents Label14 As Label
    Friend WithEvents txtFirst As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents txtMiddle As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents tcDetails As TabControl
    Friend WithEvents tpPersonal As TabPage
    Friend WithEvents tpRoom As TabPage
    Friend WithEvents lblMeterNumber As Label
    Friend WithEvents txtMeterNumber As TextBox
    Friend WithEvents lblEndDate As Label
    Friend WithEvents dtpEndDate As DateTimePicker
    Friend WithEvents lblOtherNames As Label
    Friend WithEvents txtOtherNames As TextBox
    Friend WithEvents lblFilter As Label
    Friend WithEvents cmbFilterStatus As ComboBox
    Friend WithEvents lblTitle As Label
End Class